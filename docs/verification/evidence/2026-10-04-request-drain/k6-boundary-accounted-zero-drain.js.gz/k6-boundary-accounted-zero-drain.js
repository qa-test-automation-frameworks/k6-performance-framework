"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// tests/load/request-rate-load.ts
var request_rate_load_exports = {};
__export(request_rate_load_exports, {
  handleSummary: () => handleSummary,
  options: () => options,
  singleRequest: () => singleRequest
});
module.exports = __toCommonJS(request_rate_load_exports);
var import_k63 = require("k6");
var import_execution = __toESM(require("k6/execution"));
var import_http2 = __toESM(require("k6/http"));
var import_metrics3 = require("k6/metrics");

// config/environments/local.ts
var localConfig = {
  environment: "local",
  baseUrl: "http://localhost:3000/api",
  timeouts: { http: 3e4 },
  arrival: { iterationsPerSecond: 20, maxVus: 100 },
  tags: { env: "local", app: "conduit" },
  allowsWrites: true
};

// config/environments/production.ts
function productionConfig(baseUrl) {
  if (!baseUrl) {
    throw new Error('BASE_URL is required when TARGET_ENV is "production"');
  }
  return {
    environment: "production",
    baseUrl,
    timeouts: { http: 3e4 },
    arrival: { iterationsPerSecond: 10, maxVus: 50 },
    tags: { env: "production", app: "conduit" },
    allowsWrites: false
  };
}

// config/environments/staging.ts
var stagingConfig = {
  environment: "staging",
  baseUrl: "https://api.realworld.show/api",
  timeouts: { http: 3e4 },
  arrival: { iterationsPerSecond: 50, maxVus: 400 },
  tags: { env: "staging", app: "conduit" },
  allowsWrites: false
};

// config/index.ts
var configs = {
  local: localConfig,
  staging: stagingConfig
};
function getConfig(env = __ENV.TARGET_ENV ?? "local") {
  if (env === "production") {
    return {
      ...productionConfig(__ENV.BASE_URL),
      allowsWrites: __ENV.ALLOW_NON_LOCAL_LOAD === "true"
    };
  }
  if (env === "local" || env === "staging") {
    return {
      ...configs[env],
      baseUrl: __ENV.BASE_URL ?? configs[env].baseUrl,
      allowsWrites: env === "staging" ? __ENV.ALLOW_NON_LOCAL_LOAD === "true" : configs[env].allowsWrites
    };
  }
  throw new Error(`Unknown TARGET_ENV: "${env}"`);
}

// config/workloads.ts
var REQUEST_DRAIN_SECONDS = 2;
function positiveNumber(name, fallback) {
  const raw = __ENV[name];
  if (raw === void 0) return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`${name} must be a positive number`);
  }
  return value;
}
function rejectLegacyRate() {
  if (__ENV.TARGET_RPS !== void 0) {
    throw new Error(
      "TARGET_RPS is ambiguous and has been removed. For the existing journey use TARGET_ITERATIONS_PER_SECOND (old arrival-iteration semantics); for one request per iteration use REQUESTS_PER_SECOND with the dedicated request-rate entry point."
    );
  }
}
function positiveInteger(name, fallback) {
  const value = positiveNumber(name, fallback);
  if (!Number.isSafeInteger(value)) throw new Error(`${name} must be a positive safe integer`);
  return value;
}
function getRequestRateProfile() {
  rejectLegacyRate();
  const minimumAchievedFraction = positiveNumber("MINIMUM_ACHIEVED_FRACTION", 0.98);
  if (minimumAchievedFraction > 1) {
    throw new Error("MINIMUM_ACHIEVED_FRACTION must be at most 1");
  }
  const profile2 = {
    requestsPerSecond: positiveInteger("REQUESTS_PER_SECOND", 500),
    maxVus: positiveInteger("MAX_VUS", 100),
    warmupSeconds: positiveInteger("WARMUP_SECONDS", 10),
    measurementSeconds: positiveInteger("MEASUREMENT_SECONDS", 60),
    minimumAchievedFraction
  };
  if (!Number.isSafeInteger(profile2.requestsPerSecond * profile2.measurementSeconds)) {
    throw new Error("Configured measurement request count exceeds safe integer range");
  }
  return profile2;
}
function getWorkloadProfile() {
  const config2 = getConfig();
  rejectLegacyRate();
  return {
    validation: __ENV.TEST_PROFILE === "validation",
    targetIterationsPerSecond: positiveInteger(
      "TARGET_ITERATIONS_PER_SECOND",
      config2.arrival.iterationsPerSecond
    ),
    maxVus: positiveInteger("MAX_VUS", config2.arrival.maxVus),
    thinkTimeSeconds: positiveNumber("THINK_TIME_SECONDS", 1)
  };
}

// src/helpers/auth.ts
var import_data = require("k6/data");
var tokens = new import_data.SharedArray("user tokens", () => {
  const raw = __ENV.K6_USER_TOKENS;
  if (!raw) return [];
  const parsed = JSON.parse(raw);
  if (!Array.isArray(parsed) || !parsed.every((value) => typeof value === "string")) {
    throw new Error("K6_USER_TOKENS must be a JSON array of strings");
  }
  return parsed;
});

// src/helpers/checks.ts
var import_k6 = require("k6");

// src/utils/http-client.ts
var import_k62 = require("k6");
var import_http = __toESM(require("k6/http"));

// src/utils/metrics.ts
var import_metrics = require("k6/metrics");
var authDuration = new import_metrics.Trend("custom_auth_duration_ms", true);
var articleReadDuration = new import_metrics.Trend("custom_article_read_duration_ms", true);
var articleWriteDuration = new import_metrics.Trend("custom_article_write_duration_ms", true);
var commentDuration = new import_metrics.Trend("custom_comment_duration_ms", true);
var profileDuration = new import_metrics.Trend("custom_profile_duration_ms", true);
var tagDuration = new import_metrics.Trend("custom_tag_duration_ms", true);
var totalBusinessErrors = new import_metrics.Counter("custom_business_errors_total");
var authSuccessRate = new import_metrics.Rate("custom_auth_success_rate");
var articleReadSuccessRate = new import_metrics.Rate("custom_article_read_success_rate");
var articleWriteSuccessRate = new import_metrics.Rate("custom_article_write_success_rate");
var commentSuccessRate = new import_metrics.Rate("custom_comment_success_rate");
var profileSuccessRate = new import_metrics.Rate("custom_profile_success_rate");
var tagSuccessRate = new import_metrics.Rate("custom_tag_success_rate");

// src/fixtures/browse-behaviors.ts
var import_data2 = require("k6/data");

// src/fixtures/browse-behaviors.json
var browse_behaviors_default = [
  { name: "quick-reader", weight: 50, articleLimit: 5, inspectArticle: false },
  { name: "article-reader", weight: 35, articleLimit: 10, inspectArticle: true },
  { name: "deep-reader", weight: 15, articleLimit: 20, inspectArticle: true }
];

// src/fixtures/browse-behaviors.ts
var behaviors = new import_data2.SharedArray(
  "browse behaviors",
  () => browse_behaviors_default.map((behavior) => ({ ...behavior }))
);

// src/helpers/safety.ts
function assertAuthorizedLoadTarget(policy) {
  const config2 = getConfig();
  const loopback = /^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(?:\/|$)/i.test(
    config2.baseUrl
  );
  if ((config2.environment !== "local" || !loopback) && __ENV.ALLOW_NON_LOCAL_LOAD !== "true") {
    throw new Error(
      `${policy.workload} ${policy.write ? "write" : "load"} traffic requires a loopback local target or explicit owned-target ALLOW_NON_LOCAL_LOAD=true`
    );
  }
}

// src/helpers/achieved-load.ts
function assessAchievedLoad(profile2, counts) {
  const reasons = [];
  const validCount = (value) => value !== void 0 && Number.isSafeInteger(value) && value >= 0;
  const iterations = validCount(counts.iterations) ? counts.iterations : null;
  const started = validCount(counts.started) ? counts.started : null;
  const requests = validCount(counts.requests) ? counts.requests : null;
  const dropped = validCount(counts.dropped) ? counts.dropped : null;
  if (iterations === null || requests === null || dropped === null || started === null) {
    reasons.push("Missing or invalid measurement count");
  }
  const expected = profile2.requestsPerSecond * profile2.measurementSeconds;
  if (iterations !== null && iterations < expected * profile2.minimumAchievedFraction) {
    reasons.push("Achieved arrival iterations below predeclared minimum");
  }
  if (requests !== null && requests < expected * profile2.minimumAchievedFraction) {
    reasons.push("Achieved HTTP requests below predeclared minimum");
  }
  if (requests !== null && iterations !== null && requests !== iterations) {
    reasons.push("One-request-per-completed-iteration contract violated");
  }
  if (started !== null && requests !== null && started !== requests) {
    reasons.push("Started HTTP attempts did not all complete within the bounded drain");
  }
  if (requests !== null && requests > expected + 1) {
    reasons.push("Request count exceeds configured arrival cohort");
  }
  if (dropped !== null && dropped > 0) reasons.push("Generator dropped measurement iterations");
  return {
    valid: reasons.length === 0,
    reasons,
    configuredRequestsPerSecond: profile2.requestsPerSecond,
    measurementSeconds: profile2.measurementSeconds,
    minimumAchievedFraction: profile2.minimumAchievedFraction,
    completedIterations: iterations,
    startedRequests: started,
    requests,
    droppedIterations: dropped,
    achievedIterationsPerSecond: iterations === null ? null : iterations / profile2.measurementSeconds,
    achievedRequestsPerSecond: requests === null ? null : requests / profile2.measurementSeconds
  };
}

// src/helpers/summary.ts
function summaryFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.json`;
}
function markdownFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.md`;
}
function htmlFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.html`;
}
function metricRow(name, values) {
  const median = values?.med;
  const p90 = values?.["p(90)"];
  const p95 = values?.["p(95)"];
  const p99 = values?.["p(99)"];
  const max = values?.max;
  const rate = values?.rate;
  const count = values?.count;
  return `| ${name} | ${median?.toFixed(2) ?? "-"} | ${p90?.toFixed(2) ?? "-"} | ${p95?.toFixed(2) ?? "-"} | ${p99?.toFixed(2) ?? "-"} | ${max?.toFixed(2) ?? "-"} | ${rate?.toFixed(4) ?? "-"} | ${count ?? "-"} |`;
}
function thresholdActual(values, threshold) {
  const key = threshold.match(/^(p\(\d+\)|avg|med|min|max|rate|count|value)/)?.[1];
  return key ? values[key] : void 0;
}
function htmlEscape(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function metricValue(value, digits = 2) {
  return value === void 0 ? "-" : value.toFixed(digits);
}
function htmlMetricRows(metrics, names) {
  if (names.length === 0) {
    return '<tr><td colspan="7">No matching metrics were emitted.</td></tr>';
  }
  return names.map((name) => {
    const values = metrics[name] ?? {};
    return `<tr><td>${htmlEscape(name)}</td><td>${metricValue(values.med)}</td><td>${metricValue(values["p(90)"])}</td><td>${metricValue(values["p(95)"])}</td><td>${metricValue(values["p(99)"])}</td><td>${metricValue(values.rate, 4)}</td><td>${values.count ?? "-"}</td></tr>`;
  }).join("");
}
function htmlThresholdRows(summary) {
  const rows = Object.entries(summary.thresholds).flatMap(
    ([metric, thresholds]) => Object.entries(thresholds).map(([threshold, result]) => {
      const actual = thresholdActual(summary.metrics[metric] ?? {}, threshold);
      return `<tr><td>${htmlEscape(metric)}</td><td>${htmlEscape(threshold)}</td><td>${actual ?? "unavailable"}</td><td class="${result.ok ? "passed" : "failed"}">${result.ok ? "PASS" : "FAIL"}</td></tr>`;
    })
  );
  return rows.length === 0 ? '<tr><td colspan="4">No threshold results were reported.</td></tr>' : rows.join("");
}
function createSummary(data) {
  const workload = getWorkloadProfile();
  const requestProfile = __ENV.WORKLOAD_MODE === "request-rate" ? getRequestRateProfile() : null;
  const achievedLoad = requestProfile ? assessAchievedLoad(requestProfile, {
    iterations: data.metrics["iterations{scenario:request_measurement}"]?.values.count,
    started: data.metrics["request_attempts{scenario:request_measurement}"]?.values.count,
    requests: data.metrics["http_reqs{scenario:request_measurement}"]?.values.count,
    dropped: data.metrics["dropped_iterations{scenario:request_measurement}"]?.values.count
  }) : null;
  const checkFailures = data.metrics.checks?.values.fails ?? 0;
  const interruptedIterations = data.metrics.interrupted_iterations?.values.count ?? data.state.interruptedIterations ?? 0;
  const setupErrors = data.state.setupErrors ?? 0;
  const summary = {
    achievedLoad,
    failures: [],
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    metrics: Object.fromEntries(
      Object.entries(data.metrics).map(([name, metric]) => [name, metric.values])
    ),
    metadata: {
      environment: __ENV.TARGET_ENV ?? "local",
      frameworkCommit: __ENV.FRAMEWORK_COMMIT ?? "unknown",
      k6Version: __ENV.K6_VERSION ?? "2.0.0",
      maxVus: requestProfile?.maxVus ?? workload.maxVus,
      profile: __ENV.TEST_PROFILE ?? "full",
      runnerClass: __ENV.RUNNER_CLASS ?? "local",
      targetCommit: __ENV.TARGET_COMMIT ?? "unknown",
      targetId: __ENV.TARGET_ID ?? __ENV.TARGET_ENV ?? "local",
      workloadSchema: requestProfile ? "single-request-arrival-v2" : "journey-arrival-v1",
      targetIterationsPerSecond: requestProfile?.requestsPerSecond ?? workload.targetIterationsPerSecond,
      targetRequestsPerSecond: requestProfile?.requestsPerSecond ?? null,
      measurementSeconds: requestProfile?.measurementSeconds ?? null,
      warmupSeconds: requestProfile?.warmupSeconds ?? null,
      minimumAchievedFraction: requestProfile?.minimumAchievedFraction ?? null,
      requestDrainSeconds: requestProfile ? REQUEST_DRAIN_SECONDS : null
    },
    rootGroup: data.root_group,
    state: data.state,
    thresholds: Object.fromEntries(
      Object.entries(data.metrics).filter(([, metric]) => metric.thresholds).map(([name, metric]) => [name, metric.thresholds ?? {}])
    )
  };
  const failedThresholds = Object.entries(summary.thresholds).flatMap(
    ([metric, thresholds]) => Object.entries(thresholds).filter(([, result]) => !result.ok).map(([threshold]) => {
      const actual = thresholdActual(summary.metrics[metric] ?? {}, threshold);
      return `${metric}: expected ${threshold}; actual ${actual ?? "unavailable"}`;
    })
  );
  summary.failures = [
    ...achievedLoad && !achievedLoad.valid ? achievedLoad.reasons.map((reason) => `Invalid load experiment: ${reason}`) : [],
    ...failedThresholds.map((failure) => `Threshold: ${failure}`),
    ...checkFailures > 0 ? [`Checks: ${checkFailures} failed`] : [],
    ...setupErrors > 0 ? [`Setup: ${setupErrors} error(s)`] : [],
    ...interruptedIterations > 0 ? [`Execution: ${interruptedIterations} interrupted iteration(s)`] : []
  ];
  const markdown = [
    "# k6 Performance Summary",
    "",
    `**Run status:** ${summary.failures.length ? "FAILED" : "PASSED"}`,
    `**Target:** ${summary.metadata.targetId} (${summary.metadata.targetCommit})`,
    `**Profile:** ${summary.metadata.profile} on ${summary.metadata.runnerClass}`,
    `**Workload schema:** ${summary.metadata.workloadSchema}`,
    `**Configured arrival:** ${summary.metadata.targetIterationsPerSecond} iterations/s`,
    `**Configured requests:** ${summary.metadata.targetRequestsPerSecond ?? "not fixed by journey arrival"}${requestProfile ? " requests/s" : ""}`,
    ...achievedLoad ? [
      `**Measurement:** ${achievedLoad.measurementSeconds}s scheduled arrival window, excluding warm-up and the 2s settling gap`,
      `**Completion drain:** at most ${summary.metadata.requestDrainSeconds}s; counts include completion of requests started in the scheduled arrival window, with throughput divided by that window`,
      `**Achieved:** ${achievedLoad.achievedIterationsPerSecond ?? "unknown"} completed iterations/s; ${achievedLoad.achievedRequestsPerSecond ?? "unknown"} requests/s; ${achievedLoad.droppedIterations ?? "unknown"} dropped iterations`,
      `**Load validity:** ${achievedLoad.valid ? "VALID" : "INVALID"} (predeclared minimum fraction ${achievedLoad.minimumAchievedFraction})`
    ] : [
      `**Observed full-run rates:** ${summary.metrics.iterations?.rate ?? "unknown"} iterations/s; ${summary.metrics.http_reqs?.rate ?? "unknown"} requests/s (native full-run denominator, not a separated steady-state window)`
    ],
    ...summary.failures.length ? ["", ...summary.failures.map((failure) => `- ${failure}`)] : [],
    "",
    "| Metric | p50 | p90 | p95 | p99 | max | Rate | Count |",
    "|---|---:|---:|---:|---:|---:|---:|---:|",
    metricRow("http_req_duration", summary.metrics.http_req_duration),
    metricRow("http_req_failed", summary.metrics.http_req_failed),
    metricRow("checks", summary.metrics.checks),
    metricRow("http_reqs", summary.metrics.http_reqs),
    metricRow("iterations", summary.metrics.iterations),
    metricRow("custom_article_read_duration_ms", summary.metrics.custom_article_read_duration_ms),
    metricRow("custom_business_errors_total", summary.metrics.custom_business_errors_total),
    ""
  ].join("\n");
  const duration = summary.metrics.http_req_duration ?? {};
  const bars = [
    ["p50", duration.med ?? 0],
    ["p90", duration["p(90)"] ?? 0],
    ["p95", duration["p(95)"] ?? 0],
    ["p99", duration["p(99)"] ?? 0],
    ["max", duration.max ?? 0]
  ];
  const maximum = Math.max(...bars.map(([, value]) => value), 1);
  const chart = bars.map(
    ([label, value], index) => `<g transform="translate(0 ${index * 42})"><text x="0" y="20">${label}</text><rect x="48" y="4" width="${value / maximum * 500}" height="22" fill="#2563eb"/><text x="${56 + value / maximum * 500}" y="20">${value.toFixed(2)} ms</text></g>`
  ).join("");
  const endpointMetrics = Object.keys(summary.metrics).filter(
    (name) => name.startsWith("http_req_duration{name:") || name.startsWith("http_req_failed{name:")
  ).sort();
  const businessMetrics = Object.keys(summary.metrics).filter((name) => name.startsWith("custom_")).sort();
  const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>k6 Performance Summary</title>
<style>body{font:16px system-ui;max-width:1120px;margin:40px auto;padding:0 20px;color:#18212f}table{border-collapse:collapse;width:100%;margin:12px 0 28px}th,td{padding:8px;border:1px solid #ccd3dc;text-align:left}th{background:#f4f7fb}.failed{color:#b91c1c;font-weight:700}.passed{color:#047857;font-weight:700}.meta{line-height:1.6}.chart{margin:12px 0 28px}</style></head>
<body><h1>k6 Performance Summary</h1>
<p class="${summary.failures.length ? "failed" : "passed"}"><strong>${summary.failures.length ? "FAILED" : "PASSED"}</strong></p>
<p class="meta">Target: ${htmlEscape(summary.metadata.targetId)} (${htmlEscape(summary.metadata.targetCommit)})<br>Profile: ${htmlEscape(summary.metadata.profile)}<br>Runner: ${htmlEscape(summary.metadata.runnerClass)}</p>
<svg class="chart" role="img" aria-label="Latency percentiles" width="720" height="230" viewBox="0 0 720 230">${chart}</svg>
<h2>Core Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, ["http_req_duration", "http_req_failed", "checks", "http_reqs", "iterations"])}</tbody></table>
<h2>Endpoint Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, endpointMetrics)}</tbody></table>
<h2>Business Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, businessMetrics)}</tbody></table>
<h2>Thresholds</h2>
<table><thead><tr><th>Metric</th><th>Threshold</th><th>Actual</th><th>Status</th></tr></thead><tbody>${htmlThresholdRows(summary)}</tbody></table>
<h2>Markdown Summary</h2>
<pre>${htmlEscape(markdown)}</pre>
</body></html>`;
  return {
    [summaryFile()]: JSON.stringify(summary, null, 2),
    [markdownFile()]: markdown,
    [htmlFile()]: html,
    stdout: markdown
  };
}

// src/types/config.types.ts
var summaryTrendStats = ["avg", "min", "med", "max", "p(90)", "p(95)", "p(99)"];

// tests/load/request-rate-load.ts
assertAuthorizedLoadTarget({ workload: "Single-request arrival load" });
if (__ENV.WORKLOAD_MODE !== "request-rate") {
  throw new Error("Set WORKLOAD_MODE=request-rate for this dedicated entry point");
}
var profile = getRequestRateProfile();
var config = getConfig();
var minimumCount = Math.ceil(
  profile.requestsPerSecond * profile.measurementSeconds * profile.minimumAchievedFraction
);
var expectedCount = profile.requestsPerSecond * profile.measurementSeconds;
var requestAttempts = new import_metrics3.Counter("request_attempts");
var options = {
  scenarios: {
    request_warmup: {
      executor: "constant-arrival-rate",
      exec: "singleRequest",
      rate: profile.requestsPerSecond,
      timeUnit: "1s",
      duration: `${profile.warmupSeconds}s`,
      preAllocatedVUs: Math.min(20, profile.maxVus),
      maxVUs: profile.maxVus,
      gracefulStop: "0s"
    },
    request_measurement: {
      executor: "constant-arrival-rate",
      exec: "singleRequest",
      startTime: `${profile.warmupSeconds + 2}s`,
      rate: profile.requestsPerSecond,
      timeUnit: "1s",
      duration: `${profile.measurementSeconds}s`,
      preAllocatedVUs: Math.min(20, profile.maxVus),
      maxVUs: profile.maxVus,
      gracefulStop: "0s"
    }
  },
  // Creating submetrics through thresholds makes their count available in the native summary.
  thresholds: {
    "request_attempts{scenario:request_measurement}": [
      `count>=${minimumCount}`,
      `count<=${expectedCount + 1}`
    ],
    "http_reqs{scenario:request_measurement}": [
      `count>=${minimumCount}`,
      `count<=${expectedCount + 1}`
    ],
    "iterations{scenario:request_measurement}": [`count>=${minimumCount}`],
    "dropped_iterations{scenario:request_measurement}": ["count==0"],
    "checks{scenario:request_measurement}": ["rate==1"],
    "http_req_failed{scenario:request_measurement}": ["rate<0.01"],
    "http_req_duration{scenario:request_measurement}": ["p(95)<80", "p(99)<150"]
  },
  maxRedirects: 0,
  summaryTrendStats
};
function singleRequest() {
  const path = import_execution.default.scenario.iterationInTest % 5 === 4 ? "/tags" : "/articles?limit=10&offset=0";
  requestAttempts.add(1);
  const response = import_http2.default.get(`${config.baseUrl.replace(/\/$/, "")}${path}`, {
    redirects: 0,
    timeout: "1s",
    headers: { "X-Load-Phase": import_execution.default.scenario.name },
    tags: { ...config.tags, name: path.startsWith("/tags") ? "GET /tags" : "GET /articles" }
  });
  (0, import_k63.check)(response, { "single request status is 200": (result) => result.status === 200 });
}
var handleSummary = createSummary;
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vdGVzdHMvbG9hZC9yZXF1ZXN0LXJhdGUtbG9hZC50cyIsICIuLi8uLi9jb25maWcvZW52aXJvbm1lbnRzL2xvY2FsLnRzIiwgIi4uLy4uL2NvbmZpZy9lbnZpcm9ubWVudHMvcHJvZHVjdGlvbi50cyIsICIuLi8uLi9jb25maWcvZW52aXJvbm1lbnRzL3N0YWdpbmcudHMiLCAiLi4vLi4vY29uZmlnL2luZGV4LnRzIiwgIi4uLy4uL2NvbmZpZy93b3JrbG9hZHMudHMiLCAiLi4vLi4vc3JjL2hlbHBlcnMvYXV0aC50cyIsICIuLi8uLi9zcmMvaGVscGVycy9jaGVja3MudHMiLCAiLi4vLi4vc3JjL3V0aWxzL2h0dHAtY2xpZW50LnRzIiwgIi4uLy4uL3NyYy91dGlscy9tZXRyaWNzLnRzIiwgIi4uLy4uL3NyYy9maXh0dXJlcy9icm93c2UtYmVoYXZpb3JzLnRzIiwgIi4uLy4uL3NyYy9maXh0dXJlcy9icm93c2UtYmVoYXZpb3JzLmpzb24iLCAiLi4vLi4vc3JjL2hlbHBlcnMvc2FmZXR5LnRzIiwgIi4uLy4uL3NyYy9oZWxwZXJzL2FjaGlldmVkLWxvYWQudHMiLCAiLi4vLi4vc3JjL2hlbHBlcnMvc3VtbWFyeS50cyIsICIuLi8uLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBjaGVjayB9IGZyb20gJ2s2JztcbmltcG9ydCBleGVjdXRpb24gZnJvbSAnazYvZXhlY3V0aW9uJztcbmltcG9ydCBodHRwIGZyb20gJ2s2L2h0dHAnO1xuaW1wb3J0IHsgQ291bnRlciB9IGZyb20gJ2s2L21ldHJpY3MnO1xuaW1wb3J0IHR5cGUgeyBPcHRpb25zIH0gZnJvbSAnazYvb3B0aW9ucyc7XG5pbXBvcnQgeyBnZXRDb25maWcgfSBmcm9tICcuLi8uLi9jb25maWcnO1xuaW1wb3J0IHsgZ2V0UmVxdWVzdFJhdGVQcm9maWxlLCBSRVFVRVNUX0RSQUlOX1NFQ09ORFMgfSBmcm9tICcuLi8uLi9jb25maWcvd29ya2xvYWRzJztcbmltcG9ydCB7IGFzc2VydEF1dGhvcml6ZWRMb2FkVGFyZ2V0LCBjcmVhdGVTdW1tYXJ5IH0gZnJvbSAnLi4vLi4vc3JjL2hlbHBlcnMnO1xuaW1wb3J0IHsgc3VtbWFyeVRyZW5kU3RhdHMgfSBmcm9tICcuLi8uLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzJztcblxuYXNzZXJ0QXV0aG9yaXplZExvYWRUYXJnZXQoeyB3b3JrbG9hZDogJ1NpbmdsZS1yZXF1ZXN0IGFycml2YWwgbG9hZCcgfSk7XG5pZiAoX19FTlYuV09SS0xPQURfTU9ERSAhPT0gJ3JlcXVlc3QtcmF0ZScpIHtcbiAgdGhyb3cgbmV3IEVycm9yKCdTZXQgV09SS0xPQURfTU9ERT1yZXF1ZXN0LXJhdGUgZm9yIHRoaXMgZGVkaWNhdGVkIGVudHJ5IHBvaW50Jyk7XG59XG5jb25zdCBwcm9maWxlID0gZ2V0UmVxdWVzdFJhdGVQcm9maWxlKCk7XG5jb25zdCBjb25maWcgPSBnZXRDb25maWcoKTtcbmNvbnN0IG1pbmltdW1Db3VudCA9IE1hdGguY2VpbChcbiAgcHJvZmlsZS5yZXF1ZXN0c1BlclNlY29uZCAqIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzICogcHJvZmlsZS5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbixcbik7XG5jb25zdCBleHBlY3RlZENvdW50ID0gcHJvZmlsZS5yZXF1ZXN0c1BlclNlY29uZCAqIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzO1xuY29uc3QgcmVxdWVzdEF0dGVtcHRzID0gbmV3IENvdW50ZXIoJ3JlcXVlc3RfYXR0ZW1wdHMnKTtcblxuZXhwb3J0IGNvbnN0IG9wdGlvbnM6IE9wdGlvbnMgPSB7XG4gIHNjZW5hcmlvczoge1xuICAgIHJlcXVlc3Rfd2FybXVwOiB7XG4gICAgICBleGVjdXRvcjogJ2NvbnN0YW50LWFycml2YWwtcmF0ZScsXG4gICAgICBleGVjOiAnc2luZ2xlUmVxdWVzdCcsXG4gICAgICByYXRlOiBwcm9maWxlLnJlcXVlc3RzUGVyU2Vjb25kLFxuICAgICAgdGltZVVuaXQ6ICcxcycsXG4gICAgICBkdXJhdGlvbjogYCR7cHJvZmlsZS53YXJtdXBTZWNvbmRzfXNgLFxuICAgICAgcHJlQWxsb2NhdGVkVlVzOiBNYXRoLm1pbigyMCwgcHJvZmlsZS5tYXhWdXMpLFxuICAgICAgbWF4VlVzOiBwcm9maWxlLm1heFZ1cyxcbiAgICAgIGdyYWNlZnVsU3RvcDogYCR7UkVRVUVTVF9EUkFJTl9TRUNPTkRTfXNgLFxuICAgIH0sXG4gICAgcmVxdWVzdF9tZWFzdXJlbWVudDoge1xuICAgICAgZXhlY3V0b3I6ICdjb25zdGFudC1hcnJpdmFsLXJhdGUnLFxuICAgICAgZXhlYzogJ3NpbmdsZVJlcXVlc3QnLFxuICAgICAgc3RhcnRUaW1lOiBgJHtwcm9maWxlLndhcm11cFNlY29uZHMgKyAyfXNgLFxuICAgICAgcmF0ZTogcHJvZmlsZS5yZXF1ZXN0c1BlclNlY29uZCxcbiAgICAgIHRpbWVVbml0OiAnMXMnLFxuICAgICAgZHVyYXRpb246IGAke3Byb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzfXNgLFxuICAgICAgcHJlQWxsb2NhdGVkVlVzOiBNYXRoLm1pbigyMCwgcHJvZmlsZS5tYXhWdXMpLFxuICAgICAgbWF4VlVzOiBwcm9maWxlLm1heFZ1cyxcbiAgICAgIGdyYWNlZnVsU3RvcDogYCR7UkVRVUVTVF9EUkFJTl9TRUNPTkRTfXNgLFxuICAgIH0sXG4gIH0sXG4gIC8vIENyZWF0aW5nIHN1Ym1ldHJpY3MgdGhyb3VnaCB0aHJlc2hvbGRzIG1ha2VzIHRoZWlyIGNvdW50IGF2YWlsYWJsZSBpbiB0aGUgbmF0aXZlIHN1bW1hcnkuXG4gIHRocmVzaG9sZHM6IHtcbiAgICAncmVxdWVzdF9hdHRlbXB0c3tzY2VuYXJpbzpyZXF1ZXN0X21lYXN1cmVtZW50fSc6IFtcbiAgICAgIGBjb3VudD49JHttaW5pbXVtQ291bnR9YCxcbiAgICAgIGBjb3VudDw9JHtleHBlY3RlZENvdW50ICsgMX1gLFxuICAgIF0sXG4gICAgJ2h0dHBfcmVxc3tzY2VuYXJpbzpyZXF1ZXN0X21lYXN1cmVtZW50fSc6IFtcbiAgICAgIGBjb3VudD49JHttaW5pbXVtQ291bnR9YCxcbiAgICAgIGBjb3VudDw9JHtleHBlY3RlZENvdW50ICsgMX1gLFxuICAgIF0sXG4gICAgJ2l0ZXJhdGlvbnN7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nOiBbYGNvdW50Pj0ke21pbmltdW1Db3VudH1gXSxcbiAgICAnZHJvcHBlZF9pdGVyYXRpb25ze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9JzogWydjb3VudD09MCddLFxuICAgICdjaGVja3N7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nOiBbJ3JhdGU9PTEnXSxcbiAgICAnaHR0cF9yZXFfZmFpbGVke3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9JzogWydyYXRlPDAuMDEnXSxcbiAgICAnaHR0cF9yZXFfZHVyYXRpb257c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nOiBbJ3AoOTUpPDgwJywgJ3AoOTkpPDE1MCddLFxuICB9LFxuICBtYXhSZWRpcmVjdHM6IDAsXG4gIHN1bW1hcnlUcmVuZFN0YXRzLFxufTtcblxuLyoqIEZpeGVkIDgwLzIwIGFydGljbGVzL3RhZ3MgbWl4LiBEaXJlY3QgSFRUUDogZXhhY3RseSBvbmUgYXR0ZW1wdCwgemVybyByZWRpcmVjdHMsIG5vIHNsZWVwLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNpbmdsZVJlcXVlc3QoKTogdm9pZCB7XG4gIGNvbnN0IHBhdGggPVxuICAgIGV4ZWN1dGlvbi5zY2VuYXJpby5pdGVyYXRpb25JblRlc3QgJSA1ID09PSA0ID8gJy90YWdzJyA6ICcvYXJ0aWNsZXM/bGltaXQ9MTAmb2Zmc2V0PTAnO1xuICByZXF1ZXN0QXR0ZW1wdHMuYWRkKDEpO1xuICBjb25zdCByZXNwb25zZSA9IGh0dHAuZ2V0KGAke2NvbmZpZy5iYXNlVXJsLnJlcGxhY2UoL1xcLyQvLCAnJyl9JHtwYXRofWAsIHtcbiAgICByZWRpcmVjdHM6IDAsXG4gICAgdGltZW91dDogJzFzJyxcbiAgICBoZWFkZXJzOiB7ICdYLUxvYWQtUGhhc2UnOiBleGVjdXRpb24uc2NlbmFyaW8ubmFtZSB9LFxuICAgIHRhZ3M6IHsgLi4uY29uZmlnLnRhZ3MsIG5hbWU6IHBhdGguc3RhcnRzV2l0aCgnL3RhZ3MnKSA/ICdHRVQgL3RhZ3MnIDogJ0dFVCAvYXJ0aWNsZXMnIH0sXG4gIH0pO1xuICBjaGVjayhyZXNwb25zZSwgeyAnc2luZ2xlIHJlcXVlc3Qgc3RhdHVzIGlzIDIwMCc6IChyZXN1bHQpID0+IHJlc3VsdC5zdGF0dXMgPT09IDIwMCB9KTtcbn1cblxuZXhwb3J0IGNvbnN0IGhhbmRsZVN1bW1hcnkgPSBjcmVhdGVTdW1tYXJ5O1xuIiwgImltcG9ydCB0eXBlIHsgRW52Q29uZmlnIH0gZnJvbSAnLi4vLi4vc3JjL3R5cGVzL2NvbmZpZy50eXBlcyc7XG5cbmV4cG9ydCBjb25zdCBsb2NhbENvbmZpZzogRW52Q29uZmlnID0ge1xuICBlbnZpcm9ubWVudDogJ2xvY2FsJyxcbiAgYmFzZVVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGknLFxuICB0aW1lb3V0czogeyBodHRwOiAzMF8wMDAgfSxcbiAgYXJyaXZhbDogeyBpdGVyYXRpb25zUGVyU2Vjb25kOiAyMCwgbWF4VnVzOiAxMDAgfSxcbiAgdGFnczogeyBlbnY6ICdsb2NhbCcsIGFwcDogJ2NvbmR1aXQnIH0sXG4gIGFsbG93c1dyaXRlczogdHJ1ZSxcbn07XG4iLCAiaW1wb3J0IHR5cGUgeyBFbnZDb25maWcgfSBmcm9tICcuLi8uLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzJztcblxuLyoqXG4gKiBDcmVhdGVzIGEgcmVhZC1vbmx5IHByb2R1Y3Rpb24gdGFyZ2V0IGNvbmZpZ3VyYXRpb24uXG4gKiBAcGFyYW0gYmFzZVVybCBFeHBsaWNpdCBhdXRob3JpemVkIHByb2R1Y3Rpb24gVVJMLlxuICogQHJldHVybnMgUHJvZHVjdGlvbiBlbnZpcm9ubWVudCBjb25maWd1cmF0aW9uLlxuICogQHRocm93cyBXaGVuIG5vIHByb2R1Y3Rpb24gVVJMIGlzIHN1cHBsaWVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcHJvZHVjdGlvbkNvbmZpZyhiYXNlVXJsOiBzdHJpbmcgfCB1bmRlZmluZWQpOiBFbnZDb25maWcge1xuICBpZiAoIWJhc2VVcmwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0JBU0VfVVJMIGlzIHJlcXVpcmVkIHdoZW4gVEFSR0VUX0VOViBpcyBcInByb2R1Y3Rpb25cIicpO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBlbnZpcm9ubWVudDogJ3Byb2R1Y3Rpb24nLFxuICAgIGJhc2VVcmwsXG4gICAgdGltZW91dHM6IHsgaHR0cDogMzBfMDAwIH0sXG4gICAgYXJyaXZhbDogeyBpdGVyYXRpb25zUGVyU2Vjb25kOiAxMCwgbWF4VnVzOiA1MCB9LFxuICAgIHRhZ3M6IHsgZW52OiAncHJvZHVjdGlvbicsIGFwcDogJ2NvbmR1aXQnIH0sXG4gICAgYWxsb3dzV3JpdGVzOiBmYWxzZSxcbiAgfTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IEVudkNvbmZpZyB9IGZyb20gJy4uLy4uL3NyYy90eXBlcy9jb25maWcudHlwZXMnO1xuXG5leHBvcnQgY29uc3Qgc3RhZ2luZ0NvbmZpZzogRW52Q29uZmlnID0ge1xuICBlbnZpcm9ubWVudDogJ3N0YWdpbmcnLFxuICBiYXNlVXJsOiAnaHR0cHM6Ly9hcGkucmVhbHdvcmxkLnNob3cvYXBpJyxcbiAgdGltZW91dHM6IHsgaHR0cDogMzBfMDAwIH0sXG4gIGFycml2YWw6IHsgaXRlcmF0aW9uc1BlclNlY29uZDogNTAsIG1heFZ1czogNDAwIH0sXG4gIHRhZ3M6IHsgZW52OiAnc3RhZ2luZycsIGFwcDogJ2NvbmR1aXQnIH0sXG4gIGFsbG93c1dyaXRlczogZmFsc2UsXG59O1xuIiwgImltcG9ydCB7IGxvY2FsQ29uZmlnIH0gZnJvbSAnLi9lbnZpcm9ubWVudHMvbG9jYWwnO1xuaW1wb3J0IHsgcHJvZHVjdGlvbkNvbmZpZyB9IGZyb20gJy4vZW52aXJvbm1lbnRzL3Byb2R1Y3Rpb24nO1xuaW1wb3J0IHsgc3RhZ2luZ0NvbmZpZyB9IGZyb20gJy4vZW52aXJvbm1lbnRzL3N0YWdpbmcnO1xuaW1wb3J0IHR5cGUgeyBFbnZpcm9ubWVudE5hbWUsIEVudkNvbmZpZyB9IGZyb20gJy4uL3NyYy90eXBlcy9jb25maWcudHlwZXMnO1xuXG5jb25zdCBjb25maWdzOiBSZWNvcmQ8RXhjbHVkZTxFbnZpcm9ubWVudE5hbWUsICdwcm9kdWN0aW9uJz4sIEVudkNvbmZpZz4gPSB7XG4gIGxvY2FsOiBsb2NhbENvbmZpZyxcbiAgc3RhZ2luZzogc3RhZ2luZ0NvbmZpZyxcbn07XG5cbi8qKlxuICogUmVzb2x2ZXMgYW5kIHZhbGlkYXRlcyB0aGUgc2VsZWN0ZWQgdGFyZ2V0IGVudmlyb25tZW50IGF0IGs2IGluaXRpYWxpemF0aW9uIHRpbWUuXG4gKiBAcGFyYW0gZW52IFRhcmdldCBlbnZpcm9ubWVudCBuYW1lLlxuICogQHJldHVybnMgVmFsaWRhdGVkIGVudmlyb25tZW50IGNvbmZpZ3VyYXRpb24uXG4gKiBAdGhyb3dzIFdoZW4gdGhlIGVudmlyb25tZW50IG5hbWUgaXMgdW5rbm93biBvciByZXF1aXJlZCBwcm9kdWN0aW9uIHNldHRpbmdzIGFyZSBhYnNlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb25maWcoZW52OiBzdHJpbmcgPSBfX0VOVi5UQVJHRVRfRU5WID8/ICdsb2NhbCcpOiBFbnZDb25maWcge1xuICBpZiAoZW52ID09PSAncHJvZHVjdGlvbicpIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4ucHJvZHVjdGlvbkNvbmZpZyhfX0VOVi5CQVNFX1VSTCksXG4gICAgICBhbGxvd3NXcml0ZXM6IF9fRU5WLkFMTE9XX05PTl9MT0NBTF9MT0FEID09PSAndHJ1ZScsXG4gICAgfTtcbiAgfVxuXG4gIGlmIChlbnYgPT09ICdsb2NhbCcgfHwgZW52ID09PSAnc3RhZ2luZycpIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uY29uZmlnc1tlbnZdLFxuICAgICAgYmFzZVVybDogX19FTlYuQkFTRV9VUkwgPz8gY29uZmlnc1tlbnZdLmJhc2VVcmwsXG4gICAgICBhbGxvd3NXcml0ZXM6XG4gICAgICAgIGVudiA9PT0gJ3N0YWdpbmcnID8gX19FTlYuQUxMT1dfTk9OX0xPQ0FMX0xPQUQgPT09ICd0cnVlJyA6IGNvbmZpZ3NbZW52XS5hbGxvd3NXcml0ZXMsXG4gICAgfTtcbiAgfVxuXG4gIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBUQVJHRVRfRU5WOiBcIiR7ZW52fVwiYCk7XG59XG4iLCAiaW1wb3J0IHsgZ2V0Q29uZmlnIH0gZnJvbSAnLic7XG4vLyBBIHNpbmdsZSByZXF1ZXN0IGhhcyBhIDFzIHRpbWVvdXQ7IGFsbG93IGNvbXBsZXRpb24gYW5kIG1ldHJpYyByZWNvcmRpbmcgYmVmb3JlIHNodXRkb3duLlxuZXhwb3J0IGNvbnN0IFJFUVVFU1RfRFJBSU5fU0VDT05EUyA9IDI7XG5pbXBvcnQgdHlwZSB7XG4gIEVudmlyb25tZW50TmFtZSxcbiAgU3RhZ2VkV29ya2xvYWQsXG4gIFdvcmtsb2FkUHJvZmlsZSxcbiAgV29ya2xvYWRTY2VuYXJpbyxcbiAgV29ya2xvYWRTdGFnZSxcbn0gZnJvbSAnLi4vc3JjL3R5cGVzL2NvbmZpZy50eXBlcyc7XG5cbmNvbnN0IGZ1bGxQcm9maWxlczogUGFydGlhbDxSZWNvcmQ8RW52aXJvbm1lbnROYW1lLCBSZWNvcmQ8U3RhZ2VkV29ya2xvYWQsIFdvcmtsb2FkU3RhZ2VbXT4+PiA9IHtcbiAgbG9jYWw6IHtcbiAgICBhdXRoZW50aWNhdGVkTG9hZDogW1xuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiA1IH0sXG4gICAgICB7IGR1cmF0aW9uOiAnNW0nLCB0YXJnZXQ6IDUgfSxcbiAgICAgIHsgZHVyYXRpb246ICcxbScsIHRhcmdldDogMCB9LFxuICAgIF0sXG4gICAgYXV0aGVudGljYXRlZFN0cmVzczogW1xuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiA1IH0sXG4gICAgICB7IGR1cmF0aW9uOiAnNW0nLCB0YXJnZXQ6IDIwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDAgfSxcbiAgICBdLFxuICAgIHN0cmVzczogW1xuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiAyNSB9LFxuICAgICAgeyBkdXJhdGlvbjogJzNtJywgdGFyZ2V0OiA1MCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzNtJywgdGFyZ2V0OiAxMDAgfSxcbiAgICAgIHsgZHVyYXRpb246ICczbScsIHRhcmdldDogMTUwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDAgfSxcbiAgICBdLFxuICAgIHNwaWtlOiBbXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDEwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMzBzJywgdGFyZ2V0OiAyMDAgfSxcbiAgICAgIHsgZHVyYXRpb246ICcxbScsIHRhcmdldDogMjAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMzBzJywgdGFyZ2V0OiAxMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzNtJywgdGFyZ2V0OiAxMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzFtJywgdGFyZ2V0OiAwIH0sXG4gICAgXSxcbiAgICBzb2FrOiBbXG4gICAgICB7IGR1cmF0aW9uOiAnNW0nLCB0YXJnZXQ6IDIwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMmgnLCB0YXJnZXQ6IDIwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnNW0nLCB0YXJnZXQ6IDAgfSxcbiAgICBdLFxuICAgIGJyZWFrcG9pbnQ6IFtcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogNTAgfSxcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogMTAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDIwMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiA0MDAgfSxcbiAgICAgIHsgZHVyYXRpb246ICcxbScsIHRhcmdldDogNDAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMW0nLCB0YXJnZXQ6IDAgfSxcbiAgICBdLFxuICB9LFxufTtcblxuY29uc3QgdmFsaWRhdGlvblByb2ZpbGVzOiBSZWNvcmQ8U3RhZ2VkV29ya2xvYWQsIFdvcmtsb2FkU3RhZ2VbXT4gPSB7XG4gIGF1dGhlbnRpY2F0ZWRMb2FkOiBbXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAxIH0sXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAwIH0sXG4gIF0sXG4gIGF1dGhlbnRpY2F0ZWRTdHJlc3M6IFtcbiAgICB7IGR1cmF0aW9uOiAnNXMnLCB0YXJnZXQ6IDEgfSxcbiAgICB7IGR1cmF0aW9uOiAnNXMnLCB0YXJnZXQ6IDAgfSxcbiAgXSxcbiAgc3RyZXNzOiBbXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiA1IH0sXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAwIH0sXG4gIF0sXG4gIHNwaWtlOiBbXG4gICAgeyBkdXJhdGlvbjogJzNzJywgdGFyZ2V0OiAyIH0sXG4gICAgeyBkdXJhdGlvbjogJzNzJywgdGFyZ2V0OiAyMCB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMiB9LFxuICBdLFxuICBzb2FrOiBbXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAyIH0sXG4gICAgeyBkdXJhdGlvbjogJzEwcycsIHRhcmdldDogMiB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMCB9LFxuICBdLFxuICBicmVha3BvaW50OiBbXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiA1IH0sXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAyMCB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMCB9LFxuICBdLFxufTtcblxuZnVuY3Rpb24gcG9zaXRpdmVOdW1iZXIobmFtZTogc3RyaW5nLCBmYWxsYmFjazogbnVtYmVyKTogbnVtYmVyIHtcbiAgY29uc3QgcmF3ID0gX19FTlZbbmFtZV07XG4gIGlmIChyYXcgPT09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbGxiYWNrO1xuICBjb25zdCB2YWx1ZSA9IE51bWJlcihyYXcpO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgfHwgdmFsdWUgPD0gMCkge1xuICAgIHRocm93IG5ldyBFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyYCk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuXG5mdW5jdGlvbiByZWplY3RMZWdhY3lSYXRlKCk6IHZvaWQge1xuICBpZiAoX19FTlYuVEFSR0VUX1JQUyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ1RBUkdFVF9SUFMgaXMgYW1iaWd1b3VzIGFuZCBoYXMgYmVlbiByZW1vdmVkLiBGb3IgdGhlIGV4aXN0aW5nIGpvdXJuZXkgdXNlICcgK1xuICAgICAgICAnVEFSR0VUX0lURVJBVElPTlNfUEVSX1NFQ09ORCAob2xkIGFycml2YWwtaXRlcmF0aW9uIHNlbWFudGljcyk7IGZvciBvbmUgcmVxdWVzdCBwZXIgJyArXG4gICAgICAgICdpdGVyYXRpb24gdXNlIFJFUVVFU1RTX1BFUl9TRUNPTkQgd2l0aCB0aGUgZGVkaWNhdGVkIHJlcXVlc3QtcmF0ZSBlbnRyeSBwb2ludC4nLFxuICAgICk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcG9zaXRpdmVJbnRlZ2VyKG5hbWU6IHN0cmluZywgZmFsbGJhY2s6IG51bWJlcik6IG51bWJlciB7XG4gIGNvbnN0IHZhbHVlID0gcG9zaXRpdmVOdW1iZXIobmFtZSwgZmFsbGJhY2spO1xuICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKHZhbHVlKSkgdGhyb3cgbmV3IEVycm9yKGAke25hbWV9IG11c3QgYmUgYSBwb3NpdGl2ZSBzYWZlIGludGVnZXJgKTtcbiAgcmV0dXJuIHZhbHVlO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJlcXVlc3RSYXRlUHJvZmlsZSB7XG4gIHJlcXVlc3RzUGVyU2Vjb25kOiBudW1iZXI7XG4gIG1heFZ1czogbnVtYmVyO1xuICB3YXJtdXBTZWNvbmRzOiBudW1iZXI7XG4gIG1lYXN1cmVtZW50U2Vjb25kczogbnVtYmVyO1xuICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbjogbnVtYmVyO1xufVxuXG4vKiogT25lIEhUVFAgcmVxdWVzdCBwZXIgYXJyaXZhbDsgZHVyYXRpb25zIGFuZCBhY2NlcHRhbmNlIGZpeGVkIGJlZm9yZSBleGVjdXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0UmVxdWVzdFJhdGVQcm9maWxlKCk6IFJlcXVlc3RSYXRlUHJvZmlsZSB7XG4gIHJlamVjdExlZ2FjeVJhdGUoKTtcbiAgY29uc3QgbWluaW11bUFjaGlldmVkRnJhY3Rpb24gPSBwb3NpdGl2ZU51bWJlcignTUlOSU1VTV9BQ0hJRVZFRF9GUkFDVElPTicsIDAuOTgpO1xuICBpZiAobWluaW11bUFjaGlldmVkRnJhY3Rpb24gPiAxKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdNSU5JTVVNX0FDSElFVkVEX0ZSQUNUSU9OIG11c3QgYmUgYXQgbW9zdCAxJyk7XG4gIH1cbiAgY29uc3QgcHJvZmlsZSA9IHtcbiAgICByZXF1ZXN0c1BlclNlY29uZDogcG9zaXRpdmVJbnRlZ2VyKCdSRVFVRVNUU19QRVJfU0VDT05EJywgNTAwKSxcbiAgICBtYXhWdXM6IHBvc2l0aXZlSW50ZWdlcignTUFYX1ZVUycsIDEwMCksXG4gICAgd2FybXVwU2Vjb25kczogcG9zaXRpdmVJbnRlZ2VyKCdXQVJNVVBfU0VDT05EUycsIDEwKSxcbiAgICBtZWFzdXJlbWVudFNlY29uZHM6IHBvc2l0aXZlSW50ZWdlcignTUVBU1VSRU1FTlRfU0VDT05EUycsIDYwKSxcbiAgICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbixcbiAgfTtcbiAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihwcm9maWxlLnJlcXVlc3RzUGVyU2Vjb25kICogcHJvZmlsZS5tZWFzdXJlbWVudFNlY29uZHMpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdDb25maWd1cmVkIG1lYXN1cmVtZW50IHJlcXVlc3QgY291bnQgZXhjZWVkcyBzYWZlIGludGVnZXIgcmFuZ2UnKTtcbiAgfVxuICByZXR1cm4gcHJvZmlsZTtcbn1cblxuLyoqXG4gKiBSZXNvbHZlcyBib3VuZGVkIHdvcmtsb2FkIGNvbnRyb2xzIGZyb20gZW52aXJvbm1lbnQgdmFyaWFibGVzIGFuZCB0YXJnZXQgZGVmYXVsdHMuXG4gKiBAcmV0dXJucyBWYWxpZGF0ZWQgd29ya2xvYWQgcHJvZmlsZS5cbiAqIEB0aHJvd3MgV2hlbiBhIG51bWVyaWMgd29ya2xvYWQgb3ZlcnJpZGUgaXMgbm90IHBvc2l0aXZlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0V29ya2xvYWRQcm9maWxlKCk6IFdvcmtsb2FkUHJvZmlsZSB7XG4gIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZygpO1xuICByZWplY3RMZWdhY3lSYXRlKCk7XG4gIHJldHVybiB7XG4gICAgdmFsaWRhdGlvbjogX19FTlYuVEVTVF9QUk9GSUxFID09PSAndmFsaWRhdGlvbicsXG4gICAgdGFyZ2V0SXRlcmF0aW9uc1BlclNlY29uZDogcG9zaXRpdmVJbnRlZ2VyKFxuICAgICAgJ1RBUkdFVF9JVEVSQVRJT05TX1BFUl9TRUNPTkQnLFxuICAgICAgY29uZmlnLmFycml2YWwuaXRlcmF0aW9uc1BlclNlY29uZCxcbiAgICApLFxuICAgIG1heFZ1czogcG9zaXRpdmVJbnRlZ2VyKCdNQVhfVlVTJywgY29uZmlnLmFycml2YWwubWF4VnVzKSxcbiAgICB0aGlua1RpbWVTZWNvbmRzOiBwb3NpdGl2ZU51bWJlcignVEhJTktfVElNRV9TRUNPTkRTJywgMSksXG4gIH07XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgYSB0eXBlZCBzdGFnZSBwcm9maWxlIGZvciB0aGUgc2VsZWN0ZWQgZW52aXJvbm1lbnQgYW5kIHRlc3QgcHJvZmlsZS5cbiAqIEEgd29ya2xvYWQgY2FuIGJlIG92ZXJyaWRkZW4gd2l0aCBhIEpTT04gYXJyYXkgaW4gaXRzIGRlcml2ZWQgZW52aXJvbm1lbnQgdmFyaWFibGUsIHN1Y2ggYXNcbiAqIGBTVFJFU1NfU1RBR0VTYCBvciBgQVVUSEVOVElDQVRFRF9MT0FEX1NUQUdFU2AuXG4gKiBAcGFyYW0gd29ya2xvYWQgTmFtZWQgc3RhZ2VkIHdvcmtsb2FkLlxuICogQHJldHVybnMgVmFsaWRhdGVkIGR1cmF0aW9uL3RhcmdldCBzdGFnZXMuXG4gKiBAdGhyb3dzIFdoZW4gYW4gb3ZlcnJpZGUgaXMgaW52YWxpZCBKU09OIG9yIGlzIG5vdCBhIG5vbi1lbXB0eSBkdXJhdGlvbi90YXJnZXQgYXJyYXkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRXb3JrbG9hZFN0YWdlcyh3b3JrbG9hZDogU3RhZ2VkV29ya2xvYWQpOiBXb3JrbG9hZFN0YWdlW10ge1xuICBjb25zdCBvdmVycmlkZU5hbWUgPVxuICAgIGAke3dvcmtsb2FkLnJlcGxhY2UoL1tBLVpdL2csIChsZXR0ZXIpID0+IGBfJHtsZXR0ZXJ9YCl9X1NUQUdFU2AudG9VcHBlckNhc2UoKTtcbiAgY29uc3QgcmF3ID0gX19FTlZbb3ZlcnJpZGVOYW1lXTtcbiAgaWYgKHJhdykge1xuICAgIGxldCBzdGFnZXM6IHVua25vd247XG4gICAgdHJ5IHtcbiAgICAgIHN0YWdlcyA9IEpTT04ucGFyc2UocmF3KSBhcyB1bmtub3duO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGAke292ZXJyaWRlTmFtZX0gbXVzdCBjb250YWluIHZhbGlkIEpTT05gKTtcbiAgICB9XG4gICAgaWYgKFxuICAgICAgIUFycmF5LmlzQXJyYXkoc3RhZ2VzKSB8fFxuICAgICAgc3RhZ2VzLmxlbmd0aCA9PT0gMCB8fFxuICAgICAgc3RhZ2VzLnNvbWUoXG4gICAgICAgIChzdGFnZSkgPT5cbiAgICAgICAgICB0eXBlb2Ygc3RhZ2UgIT09ICdvYmplY3QnIHx8XG4gICAgICAgICAgc3RhZ2UgPT09IG51bGwgfHxcbiAgICAgICAgICB0eXBlb2YgKHN0YWdlIGFzIFdvcmtsb2FkU3RhZ2UpLmR1cmF0aW9uICE9PSAnc3RyaW5nJyB8fFxuICAgICAgICAgICFOdW1iZXIuaXNJbnRlZ2VyKChzdGFnZSBhcyBXb3JrbG9hZFN0YWdlKS50YXJnZXQpIHx8XG4gICAgICAgICAgKHN0YWdlIGFzIFdvcmtsb2FkU3RhZ2UpLnRhcmdldCA8IDAsXG4gICAgICApXG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7b3ZlcnJpZGVOYW1lfSBtdXN0IGJlIGEgbm9uLWVtcHR5IEpTT04gYXJyYXkgb2YgZHVyYXRpb24vdGFyZ2V0IHN0YWdlc2ApO1xuICAgIH1cbiAgICByZXR1cm4gc3RhZ2VzIGFzIFdvcmtsb2FkU3RhZ2VbXTtcbiAgfVxuICBjb25zdCBjb25maWcgPSBnZXRDb25maWcoKTtcbiAgaWYgKF9fRU5WLlRFU1RfUFJPRklMRSA9PT0gJ3ZhbGlkYXRpb24nKSByZXR1cm4gdmFsaWRhdGlvblByb2ZpbGVzW3dvcmtsb2FkXTtcbiAgY29uc3QgZW52aXJvbm1lbnRQcm9maWxlID0gZnVsbFByb2ZpbGVzW2NvbmZpZy5lbnZpcm9ubWVudF07XG4gIGlmICghZW52aXJvbm1lbnRQcm9maWxlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYEZ1bGwgJHt3b3JrbG9hZH0gcHJvZmlsZSBpcyBub3QgZGVmaW5lZCBmb3IgJHtjb25maWcuZW52aXJvbm1lbnR9OyBwcm92aWRlICR7b3ZlcnJpZGVOYW1lfWAsXG4gICAgKTtcbiAgfVxuICByZXR1cm4gZW52aXJvbm1lbnRQcm9maWxlW3dvcmtsb2FkXTtcbn1cblxuLyoqXG4gKiBCdWlsZHMgYSByYW1waW5nLVZVIHNjZW5hcmlvLlxuICogQHBhcmFtIHN0YWdlcyBWVSB0YXJnZXRzIGFuZCBkdXJhdGlvbnMuXG4gKiBAcGFyYW0gZ3JhY2VmdWxTdG9wIEdyYWNlIHBlcmlvZCBmb3IgaW50ZXJydXB0ZWQgaXRlcmF0aW9ucy5cbiAqIEByZXR1cm5zIEEgazYgcmFtcGluZy12dXMgc2NlbmFyaW8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByYW1waW5nVnVzKFxuICBzdGFnZXM6IEFycmF5PHsgZHVyYXRpb246IHN0cmluZzsgdGFyZ2V0OiBudW1iZXIgfT4sXG4gIGdyYWNlZnVsU3RvcCA9ICczMHMnLFxuKTogV29ya2xvYWRTY2VuYXJpbyB7XG4gIHJldHVybiB7XG4gICAgZXhlY3V0b3I6ICdyYW1waW5nLXZ1cycsXG4gICAgc3RhcnRWVXM6IDAsXG4gICAgc3RhZ2VzLFxuICAgIGdyYWNlZnVsUmFtcERvd246IGdyYWNlZnVsU3RvcCxcbiAgICBncmFjZWZ1bFN0b3AsXG4gIH07XG59XG5cbi8qKlxuICogQnVpbGRzIGEgZml4ZWQgcGVyLVZVIGl0ZXJhdGlvbiBzY2VuYXJpby5cbiAqIEBwYXJhbSB2dXMgTnVtYmVyIG9mIHZpcnR1YWwgdXNlcnMuXG4gKiBAcGFyYW0gaXRlcmF0aW9ucyBJdGVyYXRpb25zIHBlciB2aXJ0dWFsIHVzZXIuXG4gKiBAcGFyYW0gbWF4RHVyYXRpb24gTWF4aW11bSBzY2VuYXJpbyBkdXJhdGlvbi5cbiAqIEBwYXJhbSBncmFjZWZ1bFN0b3AgR3JhY2UgcGVyaW9kIGZvciBpbnRlcnJ1cHRlZCBpdGVyYXRpb25zLlxuICogQHJldHVybnMgQSBrNiBwZXItdnUtaXRlcmF0aW9ucyBzY2VuYXJpby5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBlclZ1SXRlcmF0aW9ucyhcbiAgdnVzOiBudW1iZXIsXG4gIGl0ZXJhdGlvbnM6IG51bWJlcixcbiAgbWF4RHVyYXRpb246IHN0cmluZyxcbiAgZ3JhY2VmdWxTdG9wID0gJzEwcycsXG4pOiBXb3JrbG9hZFNjZW5hcmlvIHtcbiAgcmV0dXJuIHsgZXhlY3V0b3I6ICdwZXItdnUtaXRlcmF0aW9ucycsIHZ1cywgaXRlcmF0aW9ucywgbWF4RHVyYXRpb24sIGdyYWNlZnVsU3RvcCB9O1xufVxuXG4vKipcbiAqIEJ1aWxkcyBhIGJvdW5kZWQgY29uc3RhbnQtYXJyaXZhbC1yYXRlIHNjZW5hcmlvLlxuICogQHBhcmFtIHByb2ZpbGUgUmVzb2x2ZWQgd29ya2xvYWQgbGltaXRzLlxuICogQHBhcmFtIGR1cmF0aW9uIFNjZW5hcmlvIGR1cmF0aW9uLlxuICogQHJldHVybnMgQSBrNiBjb25zdGFudC1hcnJpdmFsLXJhdGUgc2NlbmFyaW8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb25zdGFudEFycml2YWxSYXRlKHByb2ZpbGU6IFdvcmtsb2FkUHJvZmlsZSwgZHVyYXRpb246IHN0cmluZyk6IFdvcmtsb2FkU2NlbmFyaW8ge1xuICByZXR1cm4ge1xuICAgIGV4ZWN1dG9yOiAnY29uc3RhbnQtYXJyaXZhbC1yYXRlJyxcbiAgICByYXRlOiBwcm9maWxlLnRhcmdldEl0ZXJhdGlvbnNQZXJTZWNvbmQsXG4gICAgdGltZVVuaXQ6ICcxcycsXG4gICAgZHVyYXRpb24sXG4gICAgcHJlQWxsb2NhdGVkVlVzOiBNYXRoLm1pbigyMCwgcHJvZmlsZS5tYXhWdXMpLFxuICAgIG1heFZVczogcHJvZmlsZS5tYXhWdXMsXG4gICAgZ3JhY2VmdWxTdG9wOiAnMzBzJyxcbiAgfTtcbn1cbiIsICJpbXBvcnQgeyBTaGFyZWRBcnJheSB9IGZyb20gJ2s2L2RhdGEnO1xuXG5jb25zdCB0b2tlbnMgPSBuZXcgU2hhcmVkQXJyYXk8c3RyaW5nPigndXNlciB0b2tlbnMnLCAoKSA9PiB7XG4gIGNvbnN0IHJhdyA9IF9fRU5WLks2X1VTRVJfVE9LRU5TO1xuICBpZiAoIXJhdykgcmV0dXJuIFtdO1xuICBjb25zdCBwYXJzZWQ6IHVua25vd24gPSBKU09OLnBhcnNlKHJhdyk7XG4gIGlmICghQXJyYXkuaXNBcnJheShwYXJzZWQpIHx8ICFwYXJzZWQuZXZlcnkoKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignSzZfVVNFUl9UT0tFTlMgbXVzdCBiZSBhIEpTT04gYXJyYXkgb2Ygc3RyaW5ncycpO1xuICB9XG4gIHJldHVybiBwYXJzZWQ7XG59KTtcblxuLyoqXG4gKiBTZWxlY3RzIGEgc2hhcmVkIGF1dGhlbnRpY2F0aW9uIHRva2VuIGRldGVybWluaXN0aWNhbGx5IGZvciBhIHZpcnR1YWwgdXNlci5cbiAqIEBwYXJhbSB2dSBrNiB2aXJ0dWFsLXVzZXIgbnVtYmVyLlxuICogQHJldHVybnMgVGhlIHRva2VuIGFzc2lnbmVkIHRvIHRoZSB2aXJ0dWFsIHVzZXIuXG4gKiBAdGhyb3dzIFdoZW4gbm8gdmFsaWQgdG9rZW4gYXJyYXkgd2FzIHByb3ZpZGVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdG9rZW5Gb3JWdSh2dSA9IF9fVlUpOiBzdHJpbmcge1xuICBpZiAodG9rZW5zLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdLNl9VU0VSX1RPS0VOUyBpcyByZXF1aXJlZCBmb3IgYXV0aGVudGljYXRlZCB0ZXN0cycpO1xuICByZXR1cm4gdG9rZW5zWyh2dSAtIDEpICUgdG9rZW5zLmxlbmd0aF0hO1xufVxuIiwgImltcG9ydCB7IGNoZWNrIH0gZnJvbSAnazYnO1xuaW1wb3J0IHR5cGUgeyBIdHRwUmVzcG9uc2UgfSBmcm9tICcuLi90eXBlcyc7XG5cbi8qKlxuICogUmVjb3JkcyBhIG5hbWVkIGs2IHN0YXR1cyBjaGVjay5cbiAqIEBwYXJhbSByZXNwb25zZSBUeXBlZCBIVFRQIHJlc3BvbnNlLlxuICogQHBhcmFtIGV4cGVjdGVkIEV4cGVjdGVkIEhUVFAgc3RhdHVzLlxuICogQHBhcmFtIGxhYmVsIEh1bWFuLXJlYWRhYmxlIG9wZXJhdGlvbiBsYWJlbC5cbiAqIEByZXR1cm5zIFdoZXRoZXIgdGhlIHJlc3BvbnNlIG1hdGNoZWQgdGhlIGV4cGVjdGVkIHN0YXR1cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrU3RhdHVzPFQ+KFxuICByZXNwb25zZTogSHR0cFJlc3BvbnNlPFQ+LFxuICBleHBlY3RlZDogbnVtYmVyLFxuICBsYWJlbDogc3RyaW5nLFxuKTogYm9vbGVhbiB7XG4gIHJldHVybiBjaGVjayhyZXNwb25zZS5yYXcsIHtcbiAgICBbYCR7bGFiZWx9OiBzdGF0dXMgJHtleHBlY3RlZH1gXTogKCkgPT4gcmVzcG9uc2Uuc3RhdHVzID09PSBleHBlY3RlZCxcbiAgfSk7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgcGFyc2VkIHJlc3BvbnNlIGJvZHkuXG4gKiBAcGFyYW0gcmVzcG9uc2UgVHlwZWQgSFRUUCByZXNwb25zZS5cbiAqIEBwYXJhbSBsYWJlbCBIdW1hbi1yZWFkYWJsZSBvcGVyYXRpb24gbGFiZWwuXG4gKiBAcmV0dXJucyBUaGUgcGFyc2VkIHJlc3BvbnNlIGJvZHkuXG4gKiBAdGhyb3dzIFdoZW4gdGhlIHJlc3BvbnNlIGhhcyBubyBKU09OIGJvZHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXF1aXJlRGF0YTxUPihyZXNwb25zZTogSHR0cFJlc3BvbnNlPFQ+LCBsYWJlbDogc3RyaW5nKTogVCB7XG4gIGlmIChyZXNwb25zZS5kYXRhID09PSBudWxsKSB0aHJvdyBuZXcgRXJyb3IoYCR7bGFiZWx9IHJldHVybmVkIG5vIEpTT04gYm9keWApO1xuICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcbn1cbiIsICJpbXBvcnQgeyBzbGVlcCB9IGZyb20gJ2s2JztcbmltcG9ydCBodHRwLCB7IHR5cGUgUGFyYW1zLCB0eXBlIFJlcXVlc3RCb2R5LCB0eXBlIFJlc3BvbnNlIH0gZnJvbSAnazYvaHR0cCc7XG5pbXBvcnQgeyBnZXRDb25maWcgfSBmcm9tICcuLi8uLi9jb25maWcnO1xuaW1wb3J0IHR5cGUgeyBIdHRwTWV0aG9kLCBIdHRwUmVxdWVzdE9wdGlvbnMsIEh0dHBSZXNwb25zZSB9IGZyb20gJy4uL3R5cGVzL2FwaS50eXBlcyc7XG5pbXBvcnQgdHlwZSB7IEJ1c2luZXNzTWV0cmljR3JvdXAgfSBmcm9tICcuLi90eXBlcy9hcGkudHlwZXMnO1xuaW1wb3J0IHR5cGUgeyBFbnZDb25maWcgfSBmcm9tICcuLi90eXBlcy9jb25maWcudHlwZXMnO1xuaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInO1xuaW1wb3J0IHtcbiAgYXJ0aWNsZVJlYWREdXJhdGlvbixcbiAgYXJ0aWNsZVJlYWRTdWNjZXNzUmF0ZSxcbiAgYXJ0aWNsZVdyaXRlRHVyYXRpb24sXG4gIGFydGljbGVXcml0ZVN1Y2Nlc3NSYXRlLFxuICBhdXRoRHVyYXRpb24sXG4gIGF1dGhTdWNjZXNzUmF0ZSxcbiAgY29tbWVudER1cmF0aW9uLFxuICBjb21tZW50U3VjY2Vzc1JhdGUsXG4gIHByb2ZpbGVEdXJhdGlvbixcbiAgcHJvZmlsZVN1Y2Nlc3NSYXRlLFxuICB0YWdEdXJhdGlvbixcbiAgdGFnU3VjY2Vzc1JhdGUsXG4gIHRvdGFsQnVzaW5lc3NFcnJvcnMsXG59IGZyb20gJy4vbWV0cmljcyc7XG5cbmNvbnN0IHNhZmVSZXRyeU1ldGhvZHMgPSBuZXcgU2V0PEh0dHBNZXRob2Q+KFsnR0VUJywgJ0hFQUQnLCAnUFVUJywgJ0RFTEVURSddKTtcbmNvbnN0IHdyaXRlTWV0aG9kcyA9IG5ldyBTZXQ8SHR0cE1ldGhvZD4oWydQT1NUJywgJ1BVVCcsICdQQVRDSCcsICdERUxFVEUnXSk7XG5cbmZ1bmN0aW9uIGpvaW5VcmwoYmFzZVVybDogc3RyaW5nLCBwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gYCR7YmFzZVVybC5yZXBsYWNlKC9cXC8rJC8sICcnKX0vJHtwYXRoLnJlcGxhY2UoL15cXC8rLywgJycpfWA7XG59XG5cbmZ1bmN0aW9uIHBhcnNlSnNvbjxUPihyZXNwb25zZTogUmVzcG9uc2UpOiBUIHwgbnVsbCB7XG4gIGlmICghcmVzcG9uc2UuYm9keSkgcmV0dXJuIG51bGw7XG4gIHRyeSB7XG4gICAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKSBhcyBUO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5jb25zdCBtZXRyaWNSZWNvcmRlcnM6IFJlY29yZDxcbiAgQnVzaW5lc3NNZXRyaWNHcm91cCxcbiAgeyBkdXJhdGlvbjogdHlwZW9mIGF1dGhEdXJhdGlvbjsgc3VjY2VzczogdHlwZW9mIGF1dGhTdWNjZXNzUmF0ZSB9XG4+ID0ge1xuICBhdXRoZW50aWNhdGlvbjogeyBkdXJhdGlvbjogYXV0aER1cmF0aW9uLCBzdWNjZXNzOiBhdXRoU3VjY2Vzc1JhdGUgfSxcbiAgJ2FydGljbGUtcmVhZCc6IHsgZHVyYXRpb246IGFydGljbGVSZWFkRHVyYXRpb24sIHN1Y2Nlc3M6IGFydGljbGVSZWFkU3VjY2Vzc1JhdGUgfSxcbiAgJ2FydGljbGUtd3JpdGUnOiB7IGR1cmF0aW9uOiBhcnRpY2xlV3JpdGVEdXJhdGlvbiwgc3VjY2VzczogYXJ0aWNsZVdyaXRlU3VjY2Vzc1JhdGUgfSxcbiAgY29tbWVudDogeyBkdXJhdGlvbjogY29tbWVudER1cmF0aW9uLCBzdWNjZXNzOiBjb21tZW50U3VjY2Vzc1JhdGUgfSxcbiAgcHJvZmlsZTogeyBkdXJhdGlvbjogcHJvZmlsZUR1cmF0aW9uLCBzdWNjZXNzOiBwcm9maWxlU3VjY2Vzc1JhdGUgfSxcbiAgdGFnOiB7IGR1cmF0aW9uOiB0YWdEdXJhdGlvbiwgc3VjY2VzczogdGFnU3VjY2Vzc1JhdGUgfSxcbn07XG5cbmZ1bmN0aW9uIHJlY29yZEJ1c2luZXNzTWV0cmljcyhcbiAgZW5kcG9pbnROYW1lOiBzdHJpbmcsXG4gIG1ldHJpY0dyb3VwOiBCdXNpbmVzc01ldHJpY0dyb3VwIHwgdW5kZWZpbmVkLFxuICByZXNwb25zZTogUmVzcG9uc2UsXG4pOiB2b2lkIHtcbiAgY29uc3QgZHVyYXRpb24gPSByZXNwb25zZS50aW1pbmdzLmR1cmF0aW9uO1xuICBpZiAobWV0cmljR3JvdXApIHtcbiAgICBjb25zdCByZWNvcmRlciA9IG1ldHJpY1JlY29yZGVyc1ttZXRyaWNHcm91cF07XG4gICAgcmVjb3JkZXIuZHVyYXRpb24uYWRkKGR1cmF0aW9uLCB7IGVuZHBvaW50OiBlbmRwb2ludE5hbWUgfSk7XG4gICAgcmVjb3JkZXIuc3VjY2Vzcy5hZGQocmVzcG9uc2Uuc3RhdHVzID49IDIwMCAmJiByZXNwb25zZS5zdGF0dXMgPCA0MDAsIHtcbiAgICAgIGVuZHBvaW50OiBlbmRwb2ludE5hbWUsXG4gICAgfSk7XG4gIH1cbiAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHtcbiAgICB0b3RhbEJ1c2luZXNzRXJyb3JzLmFkZCgxLCB7IGVuZHBvaW50OiBlbmRwb2ludE5hbWUsIHN0YXR1czogU3RyaW5nKHJlc3BvbnNlLnN0YXR1cykgfSk7XG4gIH1cbn1cblxuLyoqIFNoYXJlZCB0YWdnZWQgSFRUUCB0cmFuc3BvcnQgd2l0aCB0YXJnZXQgc2FmZXR5LCByZXRyaWVzLCBhbmQgYnVzaW5lc3MgbWV0cmljIHJlY29yZGluZy4gKi9cbmV4cG9ydCBjbGFzcyBIdHRwQ2xpZW50IHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBjb25maWc6IEVudkNvbmZpZyA9IGdldENvbmZpZygpKSB7fVxuXG4gIHJlcXVlc3Q8VD4oXG4gICAgbWV0aG9kOiBIdHRwTWV0aG9kLFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBlbmRwb2ludE5hbWU6IHN0cmluZyxcbiAgICBib2R5PzogdW5rbm93bixcbiAgICBvcHRpb25zOiBIdHRwUmVxdWVzdE9wdGlvbnMgPSB7fSxcbiAgKTogSHR0cFJlc3BvbnNlPFQ+IHtcbiAgICBpZiAoIXRoaXMuY29uZmlnLmFsbG93c1dyaXRlcyAmJiB3cml0ZU1ldGhvZHMuaGFzKG1ldGhvZCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgJHttZXRob2R9IHJlcXVlc3RzIGFyZSBibG9ja2VkIGluIHRoZSBwcm9kdWN0aW9uIGVudmlyb25tZW50YCk7XG4gICAgfVxuXG4gICAgY29uc3QgdXJsID0gam9pblVybCh0aGlzLmNvbmZpZy5iYXNlVXJsLCBwYXRoKTtcbiAgICBjb25zdCBwYXJhbXM6IFBhcmFtcyA9IHtcbiAgICAgIC4uLm9wdGlvbnMucGFyYW1zLFxuICAgICAgdGltZW91dDogb3B0aW9ucy5wYXJhbXM/LnRpbWVvdXQgPz8gdGhpcy5jb25maWcudGltZW91dHMuaHR0cCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgLi4uKGJvZHkgPT09IHVuZGVmaW5lZCA/IHt9IDogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0pLFxuICAgICAgICAuLi5vcHRpb25zLnBhcmFtcz8uaGVhZGVycyxcbiAgICAgIH0sXG4gICAgICB0YWdzOiB7XG4gICAgICAgIC4uLnRoaXMuY29uZmlnLnRhZ3MsXG4gICAgICAgIC4uLm9wdGlvbnMucGFyYW1zPy50YWdzLFxuICAgICAgICBuYW1lOiBlbmRwb2ludE5hbWUsXG4gICAgICB9LFxuICAgIH07XG4gICAgY29uc3QgcmVxdWVzdEJvZHk6IFJlcXVlc3RCb2R5IHwgbnVsbCA9XG4gICAgICBib2R5ID09PSB1bmRlZmluZWQgPyBudWxsIDogdHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnID8gYm9keSA6IEpTT04uc3RyaW5naWZ5KGJvZHkpO1xuICAgIGNvbnN0IHJldHJ5ID0gc2FmZVJldHJ5TWV0aG9kcy5oYXMobWV0aG9kKSB8fCBvcHRpb25zLnJldHJ5VW5zYWZlID09PSB0cnVlO1xuICAgIGxldCBhdHRlbXB0cyA9IDA7XG4gICAgbGV0IHJlc3BvbnNlOiBSZXNwb25zZTtcblxuICAgIGRvIHtcbiAgICAgIGF0dGVtcHRzICs9IDE7XG4gICAgICBsb2dnZXIuZGVidWcoJ0hUVFAgcmVxdWVzdCcsIHsgbWV0aG9kLCB1cmwsIHRhZ3M6IHBhcmFtcy50YWdzLCBhdHRlbXB0OiBhdHRlbXB0cyB9KTtcbiAgICAgIHJlc3BvbnNlID0gaHR0cC5yZXF1ZXN0KG1ldGhvZCwgdXJsLCByZXF1ZXN0Qm9keSwgcGFyYW1zKTtcbiAgICAgIHJlY29yZEJ1c2luZXNzTWV0cmljcyhlbmRwb2ludE5hbWUsIG9wdGlvbnMubWV0cmljR3JvdXAsIHJlc3BvbnNlKTtcbiAgICAgIGxvZ2dlci5kZWJ1ZygnSFRUUCByZXNwb25zZScsIHsgbWV0aG9kLCB1cmwsIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLCBhdHRlbXB0OiBhdHRlbXB0cyB9KTtcblxuICAgICAgaWYgKCEocmV0cnkgJiYgYXR0ZW1wdHMgPT09IDEgJiYgcmVzcG9uc2Uuc3RhdHVzID49IDUwMCkpIGJyZWFrO1xuICAgICAgc2xlZXAoMC4xKTtcbiAgICB9IHdoaWxlIChhdHRlbXB0cyA8IDIpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGRhdGE6IHBhcnNlSnNvbjxUPihyZXNwb25zZSksXG4gICAgICBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcbiAgICAgIGhlYWRlcnM6IHJlc3BvbnNlLmhlYWRlcnMsXG4gICAgICByYXc6IHJlc3BvbnNlLFxuICAgICAgYXR0ZW1wdHMsXG4gICAgfTtcbiAgfVxuXG4gIGdldDxUPihwYXRoOiBzdHJpbmcsIG5hbWU6IHN0cmluZywgb3B0aW9ucz86IEh0dHBSZXF1ZXN0T3B0aW9ucyk6IEh0dHBSZXNwb25zZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxUPignR0VUJywgcGF0aCwgbmFtZSwgdW5kZWZpbmVkLCBvcHRpb25zKTtcbiAgfVxuXG4gIHBvc3Q8VD4oXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIG5hbWU6IHN0cmluZyxcbiAgICBib2R5OiB1bmtub3duLFxuICAgIG9wdGlvbnM/OiBIdHRwUmVxdWVzdE9wdGlvbnMsXG4gICk6IEh0dHBSZXNwb25zZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxUPignUE9TVCcsIHBhdGgsIG5hbWUsIGJvZHksIG9wdGlvbnMpO1xuICB9XG5cbiAgcHV0PFQ+KHBhdGg6IHN0cmluZywgbmFtZTogc3RyaW5nLCBib2R5OiB1bmtub3duLCBvcHRpb25zPzogSHR0cFJlcXVlc3RPcHRpb25zKTogSHR0cFJlc3BvbnNlPFQ+IHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFQ+KCdQVVQnLCBwYXRoLCBuYW1lLCBib2R5LCBvcHRpb25zKTtcbiAgfVxuXG4gIHBhdGNoPFQ+KFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBuYW1lOiBzdHJpbmcsXG4gICAgYm9keTogdW5rbm93bixcbiAgICBvcHRpb25zPzogSHR0cFJlcXVlc3RPcHRpb25zLFxuICApOiBIdHRwUmVzcG9uc2U8VD4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8VD4oJ1BBVENIJywgcGF0aCwgbmFtZSwgYm9keSwgb3B0aW9ucyk7XG4gIH1cblxuICBkZWxldGU8VD4ocGF0aDogc3RyaW5nLCBuYW1lOiBzdHJpbmcsIG9wdGlvbnM/OiBIdHRwUmVxdWVzdE9wdGlvbnMpOiBIdHRwUmVzcG9uc2U8VD4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8VD4oJ0RFTEVURScsIHBhdGgsIG5hbWUsIHVuZGVmaW5lZCwgb3B0aW9ucyk7XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBDb3VudGVyLCBSYXRlLCBUcmVuZCB9IGZyb20gJ2s2L21ldHJpY3MnO1xuXG4vKiogQXV0aGVudGljYXRpb24gbGF0ZW5jeSBpbiBtaWxsaXNlY29uZHMuICovXG5leHBvcnQgY29uc3QgYXV0aER1cmF0aW9uID0gbmV3IFRyZW5kKCdjdXN0b21fYXV0aF9kdXJhdGlvbl9tcycsIHRydWUpO1xuLyoqIFJlYWQtb25seSBhcnRpY2xlIHJlcXVlc3QgbGF0ZW5jeSBpbiBtaWxsaXNlY29uZHMuICovXG5leHBvcnQgY29uc3QgYXJ0aWNsZVJlYWREdXJhdGlvbiA9IG5ldyBUcmVuZCgnY3VzdG9tX2FydGljbGVfcmVhZF9kdXJhdGlvbl9tcycsIHRydWUpO1xuLyoqIEFydGljbGUgbXV0YXRpb24gbGF0ZW5jeSBpbiBtaWxsaXNlY29uZHMuICovXG5leHBvcnQgY29uc3QgYXJ0aWNsZVdyaXRlRHVyYXRpb24gPSBuZXcgVHJlbmQoJ2N1c3RvbV9hcnRpY2xlX3dyaXRlX2R1cmF0aW9uX21zJywgdHJ1ZSk7XG4vKiogQ29tbWVudCBvcGVyYXRpb24gbGF0ZW5jeSBpbiBtaWxsaXNlY29uZHMuICovXG5leHBvcnQgY29uc3QgY29tbWVudER1cmF0aW9uID0gbmV3IFRyZW5kKCdjdXN0b21fY29tbWVudF9kdXJhdGlvbl9tcycsIHRydWUpO1xuLyoqIFByb2ZpbGUgb3BlcmF0aW9uIGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IHByb2ZpbGVEdXJhdGlvbiA9IG5ldyBUcmVuZCgnY3VzdG9tX3Byb2ZpbGVfZHVyYXRpb25fbXMnLCB0cnVlKTtcbi8qKiBUYWcgb3BlcmF0aW9uIGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IHRhZ0R1cmF0aW9uID0gbmV3IFRyZW5kKCdjdXN0b21fdGFnX2R1cmF0aW9uX21zJywgdHJ1ZSk7XG4vKiogQ291bnQgb2YgSFRUUCByZXNwb25zZXMgcmVwcmVzZW50aW5nIGJ1c2luZXNzLW9wZXJhdGlvbiBmYWlsdXJlcy4gKi9cbmV4cG9ydCBjb25zdCB0b3RhbEJ1c2luZXNzRXJyb3JzID0gbmV3IENvdW50ZXIoJ2N1c3RvbV9idXNpbmVzc19lcnJvcnNfdG90YWwnKTtcbi8qKiBSYXRpbyBvZiBzdWNjZXNzZnVsIGF1dGhlbnRpY2F0aW9uIG9wZXJhdGlvbnMuICovXG5leHBvcnQgY29uc3QgYXV0aFN1Y2Nlc3NSYXRlID0gbmV3IFJhdGUoJ2N1c3RvbV9hdXRoX3N1Y2Nlc3NfcmF0ZScpO1xuLyoqIFJhdGlvIG9mIHN1Y2Nlc3NmdWwgYXJ0aWNsZSByZWFkIG9wZXJhdGlvbnMuICovXG5leHBvcnQgY29uc3QgYXJ0aWNsZVJlYWRTdWNjZXNzUmF0ZSA9IG5ldyBSYXRlKCdjdXN0b21fYXJ0aWNsZV9yZWFkX3N1Y2Nlc3NfcmF0ZScpO1xuLyoqIFJhdGlvIG9mIHN1Y2Nlc3NmdWwgYXJ0aWNsZSB3cml0ZSBvcGVyYXRpb25zLiAqL1xuZXhwb3J0IGNvbnN0IGFydGljbGVXcml0ZVN1Y2Nlc3NSYXRlID0gbmV3IFJhdGUoJ2N1c3RvbV9hcnRpY2xlX3dyaXRlX3N1Y2Nlc3NfcmF0ZScpO1xuLyoqIFJhdGlvIG9mIHN1Y2Nlc3NmdWwgY29tbWVudCBvcGVyYXRpb25zLiAqL1xuZXhwb3J0IGNvbnN0IGNvbW1lbnRTdWNjZXNzUmF0ZSA9IG5ldyBSYXRlKCdjdXN0b21fY29tbWVudF9zdWNjZXNzX3JhdGUnKTtcbi8qKiBSYXRpbyBvZiBzdWNjZXNzZnVsIHByb2ZpbGUgb3BlcmF0aW9ucy4gKi9cbmV4cG9ydCBjb25zdCBwcm9maWxlU3VjY2Vzc1JhdGUgPSBuZXcgUmF0ZSgnY3VzdG9tX3Byb2ZpbGVfc3VjY2Vzc19yYXRlJyk7XG4vKiogUmF0aW8gb2Ygc3VjY2Vzc2Z1bCB0YWcgb3BlcmF0aW9ucy4gKi9cbmV4cG9ydCBjb25zdCB0YWdTdWNjZXNzUmF0ZSA9IG5ldyBSYXRlKCdjdXN0b21fdGFnX3N1Y2Nlc3NfcmF0ZScpO1xuIiwgImltcG9ydCB7IFNoYXJlZEFycmF5IH0gZnJvbSAnazYvZGF0YSc7XG5pbXBvcnQgc291cmNlIGZyb20gJy4vYnJvd3NlLWJlaGF2aW9ycy5qc29uJztcblxuZXhwb3J0IGludGVyZmFjZSBCcm93c2VCZWhhdmlvciB7XG4gIG5hbWU6IHN0cmluZztcbiAgd2VpZ2h0OiBudW1iZXI7XG4gIGFydGljbGVMaW1pdDogbnVtYmVyO1xuICBpbnNwZWN0QXJ0aWNsZTogYm9vbGVhbjtcbn1cblxuY29uc3QgYmVoYXZpb3JzID0gbmV3IFNoYXJlZEFycmF5PEJyb3dzZUJlaGF2aW9yPignYnJvd3NlIGJlaGF2aW9ycycsICgpID0+XG4gIHNvdXJjZS5tYXAoKGJlaGF2aW9yKSA9PiAoeyAuLi5iZWhhdmlvciB9KSksXG4pO1xuXG5leHBvcnQgZnVuY3Rpb24gYnJvd3NlQmVoYXZpb3IoaXRlcmF0aW9uID0gX19JVEVSKTogQnJvd3NlQmVoYXZpb3Ige1xuICBjb25zdCB0b3RhbFdlaWdodCA9IGJlaGF2aW9ycy5yZWR1Y2UoKHN1bSwgYmVoYXZpb3IpID0+IHN1bSArIGJlaGF2aW9yLndlaWdodCwgMCk7XG4gIGxldCBzZWxlY3Rpb24gPSBpdGVyYXRpb24gJSB0b3RhbFdlaWdodDtcbiAgZm9yIChjb25zdCBiZWhhdmlvciBvZiBiZWhhdmlvcnMpIHtcbiAgICBpZiAoc2VsZWN0aW9uIDwgYmVoYXZpb3Iud2VpZ2h0KSByZXR1cm4gYmVoYXZpb3I7XG4gICAgc2VsZWN0aW9uIC09IGJlaGF2aW9yLndlaWdodDtcbiAgfVxuICBjb25zdCBmYWxsYmFjayA9IGJlaGF2aW9yc1swXTtcbiAgaWYgKCFmYWxsYmFjaykgdGhyb3cgbmV3IEVycm9yKCdBdCBsZWFzdCBvbmUgYnJvd3NlIGJlaGF2aW9yIGlzIHJlcXVpcmVkJyk7XG4gIHJldHVybiBmYWxsYmFjaztcbn1cbiIsICJbXG4gIHsgXCJuYW1lXCI6IFwicXVpY2stcmVhZGVyXCIsIFwid2VpZ2h0XCI6IDUwLCBcImFydGljbGVMaW1pdFwiOiA1LCBcImluc3BlY3RBcnRpY2xlXCI6IGZhbHNlIH0sXG4gIHsgXCJuYW1lXCI6IFwiYXJ0aWNsZS1yZWFkZXJcIiwgXCJ3ZWlnaHRcIjogMzUsIFwiYXJ0aWNsZUxpbWl0XCI6IDEwLCBcImluc3BlY3RBcnRpY2xlXCI6IHRydWUgfSxcbiAgeyBcIm5hbWVcIjogXCJkZWVwLXJlYWRlclwiLCBcIndlaWdodFwiOiAxNSwgXCJhcnRpY2xlTGltaXRcIjogMjAsIFwiaW5zcGVjdEFydGljbGVcIjogdHJ1ZSB9XG5dXG4iLCAiaW1wb3J0IHsgZ2V0Q29uZmlnIH0gZnJvbSAnLi4vLi4vY29uZmlnJztcblxuZXhwb3J0IGludGVyZmFjZSBMb2FkVGFyZ2V0UG9saWN5IHtcbiAgd29ya2xvYWQ6IHN0cmluZztcbiAgd3JpdGU/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIFJlamVjdHMgc3VzdGFpbmVkIG9yIHdyaXRlLWhlYXZ5IHRyYWZmaWMgYWdhaW5zdCBub24tbG9jYWwgdGFyZ2V0cyB1bmxlc3MgZXhwbGljaXRseSBhcHByb3ZlZC5cbiAqIEBwYXJhbSBwb2xpY3kgV29ya2xvYWQgaWRlbnRpdHkgYW5kIHdoZXRoZXIgaXQgbXV0YXRlcyB0YXJnZXQgZGF0YS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFzc2VydEF1dGhvcml6ZWRMb2FkVGFyZ2V0KHBvbGljeTogTG9hZFRhcmdldFBvbGljeSk6IHZvaWQge1xuICBjb25zdCBjb25maWcgPSBnZXRDb25maWcoKTtcbiAgY29uc3QgbG9vcGJhY2sgPSAvXmh0dHBzPzpcXC9cXC8oPzpsb2NhbGhvc3R8MTI3XFwuMFxcLjBcXC4xfFxcWzo6MVxcXSkoPzo6XFxkKyk/KD86XFwvfCQpL2kudGVzdChcbiAgICBjb25maWcuYmFzZVVybCxcbiAgKTtcbiAgaWYgKChjb25maWcuZW52aXJvbm1lbnQgIT09ICdsb2NhbCcgfHwgIWxvb3BiYWNrKSAmJiBfX0VOVi5BTExPV19OT05fTE9DQUxfTE9BRCAhPT0gJ3RydWUnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYCR7cG9saWN5Lndvcmtsb2FkfSAke3BvbGljeS53cml0ZSA/ICd3cml0ZScgOiAnbG9hZCd9IHRyYWZmaWMgcmVxdWlyZXMgYSBsb29wYmFjayBsb2NhbCB0YXJnZXQgb3IgZXhwbGljaXQgb3duZWQtdGFyZ2V0IEFMTE9XX05PTl9MT0NBTF9MT0FEPXRydWVgLFxuICAgICk7XG4gIH1cbn1cblxuLyoqIEB0aHJvd3MgV2hlbiBhIHdyaXRlIHdvcmtsb2FkIHRhcmdldHMgYSBub24tbG9jYWwgZW52aXJvbm1lbnQgd2l0aG91dCBleHBsaWNpdCBhdXRob3JpemF0aW9uLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFzc2VydFdyaXRlVGFyZ2V0KCk6IHZvaWQge1xuICBhc3NlcnRBdXRob3JpemVkTG9hZFRhcmdldCh7IHdvcmtsb2FkOiAnQXV0aGVudGljYXRlZCcsIHdyaXRlOiB0cnVlIH0pO1xufVxuIiwgImltcG9ydCB0eXBlIHsgUmVxdWVzdFJhdGVQcm9maWxlIH0gZnJvbSAnLi4vLi4vY29uZmlnL3dvcmtsb2Fkcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQWNoaWV2ZWRMb2FkIHtcbiAgdmFsaWQ6IGJvb2xlYW47XG4gIHJlYXNvbnM6IHN0cmluZ1tdO1xuICBjb25maWd1cmVkUmVxdWVzdHNQZXJTZWNvbmQ6IG51bWJlcjtcbiAgbWVhc3VyZW1lbnRTZWNvbmRzOiBudW1iZXI7XG4gIG1pbmltdW1BY2hpZXZlZEZyYWN0aW9uOiBudW1iZXI7XG4gIGNvbXBsZXRlZEl0ZXJhdGlvbnM6IG51bWJlciB8IG51bGw7XG4gIHN0YXJ0ZWRSZXF1ZXN0czogbnVtYmVyIHwgbnVsbDtcbiAgcmVxdWVzdHM6IG51bWJlciB8IG51bGw7XG4gIGRyb3BwZWRJdGVyYXRpb25zOiBudW1iZXIgfCBudWxsO1xuICBhY2hpZXZlZEl0ZXJhdGlvbnNQZXJTZWNvbmQ6IG51bWJlciB8IG51bGw7XG4gIGFjaGlldmVkUmVxdWVzdHNQZXJTZWNvbmQ6IG51bWJlciB8IG51bGw7XG59XG5cbi8qKiBWYWxpZGF0ZSB0aGUgZml4ZWQgbWVhc3VyZW1lbnQgY29ob3J0OyBtaXNzaW5nIGV2aWRlbmNlIGlzIG5vdCB6ZXJvLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFzc2Vzc0FjaGlldmVkTG9hZChcbiAgcHJvZmlsZTogUmVxdWVzdFJhdGVQcm9maWxlLFxuICBjb3VudHM6IHtcbiAgICBpdGVyYXRpb25zPzogbnVtYmVyIHwgdW5kZWZpbmVkO1xuICAgIHN0YXJ0ZWQ/OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgcmVxdWVzdHM/OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgZHJvcHBlZD86IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgfSxcbik6IEFjaGlldmVkTG9hZCB7XG4gIGNvbnN0IHJlYXNvbnM6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHZhbGlkQ291bnQgPSAodmFsdWU6IG51bWJlciB8IHVuZGVmaW5lZCk6IHZhbHVlIGlzIG51bWJlciA9PlxuICAgIHZhbHVlICE9PSB1bmRlZmluZWQgJiYgTnVtYmVyLmlzU2FmZUludGVnZXIodmFsdWUpICYmIHZhbHVlID49IDA7XG4gIGNvbnN0IGl0ZXJhdGlvbnMgPSB2YWxpZENvdW50KGNvdW50cy5pdGVyYXRpb25zKSA/IGNvdW50cy5pdGVyYXRpb25zIDogbnVsbDtcbiAgY29uc3Qgc3RhcnRlZCA9IHZhbGlkQ291bnQoY291bnRzLnN0YXJ0ZWQpID8gY291bnRzLnN0YXJ0ZWQgOiBudWxsO1xuICBjb25zdCByZXF1ZXN0cyA9IHZhbGlkQ291bnQoY291bnRzLnJlcXVlc3RzKSA/IGNvdW50cy5yZXF1ZXN0cyA6IG51bGw7XG4gIGNvbnN0IGRyb3BwZWQgPSB2YWxpZENvdW50KGNvdW50cy5kcm9wcGVkKSA/IGNvdW50cy5kcm9wcGVkIDogbnVsbDtcbiAgaWYgKGl0ZXJhdGlvbnMgPT09IG51bGwgfHwgcmVxdWVzdHMgPT09IG51bGwgfHwgZHJvcHBlZCA9PT0gbnVsbCB8fCBzdGFydGVkID09PSBudWxsKSB7XG4gICAgcmVhc29ucy5wdXNoKCdNaXNzaW5nIG9yIGludmFsaWQgbWVhc3VyZW1lbnQgY291bnQnKTtcbiAgfVxuICBjb25zdCBleHBlY3RlZCA9IHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQgKiBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcztcbiAgaWYgKGl0ZXJhdGlvbnMgIT09IG51bGwgJiYgaXRlcmF0aW9ucyA8IGV4cGVjdGVkICogcHJvZmlsZS5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbikge1xuICAgIHJlYXNvbnMucHVzaCgnQWNoaWV2ZWQgYXJyaXZhbCBpdGVyYXRpb25zIGJlbG93IHByZWRlY2xhcmVkIG1pbmltdW0nKTtcbiAgfVxuICBpZiAocmVxdWVzdHMgIT09IG51bGwgJiYgcmVxdWVzdHMgPCBleHBlY3RlZCAqIHByb2ZpbGUubWluaW11bUFjaGlldmVkRnJhY3Rpb24pIHtcbiAgICByZWFzb25zLnB1c2goJ0FjaGlldmVkIEhUVFAgcmVxdWVzdHMgYmVsb3cgcHJlZGVjbGFyZWQgbWluaW11bScpO1xuICB9XG4gIGlmIChyZXF1ZXN0cyAhPT0gbnVsbCAmJiBpdGVyYXRpb25zICE9PSBudWxsICYmIHJlcXVlc3RzICE9PSBpdGVyYXRpb25zKSB7XG4gICAgcmVhc29ucy5wdXNoKCdPbmUtcmVxdWVzdC1wZXItY29tcGxldGVkLWl0ZXJhdGlvbiBjb250cmFjdCB2aW9sYXRlZCcpO1xuICB9XG4gIGlmIChzdGFydGVkICE9PSBudWxsICYmIHJlcXVlc3RzICE9PSBudWxsICYmIHN0YXJ0ZWQgIT09IHJlcXVlc3RzKSB7XG4gICAgcmVhc29ucy5wdXNoKCdTdGFydGVkIEhUVFAgYXR0ZW1wdHMgZGlkIG5vdCBhbGwgY29tcGxldGUgd2l0aGluIHRoZSBib3VuZGVkIGRyYWluJyk7XG4gIH1cbiAgaWYgKHJlcXVlc3RzICE9PSBudWxsICYmIHJlcXVlc3RzID4gZXhwZWN0ZWQgKyAxKSB7XG4gICAgcmVhc29ucy5wdXNoKCdSZXF1ZXN0IGNvdW50IGV4Y2VlZHMgY29uZmlndXJlZCBhcnJpdmFsIGNvaG9ydCcpO1xuICB9XG4gIGlmIChkcm9wcGVkICE9PSBudWxsICYmIGRyb3BwZWQgPiAwKSByZWFzb25zLnB1c2goJ0dlbmVyYXRvciBkcm9wcGVkIG1lYXN1cmVtZW50IGl0ZXJhdGlvbnMnKTtcbiAgcmV0dXJuIHtcbiAgICB2YWxpZDogcmVhc29ucy5sZW5ndGggPT09IDAsXG4gICAgcmVhc29ucyxcbiAgICBjb25maWd1cmVkUmVxdWVzdHNQZXJTZWNvbmQ6IHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQsXG4gICAgbWVhc3VyZW1lbnRTZWNvbmRzOiBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcyxcbiAgICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbjogcHJvZmlsZS5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbixcbiAgICBjb21wbGV0ZWRJdGVyYXRpb25zOiBpdGVyYXRpb25zLFxuICAgIHN0YXJ0ZWRSZXF1ZXN0czogc3RhcnRlZCxcbiAgICByZXF1ZXN0cyxcbiAgICBkcm9wcGVkSXRlcmF0aW9uczogZHJvcHBlZCxcbiAgICBhY2hpZXZlZEl0ZXJhdGlvbnNQZXJTZWNvbmQ6XG4gICAgICBpdGVyYXRpb25zID09PSBudWxsID8gbnVsbCA6IGl0ZXJhdGlvbnMgLyBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcyxcbiAgICBhY2hpZXZlZFJlcXVlc3RzUGVyU2Vjb25kOiByZXF1ZXN0cyA9PT0gbnVsbCA/IG51bGwgOiByZXF1ZXN0cyAvIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzLFxuICB9O1xufVxuIiwgImltcG9ydCB7XG4gIGdldFJlcXVlc3RSYXRlUHJvZmlsZSxcbiAgZ2V0V29ya2xvYWRQcm9maWxlLFxuICBSRVFVRVNUX0RSQUlOX1NFQ09ORFMsXG59IGZyb20gJy4uLy4uL2NvbmZpZy93b3JrbG9hZHMnO1xuaW1wb3J0IHsgYXNzZXNzQWNoaWV2ZWRMb2FkIH0gZnJvbSAnLi9hY2hpZXZlZC1sb2FkJztcbmltcG9ydCB0eXBlIHsgQWNoaWV2ZWRMb2FkIH0gZnJvbSAnLi9hY2hpZXZlZC1sb2FkJztcblxuaW50ZXJmYWNlIE1ldHJpY1ZhbHVlcyB7XG4gIGF2Zz86IG51bWJlcjtcbiAgY291bnQ/OiBudW1iZXI7XG4gIGZhaWxzPzogbnVtYmVyO1xuICBtYXg/OiBudW1iZXI7XG4gIG1lZD86IG51bWJlcjtcbiAgbWluPzogbnVtYmVyO1xuICBwYXNzZXM/OiBudW1iZXI7XG4gICdwKDkwKSc/OiBudW1iZXI7XG4gICdwKDk1KSc/OiBudW1iZXI7XG4gICdwKDk5KSc/OiBudW1iZXI7XG4gIHJhdGU/OiBudW1iZXI7XG4gIHZhbHVlPzogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgU3VtbWFyeU1ldHJpYyB7XG4gIGNvbnRhaW5zPzogc3RyaW5nO1xuICB0aHJlc2hvbGRzPzogUmVjb3JkPHN0cmluZywgeyBvazogYm9vbGVhbiB9PjtcbiAgdHlwZT86IHN0cmluZztcbiAgdmFsdWVzOiBNZXRyaWNWYWx1ZXM7XG59XG5cbmludGVyZmFjZSBTdW1tYXJ5RGF0YSB7XG4gIG1ldHJpY3M6IFJlY29yZDxzdHJpbmcsIFN1bW1hcnlNZXRyaWM+O1xuICByb290X2dyb3VwOiB1bmtub3duO1xuICBzdGF0ZToge1xuICAgIHNldHVwRXJyb3JzPzogbnVtYmVyO1xuICAgIGludGVycnVwdGVkSXRlcmF0aW9ucz86IG51bWJlcjtcbiAgICBba2V5OiBzdHJpbmddOiB1bmtub3duO1xuICB9O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFBlcmZvcm1hbmNlU3VtbWFyeSB7XG4gIGFjaGlldmVkTG9hZDogQWNoaWV2ZWRMb2FkIHwgbnVsbDtcbiAgZmFpbHVyZXM6IHN0cmluZ1tdO1xuICBnZW5lcmF0ZWRBdDogc3RyaW5nO1xuICBtZXRyaWNzOiBSZWNvcmQ8c3RyaW5nLCBNZXRyaWNWYWx1ZXM+O1xuICBtZXRhZGF0YToge1xuICAgIGVudmlyb25tZW50OiBzdHJpbmc7XG4gICAgZnJhbWV3b3JrQ29tbWl0OiBzdHJpbmc7XG4gICAgazZWZXJzaW9uOiBzdHJpbmc7XG4gICAgbWF4VnVzOiBudW1iZXIgfCBudWxsO1xuICAgIHByb2ZpbGU6IHN0cmluZztcbiAgICBydW5uZXJDbGFzczogc3RyaW5nO1xuICAgIHRhcmdldENvbW1pdDogc3RyaW5nO1xuICAgIHRhcmdldElkOiBzdHJpbmc7XG4gICAgd29ya2xvYWRTY2hlbWE6IHN0cmluZztcbiAgICB0YXJnZXRJdGVyYXRpb25zUGVyU2Vjb25kOiBudW1iZXI7XG4gICAgdGFyZ2V0UmVxdWVzdHNQZXJTZWNvbmQ6IG51bWJlciB8IG51bGw7XG4gICAgbWVhc3VyZW1lbnRTZWNvbmRzOiBudW1iZXIgfCBudWxsO1xuICAgIHdhcm11cFNlY29uZHM6IG51bWJlciB8IG51bGw7XG4gICAgbWluaW11bUFjaGlldmVkRnJhY3Rpb246IG51bWJlciB8IG51bGw7XG4gICAgcmVxdWVzdERyYWluU2Vjb25kczogbnVtYmVyIHwgbnVsbDtcbiAgfTtcbiAgcm9vdEdyb3VwOiB1bmtub3duO1xuICBzdGF0ZTogdW5rbm93bjtcbiAgdGhyZXNob2xkczogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgeyBvazogYm9vbGVhbiB9Pj47XG59XG5cbmZ1bmN0aW9uIHN1bW1hcnlGaWxlKCk6IHN0cmluZyB7XG4gIGNvbnN0IG5hbWUgPSBfX0VOVi5TVU1NQVJZX05BTUUgPz8gJ2s2LXN1bW1hcnknO1xuICByZXR1cm4gYHJlcG9ydHMvJHtuYW1lfS1zdW1tYXJ5Lmpzb25gO1xufVxuXG5mdW5jdGlvbiBtYXJrZG93bkZpbGUoKTogc3RyaW5nIHtcbiAgY29uc3QgbmFtZSA9IF9fRU5WLlNVTU1BUllfTkFNRSA/PyAnazYtc3VtbWFyeSc7XG4gIHJldHVybiBgcmVwb3J0cy8ke25hbWV9LXN1bW1hcnkubWRgO1xufVxuXG5mdW5jdGlvbiBodG1sRmlsZSgpOiBzdHJpbmcge1xuICBjb25zdCBuYW1lID0gX19FTlYuU1VNTUFSWV9OQU1FID8/ICdrNi1zdW1tYXJ5JztcbiAgcmV0dXJuIGByZXBvcnRzLyR7bmFtZX0tc3VtbWFyeS5odG1sYDtcbn1cblxuZnVuY3Rpb24gbWV0cmljUm93KG5hbWU6IHN0cmluZywgdmFsdWVzOiBNZXRyaWNWYWx1ZXMgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICBjb25zdCBtZWRpYW4gPSB2YWx1ZXM/Lm1lZDtcbiAgY29uc3QgcDkwID0gdmFsdWVzPy5bJ3AoOTApJ107XG4gIGNvbnN0IHA5NSA9IHZhbHVlcz8uWydwKDk1KSddO1xuICBjb25zdCBwOTkgPSB2YWx1ZXM/LlsncCg5OSknXTtcbiAgY29uc3QgbWF4ID0gdmFsdWVzPy5tYXg7XG4gIGNvbnN0IHJhdGUgPSB2YWx1ZXM/LnJhdGU7XG4gIGNvbnN0IGNvdW50ID0gdmFsdWVzPy5jb3VudDtcbiAgcmV0dXJuIGB8ICR7bmFtZX0gfCAke21lZGlhbj8udG9GaXhlZCgyKSA/PyAnLSd9IHwgJHtwOTA/LnRvRml4ZWQoMikgPz8gJy0nfSB8ICR7cDk1Py50b0ZpeGVkKDIpID8/ICctJ30gfCAke3A5OT8udG9GaXhlZCgyKSA/PyAnLSd9IHwgJHttYXg/LnRvRml4ZWQoMikgPz8gJy0nfSB8ICR7cmF0ZT8udG9GaXhlZCg0KSA/PyAnLSd9IHwgJHtjb3VudCA/PyAnLSd9IHxgO1xufVxuXG5mdW5jdGlvbiB0aHJlc2hvbGRBY3R1YWwodmFsdWVzOiBNZXRyaWNWYWx1ZXMsIHRocmVzaG9sZDogc3RyaW5nKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgY29uc3Qga2V5ID0gdGhyZXNob2xkLm1hdGNoKC9eKHBcXChcXGQrXFwpfGF2Z3xtZWR8bWlufG1heHxyYXRlfGNvdW50fHZhbHVlKS8pPy5bMV07XG4gIHJldHVybiBrZXkgPyB2YWx1ZXNba2V5IGFzIGtleW9mIE1ldHJpY1ZhbHVlc10gOiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIGh0bWxFc2NhcGUodmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiB2YWx1ZVxuICAgIC5yZXBsYWNlQWxsKCcmJywgJyZhbXA7JylcbiAgICAucmVwbGFjZUFsbCgnPCcsICcmbHQ7JylcbiAgICAucmVwbGFjZUFsbCgnPicsICcmZ3Q7JylcbiAgICAucmVwbGFjZUFsbCgnXCInLCAnJnF1b3Q7Jyk7XG59XG5cbmZ1bmN0aW9uIG1ldHJpY1ZhbHVlKHZhbHVlOiBudW1iZXIgfCB1bmRlZmluZWQsIGRpZ2l0cyA9IDIpOiBzdHJpbmcge1xuICByZXR1cm4gdmFsdWUgPT09IHVuZGVmaW5lZCA/ICctJyA6IHZhbHVlLnRvRml4ZWQoZGlnaXRzKTtcbn1cblxuZnVuY3Rpb24gaHRtbE1ldHJpY1Jvd3MobWV0cmljczogUmVjb3JkPHN0cmluZywgTWV0cmljVmFsdWVzPiwgbmFtZXM6IHN0cmluZ1tdKTogc3RyaW5nIHtcbiAgaWYgKG5hbWVzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAnPHRyPjx0ZCBjb2xzcGFuPVwiN1wiPk5vIG1hdGNoaW5nIG1ldHJpY3Mgd2VyZSBlbWl0dGVkLjwvdGQ+PC90cj4nO1xuICB9XG4gIHJldHVybiBuYW1lc1xuICAgIC5tYXAoKG5hbWUpID0+IHtcbiAgICAgIGNvbnN0IHZhbHVlcyA9IG1ldHJpY3NbbmFtZV0gPz8ge307XG4gICAgICByZXR1cm4gYDx0cj48dGQ+JHtodG1sRXNjYXBlKG5hbWUpfTwvdGQ+PHRkPiR7bWV0cmljVmFsdWUodmFsdWVzLm1lZCl9PC90ZD48dGQ+JHttZXRyaWNWYWx1ZSh2YWx1ZXNbJ3AoOTApJ10pfTwvdGQ+PHRkPiR7bWV0cmljVmFsdWUodmFsdWVzWydwKDk1KSddKX08L3RkPjx0ZD4ke21ldHJpY1ZhbHVlKHZhbHVlc1sncCg5OSknXSl9PC90ZD48dGQ+JHttZXRyaWNWYWx1ZSh2YWx1ZXMucmF0ZSwgNCl9PC90ZD48dGQ+JHt2YWx1ZXMuY291bnQgPz8gJy0nfTwvdGQ+PC90cj5gO1xuICAgIH0pXG4gICAgLmpvaW4oJycpO1xufVxuXG5mdW5jdGlvbiBodG1sVGhyZXNob2xkUm93cyhzdW1tYXJ5OiBQZXJmb3JtYW5jZVN1bW1hcnkpOiBzdHJpbmcge1xuICBjb25zdCByb3dzID0gT2JqZWN0LmVudHJpZXMoc3VtbWFyeS50aHJlc2hvbGRzKS5mbGF0TWFwKChbbWV0cmljLCB0aHJlc2hvbGRzXSkgPT5cbiAgICBPYmplY3QuZW50cmllcyh0aHJlc2hvbGRzKS5tYXAoKFt0aHJlc2hvbGQsIHJlc3VsdF0pID0+IHtcbiAgICAgIGNvbnN0IGFjdHVhbCA9IHRocmVzaG9sZEFjdHVhbChzdW1tYXJ5Lm1ldHJpY3NbbWV0cmljXSA/PyB7fSwgdGhyZXNob2xkKTtcbiAgICAgIHJldHVybiBgPHRyPjx0ZD4ke2h0bWxFc2NhcGUobWV0cmljKX08L3RkPjx0ZD4ke2h0bWxFc2NhcGUodGhyZXNob2xkKX08L3RkPjx0ZD4ke2FjdHVhbCA/PyAndW5hdmFpbGFibGUnfTwvdGQ+PHRkIGNsYXNzPVwiJHtyZXN1bHQub2sgPyAncGFzc2VkJyA6ICdmYWlsZWQnfVwiPiR7cmVzdWx0Lm9rID8gJ1BBU1MnIDogJ0ZBSUwnfTwvdGQ+PC90cj5gO1xuICAgIH0pLFxuICApO1xuICByZXR1cm4gcm93cy5sZW5ndGggPT09IDBcbiAgICA/ICc8dHI+PHRkIGNvbHNwYW49XCI0XCI+Tm8gdGhyZXNob2xkIHJlc3VsdHMgd2VyZSByZXBvcnRlZC48L3RkPjwvdHI+J1xuICAgIDogcm93cy5qb2luKCcnKTtcbn1cblxuLyoqXG4gKiBQcm9kdWNlcyBtYWNoaW5lLXJlYWRhYmxlIGFuZCByZXZpZXdlci1yZWFkYWJsZSBhcnRpZmFjdHMgZnJvbSBhIGNvbXBsZXRlZCBrNiBydW4uXG4gKiBAcGFyYW0gZGF0YSBrNiBlbmQtb2YtdGVzdCBzdW1tYXJ5IGRhdGEuXG4gKiBAcmV0dXJucyBPdXRwdXQgcGF0aHMgbWFwcGVkIHRvIHNlcmlhbGl6ZWQgcmVwb3J0IGNvbnRlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTdW1tYXJ5KGRhdGE6IFN1bW1hcnlEYXRhKTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gIGNvbnN0IHdvcmtsb2FkID0gZ2V0V29ya2xvYWRQcm9maWxlKCk7XG4gIGNvbnN0IHJlcXVlc3RQcm9maWxlID0gX19FTlYuV09SS0xPQURfTU9ERSA9PT0gJ3JlcXVlc3QtcmF0ZScgPyBnZXRSZXF1ZXN0UmF0ZVByb2ZpbGUoKSA6IG51bGw7XG4gIGNvbnN0IGFjaGlldmVkTG9hZCA9IHJlcXVlc3RQcm9maWxlXG4gICAgPyBhc3Nlc3NBY2hpZXZlZExvYWQocmVxdWVzdFByb2ZpbGUsIHtcbiAgICAgICAgaXRlcmF0aW9uczogZGF0YS5tZXRyaWNzWydpdGVyYXRpb25ze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9J10/LnZhbHVlcy5jb3VudCxcbiAgICAgICAgc3RhcnRlZDogZGF0YS5tZXRyaWNzWydyZXF1ZXN0X2F0dGVtcHRze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9J10/LnZhbHVlcy5jb3VudCxcbiAgICAgICAgcmVxdWVzdHM6IGRhdGEubWV0cmljc1snaHR0cF9yZXFze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9J10/LnZhbHVlcy5jb3VudCxcbiAgICAgICAgZHJvcHBlZDogZGF0YS5tZXRyaWNzWydkcm9wcGVkX2l0ZXJhdGlvbnN7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nXT8udmFsdWVzLmNvdW50LFxuICAgICAgfSlcbiAgICA6IG51bGw7XG4gIGNvbnN0IGNoZWNrRmFpbHVyZXMgPSBkYXRhLm1ldHJpY3MuY2hlY2tzPy52YWx1ZXMuZmFpbHMgPz8gMDtcbiAgY29uc3QgaW50ZXJydXB0ZWRJdGVyYXRpb25zID1cbiAgICBkYXRhLm1ldHJpY3MuaW50ZXJydXB0ZWRfaXRlcmF0aW9ucz8udmFsdWVzLmNvdW50ID8/IGRhdGEuc3RhdGUuaW50ZXJydXB0ZWRJdGVyYXRpb25zID8/IDA7XG4gIGNvbnN0IHNldHVwRXJyb3JzID0gZGF0YS5zdGF0ZS5zZXR1cEVycm9ycyA/PyAwO1xuICBjb25zdCBzdW1tYXJ5OiBQZXJmb3JtYW5jZVN1bW1hcnkgPSB7XG4gICAgYWNoaWV2ZWRMb2FkLFxuICAgIGZhaWx1cmVzOiBbXSxcbiAgICBnZW5lcmF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIG1ldHJpY3M6IE9iamVjdC5mcm9tRW50cmllcyhcbiAgICAgIE9iamVjdC5lbnRyaWVzKGRhdGEubWV0cmljcykubWFwKChbbmFtZSwgbWV0cmljXSkgPT4gW25hbWUsIG1ldHJpYy52YWx1ZXNdKSxcbiAgICApLFxuICAgIG1ldGFkYXRhOiB7XG4gICAgICBlbnZpcm9ubWVudDogX19FTlYuVEFSR0VUX0VOViA/PyAnbG9jYWwnLFxuICAgICAgZnJhbWV3b3JrQ29tbWl0OiBfX0VOVi5GUkFNRVdPUktfQ09NTUlUID8/ICd1bmtub3duJyxcbiAgICAgIGs2VmVyc2lvbjogX19FTlYuSzZfVkVSU0lPTiA/PyAnMi4wLjAnLFxuICAgICAgbWF4VnVzOiByZXF1ZXN0UHJvZmlsZT8ubWF4VnVzID8/IHdvcmtsb2FkLm1heFZ1cyxcbiAgICAgIHByb2ZpbGU6IF9fRU5WLlRFU1RfUFJPRklMRSA/PyAnZnVsbCcsXG4gICAgICBydW5uZXJDbGFzczogX19FTlYuUlVOTkVSX0NMQVNTID8/ICdsb2NhbCcsXG4gICAgICB0YXJnZXRDb21taXQ6IF9fRU5WLlRBUkdFVF9DT01NSVQgPz8gJ3Vua25vd24nLFxuICAgICAgdGFyZ2V0SWQ6IF9fRU5WLlRBUkdFVF9JRCA/PyBfX0VOVi5UQVJHRVRfRU5WID8/ICdsb2NhbCcsXG4gICAgICB3b3JrbG9hZFNjaGVtYTogcmVxdWVzdFByb2ZpbGUgPyAnc2luZ2xlLXJlcXVlc3QtYXJyaXZhbC12MicgOiAnam91cm5leS1hcnJpdmFsLXYxJyxcbiAgICAgIHRhcmdldEl0ZXJhdGlvbnNQZXJTZWNvbmQ6XG4gICAgICAgIHJlcXVlc3RQcm9maWxlPy5yZXF1ZXN0c1BlclNlY29uZCA/PyB3b3JrbG9hZC50YXJnZXRJdGVyYXRpb25zUGVyU2Vjb25kLFxuICAgICAgdGFyZ2V0UmVxdWVzdHNQZXJTZWNvbmQ6IHJlcXVlc3RQcm9maWxlPy5yZXF1ZXN0c1BlclNlY29uZCA/PyBudWxsLFxuICAgICAgbWVhc3VyZW1lbnRTZWNvbmRzOiByZXF1ZXN0UHJvZmlsZT8ubWVhc3VyZW1lbnRTZWNvbmRzID8/IG51bGwsXG4gICAgICB3YXJtdXBTZWNvbmRzOiByZXF1ZXN0UHJvZmlsZT8ud2FybXVwU2Vjb25kcyA/PyBudWxsLFxuICAgICAgbWluaW11bUFjaGlldmVkRnJhY3Rpb246IHJlcXVlc3RQcm9maWxlPy5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbiA/PyBudWxsLFxuICAgICAgcmVxdWVzdERyYWluU2Vjb25kczogcmVxdWVzdFByb2ZpbGUgPyBSRVFVRVNUX0RSQUlOX1NFQ09ORFMgOiBudWxsLFxuICAgIH0sXG4gICAgcm9vdEdyb3VwOiBkYXRhLnJvb3RfZ3JvdXAsXG4gICAgc3RhdGU6IGRhdGEuc3RhdGUsXG4gICAgdGhyZXNob2xkczogT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgICAgT2JqZWN0LmVudHJpZXMoZGF0YS5tZXRyaWNzKVxuICAgICAgICAuZmlsdGVyKChbLCBtZXRyaWNdKSA9PiBtZXRyaWMudGhyZXNob2xkcylcbiAgICAgICAgLm1hcCgoW25hbWUsIG1ldHJpY10pID0+IFtuYW1lLCBtZXRyaWMudGhyZXNob2xkcyA/PyB7fV0pLFxuICAgICksXG4gIH07XG4gIGNvbnN0IGZhaWxlZFRocmVzaG9sZHMgPSBPYmplY3QuZW50cmllcyhzdW1tYXJ5LnRocmVzaG9sZHMpLmZsYXRNYXAoKFttZXRyaWMsIHRocmVzaG9sZHNdKSA9PlxuICAgIE9iamVjdC5lbnRyaWVzKHRocmVzaG9sZHMpXG4gICAgICAuZmlsdGVyKChbLCByZXN1bHRdKSA9PiAhcmVzdWx0Lm9rKVxuICAgICAgLm1hcCgoW3RocmVzaG9sZF0pID0+IHtcbiAgICAgICAgY29uc3QgYWN0dWFsID0gdGhyZXNob2xkQWN0dWFsKHN1bW1hcnkubWV0cmljc1ttZXRyaWNdID8/IHt9LCB0aHJlc2hvbGQpO1xuICAgICAgICByZXR1cm4gYCR7bWV0cmljfTogZXhwZWN0ZWQgJHt0aHJlc2hvbGR9OyBhY3R1YWwgJHthY3R1YWwgPz8gJ3VuYXZhaWxhYmxlJ31gO1xuICAgICAgfSksXG4gICk7XG4gIHN1bW1hcnkuZmFpbHVyZXMgPSBbXG4gICAgLi4uKGFjaGlldmVkTG9hZCAmJiAhYWNoaWV2ZWRMb2FkLnZhbGlkXG4gICAgICA/IGFjaGlldmVkTG9hZC5yZWFzb25zLm1hcCgocmVhc29uKSA9PiBgSW52YWxpZCBsb2FkIGV4cGVyaW1lbnQ6ICR7cmVhc29ufWApXG4gICAgICA6IFtdKSxcbiAgICAuLi5mYWlsZWRUaHJlc2hvbGRzLm1hcCgoZmFpbHVyZSkgPT4gYFRocmVzaG9sZDogJHtmYWlsdXJlfWApLFxuICAgIC4uLihjaGVja0ZhaWx1cmVzID4gMCA/IFtgQ2hlY2tzOiAke2NoZWNrRmFpbHVyZXN9IGZhaWxlZGBdIDogW10pLFxuICAgIC4uLihzZXR1cEVycm9ycyA+IDAgPyBbYFNldHVwOiAke3NldHVwRXJyb3JzfSBlcnJvcihzKWBdIDogW10pLFxuICAgIC4uLihpbnRlcnJ1cHRlZEl0ZXJhdGlvbnMgPiAwXG4gICAgICA/IFtgRXhlY3V0aW9uOiAke2ludGVycnVwdGVkSXRlcmF0aW9uc30gaW50ZXJydXB0ZWQgaXRlcmF0aW9uKHMpYF1cbiAgICAgIDogW10pLFxuICBdO1xuICBjb25zdCBtYXJrZG93biA9IFtcbiAgICAnIyBrNiBQZXJmb3JtYW5jZSBTdW1tYXJ5JyxcbiAgICAnJyxcbiAgICBgKipSdW4gc3RhdHVzOioqICR7c3VtbWFyeS5mYWlsdXJlcy5sZW5ndGggPyAnRkFJTEVEJyA6ICdQQVNTRUQnfWAsXG4gICAgYCoqVGFyZ2V0OioqICR7c3VtbWFyeS5tZXRhZGF0YS50YXJnZXRJZH0gKCR7c3VtbWFyeS5tZXRhZGF0YS50YXJnZXRDb21taXR9KWAsXG4gICAgYCoqUHJvZmlsZToqKiAke3N1bW1hcnkubWV0YWRhdGEucHJvZmlsZX0gb24gJHtzdW1tYXJ5Lm1ldGFkYXRhLnJ1bm5lckNsYXNzfWAsXG4gICAgYCoqV29ya2xvYWQgc2NoZW1hOioqICR7c3VtbWFyeS5tZXRhZGF0YS53b3JrbG9hZFNjaGVtYX1gLFxuICAgIGAqKkNvbmZpZ3VyZWQgYXJyaXZhbDoqKiAke3N1bW1hcnkubWV0YWRhdGEudGFyZ2V0SXRlcmF0aW9uc1BlclNlY29uZH0gaXRlcmF0aW9ucy9zYCxcbiAgICBgKipDb25maWd1cmVkIHJlcXVlc3RzOioqICR7c3VtbWFyeS5tZXRhZGF0YS50YXJnZXRSZXF1ZXN0c1BlclNlY29uZCA/PyAnbm90IGZpeGVkIGJ5IGpvdXJuZXkgYXJyaXZhbCd9JHtyZXF1ZXN0UHJvZmlsZSA/ICcgcmVxdWVzdHMvcycgOiAnJ31gLFxuICAgIC4uLihhY2hpZXZlZExvYWRcbiAgICAgID8gW1xuICAgICAgICAgIGAqKk1lYXN1cmVtZW50OioqICR7YWNoaWV2ZWRMb2FkLm1lYXN1cmVtZW50U2Vjb25kc31zIHNjaGVkdWxlZCBhcnJpdmFsIHdpbmRvdywgZXhjbHVkaW5nIHdhcm0tdXAgYW5kIHRoZSAycyBzZXR0bGluZyBnYXBgLFxuICAgICAgICAgIGAqKkNvbXBsZXRpb24gZHJhaW46KiogYXQgbW9zdCAke3N1bW1hcnkubWV0YWRhdGEucmVxdWVzdERyYWluU2Vjb25kc31zOyBjb3VudHMgaW5jbHVkZSBjb21wbGV0aW9uIG9mIHJlcXVlc3RzIHN0YXJ0ZWQgaW4gdGhlIHNjaGVkdWxlZCBhcnJpdmFsIHdpbmRvdywgd2l0aCB0aHJvdWdocHV0IGRpdmlkZWQgYnkgdGhhdCB3aW5kb3dgLFxuICAgICAgICAgIGAqKkFjaGlldmVkOioqICR7YWNoaWV2ZWRMb2FkLmFjaGlldmVkSXRlcmF0aW9uc1BlclNlY29uZCA/PyAndW5rbm93bid9IGNvbXBsZXRlZCBpdGVyYXRpb25zL3M7ICR7YWNoaWV2ZWRMb2FkLmFjaGlldmVkUmVxdWVzdHNQZXJTZWNvbmQgPz8gJ3Vua25vd24nfSByZXF1ZXN0cy9zOyAke2FjaGlldmVkTG9hZC5kcm9wcGVkSXRlcmF0aW9ucyA/PyAndW5rbm93bid9IGRyb3BwZWQgaXRlcmF0aW9uc2AsXG4gICAgICAgICAgYCoqTG9hZCB2YWxpZGl0eToqKiAke2FjaGlldmVkTG9hZC52YWxpZCA/ICdWQUxJRCcgOiAnSU5WQUxJRCd9IChwcmVkZWNsYXJlZCBtaW5pbXVtIGZyYWN0aW9uICR7YWNoaWV2ZWRMb2FkLm1pbmltdW1BY2hpZXZlZEZyYWN0aW9ufSlgLFxuICAgICAgICBdXG4gICAgICA6IFtcbiAgICAgICAgICBgKipPYnNlcnZlZCBmdWxsLXJ1biByYXRlczoqKiAke3N1bW1hcnkubWV0cmljcy5pdGVyYXRpb25zPy5yYXRlID8/ICd1bmtub3duJ30gaXRlcmF0aW9ucy9zOyAke3N1bW1hcnkubWV0cmljcy5odHRwX3JlcXM/LnJhdGUgPz8gJ3Vua25vd24nfSByZXF1ZXN0cy9zIChuYXRpdmUgZnVsbC1ydW4gZGVub21pbmF0b3IsIG5vdCBhIHNlcGFyYXRlZCBzdGVhZHktc3RhdGUgd2luZG93KWAsXG4gICAgICAgIF0pLFxuICAgIC4uLihzdW1tYXJ5LmZhaWx1cmVzLmxlbmd0aCA/IFsnJywgLi4uc3VtbWFyeS5mYWlsdXJlcy5tYXAoKGZhaWx1cmUpID0+IGAtICR7ZmFpbHVyZX1gKV0gOiBbXSksXG4gICAgJycsXG4gICAgJ3wgTWV0cmljIHwgcDUwIHwgcDkwIHwgcDk1IHwgcDk5IHwgbWF4IHwgUmF0ZSB8IENvdW50IHwnLFxuICAgICd8LS0tfC0tLTp8LS0tOnwtLS06fC0tLTp8LS0tOnwtLS06fC0tLTp8JyxcbiAgICBtZXRyaWNSb3coJ2h0dHBfcmVxX2R1cmF0aW9uJywgc3VtbWFyeS5tZXRyaWNzLmh0dHBfcmVxX2R1cmF0aW9uKSxcbiAgICBtZXRyaWNSb3coJ2h0dHBfcmVxX2ZhaWxlZCcsIHN1bW1hcnkubWV0cmljcy5odHRwX3JlcV9mYWlsZWQpLFxuICAgIG1ldHJpY1JvdygnY2hlY2tzJywgc3VtbWFyeS5tZXRyaWNzLmNoZWNrcyksXG4gICAgbWV0cmljUm93KCdodHRwX3JlcXMnLCBzdW1tYXJ5Lm1ldHJpY3MuaHR0cF9yZXFzKSxcbiAgICBtZXRyaWNSb3coJ2l0ZXJhdGlvbnMnLCBzdW1tYXJ5Lm1ldHJpY3MuaXRlcmF0aW9ucyksXG4gICAgbWV0cmljUm93KCdjdXN0b21fYXJ0aWNsZV9yZWFkX2R1cmF0aW9uX21zJywgc3VtbWFyeS5tZXRyaWNzLmN1c3RvbV9hcnRpY2xlX3JlYWRfZHVyYXRpb25fbXMpLFxuICAgIG1ldHJpY1JvdygnY3VzdG9tX2J1c2luZXNzX2Vycm9yc190b3RhbCcsIHN1bW1hcnkubWV0cmljcy5jdXN0b21fYnVzaW5lc3NfZXJyb3JzX3RvdGFsKSxcbiAgICAnJyxcbiAgXS5qb2luKCdcXG4nKTtcbiAgY29uc3QgZHVyYXRpb24gPSBzdW1tYXJ5Lm1ldHJpY3MuaHR0cF9yZXFfZHVyYXRpb24gPz8ge307XG4gIGNvbnN0IGJhcnMgPSBbXG4gICAgWydwNTAnLCBkdXJhdGlvbi5tZWQgPz8gMF0sXG4gICAgWydwOTAnLCBkdXJhdGlvblsncCg5MCknXSA/PyAwXSxcbiAgICBbJ3A5NScsIGR1cmF0aW9uWydwKDk1KSddID8/IDBdLFxuICAgIFsncDk5JywgZHVyYXRpb25bJ3AoOTkpJ10gPz8gMF0sXG4gICAgWydtYXgnLCBkdXJhdGlvbi5tYXggPz8gMF0sXG4gIF0gYXMgY29uc3Q7XG4gIGNvbnN0IG1heGltdW0gPSBNYXRoLm1heCguLi5iYXJzLm1hcCgoWywgdmFsdWVdKSA9PiB2YWx1ZSksIDEpO1xuICBjb25zdCBjaGFydCA9IGJhcnNcbiAgICAubWFwKFxuICAgICAgKFtsYWJlbCwgdmFsdWVdLCBpbmRleCkgPT5cbiAgICAgICAgYDxnIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwICR7aW5kZXggKiA0Mn0pXCI+PHRleHQgeD1cIjBcIiB5PVwiMjBcIj4ke2xhYmVsfTwvdGV4dD48cmVjdCB4PVwiNDhcIiB5PVwiNFwiIHdpZHRoPVwiJHsodmFsdWUgLyBtYXhpbXVtKSAqIDUwMH1cIiBoZWlnaHQ9XCIyMlwiIGZpbGw9XCIjMjU2M2ViXCIvPjx0ZXh0IHg9XCIkezU2ICsgKHZhbHVlIC8gbWF4aW11bSkgKiA1MDB9XCIgeT1cIjIwXCI+JHt2YWx1ZS50b0ZpeGVkKDIpfSBtczwvdGV4dD48L2c+YCxcbiAgICApXG4gICAgLmpvaW4oJycpO1xuICBjb25zdCBlbmRwb2ludE1ldHJpY3MgPSBPYmplY3Qua2V5cyhzdW1tYXJ5Lm1ldHJpY3MpXG4gICAgLmZpbHRlcihcbiAgICAgIChuYW1lKSA9PlxuICAgICAgICBuYW1lLnN0YXJ0c1dpdGgoJ2h0dHBfcmVxX2R1cmF0aW9ue25hbWU6JykgfHwgbmFtZS5zdGFydHNXaXRoKCdodHRwX3JlcV9mYWlsZWR7bmFtZTonKSxcbiAgICApXG4gICAgLnNvcnQoKTtcbiAgY29uc3QgYnVzaW5lc3NNZXRyaWNzID0gT2JqZWN0LmtleXMoc3VtbWFyeS5tZXRyaWNzKVxuICAgIC5maWx0ZXIoKG5hbWUpID0+IG5hbWUuc3RhcnRzV2l0aCgnY3VzdG9tXycpKVxuICAgIC5zb3J0KCk7XG4gIGNvbnN0IGh0bWwgPSBgPCFkb2N0eXBlIGh0bWw+XG48aHRtbD48aGVhZD48bWV0YSBjaGFyc2V0PVwidXRmLThcIj48dGl0bGU+azYgUGVyZm9ybWFuY2UgU3VtbWFyeTwvdGl0bGU+XG48c3R5bGU+Ym9keXtmb250OjE2cHggc3lzdGVtLXVpO21heC13aWR0aDoxMTIwcHg7bWFyZ2luOjQwcHggYXV0bztwYWRkaW5nOjAgMjBweDtjb2xvcjojMTgyMTJmfXRhYmxle2JvcmRlci1jb2xsYXBzZTpjb2xsYXBzZTt3aWR0aDoxMDAlO21hcmdpbjoxMnB4IDAgMjhweH10aCx0ZHtwYWRkaW5nOjhweDtib3JkZXI6MXB4IHNvbGlkICNjY2QzZGM7dGV4dC1hbGlnbjpsZWZ0fXRoe2JhY2tncm91bmQ6I2Y0ZjdmYn0uZmFpbGVke2NvbG9yOiNiOTFjMWM7Zm9udC13ZWlnaHQ6NzAwfS5wYXNzZWR7Y29sb3I6IzA0Nzg1Nztmb250LXdlaWdodDo3MDB9Lm1ldGF7bGluZS1oZWlnaHQ6MS42fS5jaGFydHttYXJnaW46MTJweCAwIDI4cHh9PC9zdHlsZT48L2hlYWQ+XG48Ym9keT48aDE+azYgUGVyZm9ybWFuY2UgU3VtbWFyeTwvaDE+XG48cCBjbGFzcz1cIiR7c3VtbWFyeS5mYWlsdXJlcy5sZW5ndGggPyAnZmFpbGVkJyA6ICdwYXNzZWQnfVwiPjxzdHJvbmc+JHtzdW1tYXJ5LmZhaWx1cmVzLmxlbmd0aCA/ICdGQUlMRUQnIDogJ1BBU1NFRCd9PC9zdHJvbmc+PC9wPlxuPHAgY2xhc3M9XCJtZXRhXCI+VGFyZ2V0OiAke2h0bWxFc2NhcGUoc3VtbWFyeS5tZXRhZGF0YS50YXJnZXRJZCl9ICgke2h0bWxFc2NhcGUoc3VtbWFyeS5tZXRhZGF0YS50YXJnZXRDb21taXQpfSk8YnI+UHJvZmlsZTogJHtodG1sRXNjYXBlKHN1bW1hcnkubWV0YWRhdGEucHJvZmlsZSl9PGJyPlJ1bm5lcjogJHtodG1sRXNjYXBlKHN1bW1hcnkubWV0YWRhdGEucnVubmVyQ2xhc3MpfTwvcD5cbjxzdmcgY2xhc3M9XCJjaGFydFwiIHJvbGU9XCJpbWdcIiBhcmlhLWxhYmVsPVwiTGF0ZW5jeSBwZXJjZW50aWxlc1wiIHdpZHRoPVwiNzIwXCIgaGVpZ2h0PVwiMjMwXCIgdmlld0JveD1cIjAgMCA3MjAgMjMwXCI+JHtjaGFydH08L3N2Zz5cbjxoMj5Db3JlIE1ldHJpY3M8L2gyPlxuPHRhYmxlPjx0aGVhZD48dHI+PHRoPk1ldHJpYzwvdGg+PHRoPnA1MDwvdGg+PHRoPnA5MDwvdGg+PHRoPnA5NTwvdGg+PHRoPnA5OTwvdGg+PHRoPlJhdGU8L3RoPjx0aD5Db3VudDwvdGg+PC90cj48L3RoZWFkPjx0Ym9keT4ke2h0bWxNZXRyaWNSb3dzKHN1bW1hcnkubWV0cmljcywgWydodHRwX3JlcV9kdXJhdGlvbicsICdodHRwX3JlcV9mYWlsZWQnLCAnY2hlY2tzJywgJ2h0dHBfcmVxcycsICdpdGVyYXRpb25zJ10pfTwvdGJvZHk+PC90YWJsZT5cbjxoMj5FbmRwb2ludCBNZXRyaWNzPC9oMj5cbjx0YWJsZT48dGhlYWQ+PHRyPjx0aD5NZXRyaWM8L3RoPjx0aD5wNTA8L3RoPjx0aD5wOTA8L3RoPjx0aD5wOTU8L3RoPjx0aD5wOTk8L3RoPjx0aD5SYXRlPC90aD48dGg+Q291bnQ8L3RoPjwvdHI+PC90aGVhZD48dGJvZHk+JHtodG1sTWV0cmljUm93cyhzdW1tYXJ5Lm1ldHJpY3MsIGVuZHBvaW50TWV0cmljcyl9PC90Ym9keT48L3RhYmxlPlxuPGgyPkJ1c2luZXNzIE1ldHJpY3M8L2gyPlxuPHRhYmxlPjx0aGVhZD48dHI+PHRoPk1ldHJpYzwvdGg+PHRoPnA1MDwvdGg+PHRoPnA5MDwvdGg+PHRoPnA5NTwvdGg+PHRoPnA5OTwvdGg+PHRoPlJhdGU8L3RoPjx0aD5Db3VudDwvdGg+PC90cj48L3RoZWFkPjx0Ym9keT4ke2h0bWxNZXRyaWNSb3dzKHN1bW1hcnkubWV0cmljcywgYnVzaW5lc3NNZXRyaWNzKX08L3Rib2R5PjwvdGFibGU+XG48aDI+VGhyZXNob2xkczwvaDI+XG48dGFibGU+PHRoZWFkPjx0cj48dGg+TWV0cmljPC90aD48dGg+VGhyZXNob2xkPC90aD48dGg+QWN0dWFsPC90aD48dGg+U3RhdHVzPC90aD48L3RyPjwvdGhlYWQ+PHRib2R5PiR7aHRtbFRocmVzaG9sZFJvd3Moc3VtbWFyeSl9PC90Ym9keT48L3RhYmxlPlxuPGgyPk1hcmtkb3duIFN1bW1hcnk8L2gyPlxuPHByZT4ke2h0bWxFc2NhcGUobWFya2Rvd24pfTwvcHJlPlxuPC9ib2R5PjwvaHRtbD5gO1xuXG4gIHJldHVybiB7XG4gICAgW3N1bW1hcnlGaWxlKCldOiBKU09OLnN0cmluZ2lmeShzdW1tYXJ5LCBudWxsLCAyKSxcbiAgICBbbWFya2Rvd25GaWxlKCldOiBtYXJrZG93bixcbiAgICBbaHRtbEZpbGUoKV06IGh0bWwsXG4gICAgc3Rkb3V0OiBtYXJrZG93bixcbiAgfTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IFRocmVzaG9sZCB9IGZyb20gJ2s2L29wdGlvbnMnO1xuaW1wb3J0IHR5cGUgeyBTY2VuYXJpb09wdGlvbnMgfSBmcm9tICcuL3NjZW5hcmlvLnR5cGVzJztcblxuZXhwb3J0IHR5cGUgRW52aXJvbm1lbnROYW1lID0gJ2xvY2FsJyB8ICdzdGFnaW5nJyB8ICdwcm9kdWN0aW9uJztcblxuZXhwb3J0IGludGVyZmFjZSBFbnZDb25maWcge1xuICBlbnZpcm9ubWVudDogRW52aXJvbm1lbnROYW1lO1xuICBiYXNlVXJsOiBzdHJpbmc7XG4gIHRpbWVvdXRzOiB7XG4gICAgaHR0cDogbnVtYmVyO1xuICB9O1xuICBhcnJpdmFsOiB7XG4gICAgaXRlcmF0aW9uc1BlclNlY29uZDogbnVtYmVyO1xuICAgIG1heFZ1czogbnVtYmVyO1xuICB9O1xuICB0YWdzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICBhbGxvd3NXcml0ZXM6IGJvb2xlYW47XG59XG5cbmV4cG9ydCB0eXBlIFRocmVzaG9sZFNldCA9IFJlY29yZDxzdHJpbmcsIFRocmVzaG9sZFtdPjtcblxuZXhwb3J0IGNvbnN0IHN1bW1hcnlUcmVuZFN0YXRzID0gWydhdmcnLCAnbWluJywgJ21lZCcsICdtYXgnLCAncCg5MCknLCAncCg5NSknLCAncCg5OSknXTtcblxuZXhwb3J0IGludGVyZmFjZSBXb3JrbG9hZFByb2ZpbGUge1xuICB2YWxpZGF0aW9uOiBib29sZWFuO1xuICB0YXJnZXRJdGVyYXRpb25zUGVyU2Vjb25kOiBudW1iZXI7XG4gIG1heFZ1czogbnVtYmVyO1xuICB0aGlua1RpbWVTZWNvbmRzOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgV29ya2xvYWRTdGFnZSB7XG4gIGR1cmF0aW9uOiBzdHJpbmc7XG4gIHRhcmdldDogbnVtYmVyO1xufVxuXG5leHBvcnQgdHlwZSBTdGFnZWRXb3JrbG9hZCA9XG4gIHwgJ2F1dGhlbnRpY2F0ZWRMb2FkJ1xuICB8ICdhdXRoZW50aWNhdGVkU3RyZXNzJ1xuICB8ICdzdHJlc3MnXG4gIHwgJ3NwaWtlJ1xuICB8ICdzb2FrJ1xuICB8ICdicmVha3BvaW50JztcblxuZXhwb3J0IHR5cGUgV29ya2xvYWRTY2VuYXJpbyA9IFNjZW5hcmlvT3B0aW9ucztcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFBQUEsYUFBc0I7QUFDdEIsdUJBQXNCO0FBQ3RCLElBQUFDLGVBQWlCO0FBQ2pCLElBQUFDLGtCQUF3Qjs7O0FDRGpCLElBQU0sY0FBeUI7QUFBQSxFQUNwQyxhQUFhO0FBQUEsRUFDYixTQUFTO0FBQUEsRUFDVCxVQUFVLEVBQUUsTUFBTSxJQUFPO0FBQUEsRUFDekIsU0FBUyxFQUFFLHFCQUFxQixJQUFJLFFBQVEsSUFBSTtBQUFBLEVBQ2hELE1BQU0sRUFBRSxLQUFLLFNBQVMsS0FBSyxVQUFVO0FBQUEsRUFDckMsY0FBYztBQUNoQjs7O0FDRE8sU0FBUyxpQkFBaUIsU0FBd0M7QUFDdkUsTUFBSSxDQUFDLFNBQVM7QUFDWixVQUFNLElBQUksTUFBTSxzREFBc0Q7QUFBQSxFQUN4RTtBQUVBLFNBQU87QUFBQSxJQUNMLGFBQWE7QUFBQSxJQUNiO0FBQUEsSUFDQSxVQUFVLEVBQUUsTUFBTSxJQUFPO0FBQUEsSUFDekIsU0FBUyxFQUFFLHFCQUFxQixJQUFJLFFBQVEsR0FBRztBQUFBLElBQy9DLE1BQU0sRUFBRSxLQUFLLGNBQWMsS0FBSyxVQUFVO0FBQUEsSUFDMUMsY0FBYztBQUFBLEVBQ2hCO0FBQ0Y7OztBQ25CTyxJQUFNLGdCQUEyQjtBQUFBLEVBQ3RDLGFBQWE7QUFBQSxFQUNiLFNBQVM7QUFBQSxFQUNULFVBQVUsRUFBRSxNQUFNLElBQU87QUFBQSxFQUN6QixTQUFTLEVBQUUscUJBQXFCLElBQUksUUFBUSxJQUFJO0FBQUEsRUFDaEQsTUFBTSxFQUFFLEtBQUssV0FBVyxLQUFLLFVBQVU7QUFBQSxFQUN2QyxjQUFjO0FBQ2hCOzs7QUNKQSxJQUFNLFVBQXFFO0FBQUEsRUFDekUsT0FBTztBQUFBLEVBQ1AsU0FBUztBQUNYO0FBUU8sU0FBUyxVQUFVLE1BQWMsTUFBTSxjQUFjLFNBQW9CO0FBQzlFLE1BQUksUUFBUSxjQUFjO0FBQ3hCLFdBQU87QUFBQSxNQUNMLEdBQUcsaUJBQWlCLE1BQU0sUUFBUTtBQUFBLE1BQ2xDLGNBQWMsTUFBTSx5QkFBeUI7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFFBQVEsV0FBVyxRQUFRLFdBQVc7QUFDeEMsV0FBTztBQUFBLE1BQ0wsR0FBRyxRQUFRLEdBQUc7QUFBQSxNQUNkLFNBQVMsTUFBTSxZQUFZLFFBQVEsR0FBRyxFQUFFO0FBQUEsTUFDeEMsY0FDRSxRQUFRLFlBQVksTUFBTSx5QkFBeUIsU0FBUyxRQUFRLEdBQUcsRUFBRTtBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUVBLFFBQU0sSUFBSSxNQUFNLHdCQUF3QixHQUFHLEdBQUc7QUFDaEQ7OztBQ2hDTyxJQUFNLHdCQUF3QjtBQWtGckMsU0FBUyxlQUFlLE1BQWMsVUFBMEI7QUFDOUQsUUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixNQUFJLFFBQVEsT0FBVyxRQUFPO0FBQzlCLFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0FBQ3pDLFVBQU0sSUFBSSxNQUFNLEdBQUcsSUFBSSw0QkFBNEI7QUFBQSxFQUNyRDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsbUJBQXlCO0FBQ2hDLE1BQUksTUFBTSxlQUFlLFFBQVc7QUFDbEMsVUFBTSxJQUFJO0FBQUEsTUFDUjtBQUFBLElBR0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixNQUFjLFVBQTBCO0FBQy9ELFFBQU0sUUFBUSxlQUFlLE1BQU0sUUFBUTtBQUMzQyxNQUFJLENBQUMsT0FBTyxjQUFjLEtBQUssRUFBRyxPQUFNLElBQUksTUFBTSxHQUFHLElBQUksa0NBQWtDO0FBQzNGLFNBQU87QUFDVDtBQVdPLFNBQVMsd0JBQTRDO0FBQzFELG1CQUFpQjtBQUNqQixRQUFNLDBCQUEwQixlQUFlLDZCQUE2QixJQUFJO0FBQ2hGLE1BQUksMEJBQTBCLEdBQUc7QUFDL0IsVUFBTSxJQUFJLE1BQU0sNkNBQTZDO0FBQUEsRUFDL0Q7QUFDQSxRQUFNQyxXQUFVO0FBQUEsSUFDZCxtQkFBbUIsZ0JBQWdCLHVCQUF1QixHQUFHO0FBQUEsSUFDN0QsUUFBUSxnQkFBZ0IsV0FBVyxHQUFHO0FBQUEsSUFDdEMsZUFBZSxnQkFBZ0Isa0JBQWtCLEVBQUU7QUFBQSxJQUNuRCxvQkFBb0IsZ0JBQWdCLHVCQUF1QixFQUFFO0FBQUEsSUFDN0Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE9BQU8sY0FBY0EsU0FBUSxvQkFBb0JBLFNBQVEsa0JBQWtCLEdBQUc7QUFDakYsVUFBTSxJQUFJLE1BQU0saUVBQWlFO0FBQUEsRUFDbkY7QUFDQSxTQUFPQTtBQUNUO0FBT08sU0FBUyxxQkFBc0M7QUFDcEQsUUFBTUMsVUFBUyxVQUFVO0FBQ3pCLG1CQUFpQjtBQUNqQixTQUFPO0FBQUEsSUFDTCxZQUFZLE1BQU0saUJBQWlCO0FBQUEsSUFDbkMsMkJBQTJCO0FBQUEsTUFDekI7QUFBQSxNQUNBQSxRQUFPLFFBQVE7QUFBQSxJQUNqQjtBQUFBLElBQ0EsUUFBUSxnQkFBZ0IsV0FBV0EsUUFBTyxRQUFRLE1BQU07QUFBQSxJQUN4RCxrQkFBa0IsZUFBZSxzQkFBc0IsQ0FBQztBQUFBLEVBQzFEO0FBQ0Y7OztBQzNKQSxrQkFBNEI7QUFFNUIsSUFBTSxTQUFTLElBQUksd0JBQW9CLGVBQWUsTUFBTTtBQUMxRCxRQUFNLE1BQU0sTUFBTTtBQUNsQixNQUFJLENBQUMsSUFBSyxRQUFPLENBQUM7QUFDbEIsUUFBTSxTQUFrQixLQUFLLE1BQU0sR0FBRztBQUN0QyxNQUFJLENBQUMsTUFBTSxRQUFRLE1BQU0sS0FBSyxDQUFDLE9BQU8sTUFBTSxDQUFDLFVBQVUsT0FBTyxVQUFVLFFBQVEsR0FBRztBQUNqRixVQUFNLElBQUksTUFBTSxnREFBZ0Q7QUFBQSxFQUNsRTtBQUNBLFNBQU87QUFDVCxDQUFDOzs7QUNWRCxnQkFBc0I7OztBQ0F0QixJQUFBQyxhQUFzQjtBQUN0QixrQkFBbUU7OztBQ0RuRSxxQkFBcUM7QUFHOUIsSUFBTSxlQUFlLElBQUkscUJBQU0sMkJBQTJCLElBQUk7QUFFOUQsSUFBTSxzQkFBc0IsSUFBSSxxQkFBTSxtQ0FBbUMsSUFBSTtBQUU3RSxJQUFNLHVCQUF1QixJQUFJLHFCQUFNLG9DQUFvQyxJQUFJO0FBRS9FLElBQU0sa0JBQWtCLElBQUkscUJBQU0sOEJBQThCLElBQUk7QUFFcEUsSUFBTSxrQkFBa0IsSUFBSSxxQkFBTSw4QkFBOEIsSUFBSTtBQUVwRSxJQUFNLGNBQWMsSUFBSSxxQkFBTSwwQkFBMEIsSUFBSTtBQUU1RCxJQUFNLHNCQUFzQixJQUFJLHVCQUFRLDhCQUE4QjtBQUV0RSxJQUFNLGtCQUFrQixJQUFJLG9CQUFLLDBCQUEwQjtBQUUzRCxJQUFNLHlCQUF5QixJQUFJLG9CQUFLLGtDQUFrQztBQUUxRSxJQUFNLDBCQUEwQixJQUFJLG9CQUFLLG1DQUFtQztBQUU1RSxJQUFNLHFCQUFxQixJQUFJLG9CQUFLLDZCQUE2QjtBQUVqRSxJQUFNLHFCQUFxQixJQUFJLG9CQUFLLDZCQUE2QjtBQUVqRSxJQUFNLGlCQUFpQixJQUFJLG9CQUFLLHlCQUF5Qjs7O0FDM0JoRSxJQUFBQyxlQUE0Qjs7O0FDQTVCO0FBQUEsRUFDRSxFQUFFLE1BQVEsZ0JBQWdCLFFBQVUsSUFBSSxjQUFnQixHQUFHLGdCQUFrQixNQUFNO0FBQUEsRUFDbkYsRUFBRSxNQUFRLGtCQUFrQixRQUFVLElBQUksY0FBZ0IsSUFBSSxnQkFBa0IsS0FBSztBQUFBLEVBQ3JGLEVBQUUsTUFBUSxlQUFlLFFBQVUsSUFBSSxjQUFnQixJQUFJLGdCQUFrQixLQUFLO0FBQ3BGOzs7QURNQSxJQUFNLFlBQVksSUFBSTtBQUFBLEVBQTRCO0FBQUEsRUFBb0IsTUFDcEUseUJBQU8sSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLFNBQVMsRUFBRTtBQUM1Qzs7O0FFRE8sU0FBUywyQkFBMkIsUUFBZ0M7QUFDekUsUUFBTUMsVUFBUyxVQUFVO0FBQ3pCLFFBQU0sV0FBVyxtRUFBbUU7QUFBQSxJQUNsRkEsUUFBTztBQUFBLEVBQ1Q7QUFDQSxPQUFLQSxRQUFPLGdCQUFnQixXQUFXLENBQUMsYUFBYSxNQUFNLHlCQUF5QixRQUFRO0FBQzFGLFVBQU0sSUFBSTtBQUFBLE1BQ1IsR0FBRyxPQUFPLFFBQVEsSUFBSSxPQUFPLFFBQVEsVUFBVSxNQUFNO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBQ0Y7OztBQ0pPLFNBQVMsbUJBQ2RDLFVBQ0EsUUFNYztBQUNkLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixRQUFNLGFBQWEsQ0FBQyxVQUNsQixVQUFVLFVBQWEsT0FBTyxjQUFjLEtBQUssS0FBSyxTQUFTO0FBQ2pFLFFBQU0sYUFBYSxXQUFXLE9BQU8sVUFBVSxJQUFJLE9BQU8sYUFBYTtBQUN2RSxRQUFNLFVBQVUsV0FBVyxPQUFPLE9BQU8sSUFBSSxPQUFPLFVBQVU7QUFDOUQsUUFBTSxXQUFXLFdBQVcsT0FBTyxRQUFRLElBQUksT0FBTyxXQUFXO0FBQ2pFLFFBQU0sVUFBVSxXQUFXLE9BQU8sT0FBTyxJQUFJLE9BQU8sVUFBVTtBQUM5RCxNQUFJLGVBQWUsUUFBUSxhQUFhLFFBQVEsWUFBWSxRQUFRLFlBQVksTUFBTTtBQUNwRixZQUFRLEtBQUssc0NBQXNDO0FBQUEsRUFDckQ7QUFDQSxRQUFNLFdBQVdBLFNBQVEsb0JBQW9CQSxTQUFRO0FBQ3JELE1BQUksZUFBZSxRQUFRLGFBQWEsV0FBV0EsU0FBUSx5QkFBeUI7QUFDbEYsWUFBUSxLQUFLLHVEQUF1RDtBQUFBLEVBQ3RFO0FBQ0EsTUFBSSxhQUFhLFFBQVEsV0FBVyxXQUFXQSxTQUFRLHlCQUF5QjtBQUM5RSxZQUFRLEtBQUssa0RBQWtEO0FBQUEsRUFDakU7QUFDQSxNQUFJLGFBQWEsUUFBUSxlQUFlLFFBQVEsYUFBYSxZQUFZO0FBQ3ZFLFlBQVEsS0FBSyx1REFBdUQ7QUFBQSxFQUN0RTtBQUNBLE1BQUksWUFBWSxRQUFRLGFBQWEsUUFBUSxZQUFZLFVBQVU7QUFDakUsWUFBUSxLQUFLLHFFQUFxRTtBQUFBLEVBQ3BGO0FBQ0EsTUFBSSxhQUFhLFFBQVEsV0FBVyxXQUFXLEdBQUc7QUFDaEQsWUFBUSxLQUFLLGlEQUFpRDtBQUFBLEVBQ2hFO0FBQ0EsTUFBSSxZQUFZLFFBQVEsVUFBVSxFQUFHLFNBQVEsS0FBSywwQ0FBMEM7QUFDNUYsU0FBTztBQUFBLElBQ0wsT0FBTyxRQUFRLFdBQVc7QUFBQSxJQUMxQjtBQUFBLElBQ0EsNkJBQTZCQSxTQUFRO0FBQUEsSUFDckMsb0JBQW9CQSxTQUFRO0FBQUEsSUFDNUIseUJBQXlCQSxTQUFRO0FBQUEsSUFDakMscUJBQXFCO0FBQUEsSUFDckIsaUJBQWlCO0FBQUEsSUFDakI7QUFBQSxJQUNBLG1CQUFtQjtBQUFBLElBQ25CLDZCQUNFLGVBQWUsT0FBTyxPQUFPLGFBQWFBLFNBQVE7QUFBQSxJQUNwRCwyQkFBMkIsYUFBYSxPQUFPLE9BQU8sV0FBV0EsU0FBUTtBQUFBLEVBQzNFO0FBQ0Y7OztBQ0FBLFNBQVMsY0FBc0I7QUFDN0IsUUFBTSxPQUFPLE1BQU0sZ0JBQWdCO0FBQ25DLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBRUEsU0FBUyxlQUF1QjtBQUM5QixRQUFNLE9BQU8sTUFBTSxnQkFBZ0I7QUFDbkMsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFFQSxTQUFTLFdBQW1CO0FBQzFCLFFBQU0sT0FBTyxNQUFNLGdCQUFnQjtBQUNuQyxTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUVBLFNBQVMsVUFBVSxNQUFjLFFBQTBDO0FBQ3pFLFFBQU0sU0FBUyxRQUFRO0FBQ3ZCLFFBQU0sTUFBTSxTQUFTLE9BQU87QUFDNUIsUUFBTSxNQUFNLFNBQVMsT0FBTztBQUM1QixRQUFNLE1BQU0sU0FBUyxPQUFPO0FBQzVCLFFBQU0sTUFBTSxRQUFRO0FBQ3BCLFFBQU0sT0FBTyxRQUFRO0FBQ3JCLFFBQU0sUUFBUSxRQUFRO0FBQ3RCLFNBQU8sS0FBSyxJQUFJLE1BQU0sUUFBUSxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sS0FBSyxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sTUFBTSxRQUFRLENBQUMsS0FBSyxHQUFHLE1BQU0sU0FBUyxHQUFHO0FBQ2hOO0FBRUEsU0FBUyxnQkFBZ0IsUUFBc0IsV0FBdUM7QUFDcEYsUUFBTSxNQUFNLFVBQVUsTUFBTSw4Q0FBOEMsSUFBSSxDQUFDO0FBQy9FLFNBQU8sTUFBTSxPQUFPLEdBQXlCLElBQUk7QUFDbkQ7QUFFQSxTQUFTLFdBQVcsT0FBdUI7QUFDekMsU0FBTyxNQUNKLFdBQVcsS0FBSyxPQUFPLEVBQ3ZCLFdBQVcsS0FBSyxNQUFNLEVBQ3RCLFdBQVcsS0FBSyxNQUFNLEVBQ3RCLFdBQVcsS0FBSyxRQUFRO0FBQzdCO0FBRUEsU0FBUyxZQUFZLE9BQTJCLFNBQVMsR0FBVztBQUNsRSxTQUFPLFVBQVUsU0FBWSxNQUFNLE1BQU0sUUFBUSxNQUFNO0FBQ3pEO0FBRUEsU0FBUyxlQUFlLFNBQXVDLE9BQXlCO0FBQ3RGLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLE1BQ0osSUFBSSxDQUFDLFNBQVM7QUFDYixVQUFNLFNBQVMsUUFBUSxJQUFJLEtBQUssQ0FBQztBQUNqQyxXQUFPLFdBQVcsV0FBVyxJQUFJLENBQUMsWUFBWSxZQUFZLE9BQU8sR0FBRyxDQUFDLFlBQVksWUFBWSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFlBQVksWUFBWSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFlBQVksWUFBWSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFlBQVksWUFBWSxPQUFPLE1BQU0sQ0FBQyxDQUFDLFlBQVksT0FBTyxTQUFTLEdBQUc7QUFBQSxFQUNyUSxDQUFDLEVBQ0EsS0FBSyxFQUFFO0FBQ1o7QUFFQSxTQUFTLGtCQUFrQixTQUFxQztBQUM5RCxRQUFNLE9BQU8sT0FBTyxRQUFRLFFBQVEsVUFBVSxFQUFFO0FBQUEsSUFBUSxDQUFDLENBQUMsUUFBUSxVQUFVLE1BQzFFLE9BQU8sUUFBUSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsV0FBVyxNQUFNLE1BQU07QUFDdEQsWUFBTSxTQUFTLGdCQUFnQixRQUFRLFFBQVEsTUFBTSxLQUFLLENBQUMsR0FBRyxTQUFTO0FBQ3ZFLGFBQU8sV0FBVyxXQUFXLE1BQU0sQ0FBQyxZQUFZLFdBQVcsU0FBUyxDQUFDLFlBQVksVUFBVSxhQUFhLG1CQUFtQixPQUFPLEtBQUssV0FBVyxRQUFRLEtBQUssT0FBTyxLQUFLLFNBQVMsTUFBTTtBQUFBLElBQzVMLENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTyxLQUFLLFdBQVcsSUFDbkIsc0VBQ0EsS0FBSyxLQUFLLEVBQUU7QUFDbEI7QUFPTyxTQUFTLGNBQWMsTUFBMkM7QUFDdkUsUUFBTSxXQUFXLG1CQUFtQjtBQUNwQyxRQUFNLGlCQUFpQixNQUFNLGtCQUFrQixpQkFBaUIsc0JBQXNCLElBQUk7QUFDMUYsUUFBTSxlQUFlLGlCQUNqQixtQkFBbUIsZ0JBQWdCO0FBQUEsSUFDakMsWUFBWSxLQUFLLFFBQVEsMENBQTBDLEdBQUcsT0FBTztBQUFBLElBQzdFLFNBQVMsS0FBSyxRQUFRLGdEQUFnRCxHQUFHLE9BQU87QUFBQSxJQUNoRixVQUFVLEtBQUssUUFBUSx5Q0FBeUMsR0FBRyxPQUFPO0FBQUEsSUFDMUUsU0FBUyxLQUFLLFFBQVEsa0RBQWtELEdBQUcsT0FBTztBQUFBLEVBQ3BGLENBQUMsSUFDRDtBQUNKLFFBQU0sZ0JBQWdCLEtBQUssUUFBUSxRQUFRLE9BQU8sU0FBUztBQUMzRCxRQUFNLHdCQUNKLEtBQUssUUFBUSx3QkFBd0IsT0FBTyxTQUFTLEtBQUssTUFBTSx5QkFBeUI7QUFDM0YsUUFBTSxjQUFjLEtBQUssTUFBTSxlQUFlO0FBQzlDLFFBQU0sVUFBOEI7QUFBQSxJQUNsQztBQUFBLElBQ0EsVUFBVSxDQUFDO0FBQUEsSUFDWCxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsU0FBUyxPQUFPO0FBQUEsTUFDZCxPQUFPLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDO0FBQUEsSUFDNUU7QUFBQSxJQUNBLFVBQVU7QUFBQSxNQUNSLGFBQWEsTUFBTSxjQUFjO0FBQUEsTUFDakMsaUJBQWlCLE1BQU0sb0JBQW9CO0FBQUEsTUFDM0MsV0FBVyxNQUFNLGNBQWM7QUFBQSxNQUMvQixRQUFRLGdCQUFnQixVQUFVLFNBQVM7QUFBQSxNQUMzQyxTQUFTLE1BQU0sZ0JBQWdCO0FBQUEsTUFDL0IsYUFBYSxNQUFNLGdCQUFnQjtBQUFBLE1BQ25DLGNBQWMsTUFBTSxpQkFBaUI7QUFBQSxNQUNyQyxVQUFVLE1BQU0sYUFBYSxNQUFNLGNBQWM7QUFBQSxNQUNqRCxnQkFBZ0IsaUJBQWlCLDhCQUE4QjtBQUFBLE1BQy9ELDJCQUNFLGdCQUFnQixxQkFBcUIsU0FBUztBQUFBLE1BQ2hELHlCQUF5QixnQkFBZ0IscUJBQXFCO0FBQUEsTUFDOUQsb0JBQW9CLGdCQUFnQixzQkFBc0I7QUFBQSxNQUMxRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCx5QkFBeUIsZ0JBQWdCLDJCQUEyQjtBQUFBLE1BQ3BFLHFCQUFxQixpQkFBaUIsd0JBQXdCO0FBQUEsSUFDaEU7QUFBQSxJQUNBLFdBQVcsS0FBSztBQUFBLElBQ2hCLE9BQU8sS0FBSztBQUFBLElBQ1osWUFBWSxPQUFPO0FBQUEsTUFDakIsT0FBTyxRQUFRLEtBQUssT0FBTyxFQUN4QixPQUFPLENBQUMsQ0FBQyxFQUFFLE1BQU0sTUFBTSxPQUFPLFVBQVUsRUFDeEMsSUFBSSxDQUFDLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQyxNQUFNLE9BQU8sY0FBYyxDQUFDLENBQUMsQ0FBQztBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUNBLFFBQU0sbUJBQW1CLE9BQU8sUUFBUSxRQUFRLFVBQVUsRUFBRTtBQUFBLElBQVEsQ0FBQyxDQUFDLFFBQVEsVUFBVSxNQUN0RixPQUFPLFFBQVEsVUFBVSxFQUN0QixPQUFPLENBQUMsQ0FBQyxFQUFFLE1BQU0sTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUNqQyxJQUFJLENBQUMsQ0FBQyxTQUFTLE1BQU07QUFDcEIsWUFBTSxTQUFTLGdCQUFnQixRQUFRLFFBQVEsTUFBTSxLQUFLLENBQUMsR0FBRyxTQUFTO0FBQ3ZFLGFBQU8sR0FBRyxNQUFNLGNBQWMsU0FBUyxZQUFZLFVBQVUsYUFBYTtBQUFBLElBQzVFLENBQUM7QUFBQSxFQUNMO0FBQ0EsVUFBUSxXQUFXO0FBQUEsSUFDakIsR0FBSSxnQkFBZ0IsQ0FBQyxhQUFhLFFBQzlCLGFBQWEsUUFBUSxJQUFJLENBQUMsV0FBVyw0QkFBNEIsTUFBTSxFQUFFLElBQ3pFLENBQUM7QUFBQSxJQUNMLEdBQUcsaUJBQWlCLElBQUksQ0FBQyxZQUFZLGNBQWMsT0FBTyxFQUFFO0FBQUEsSUFDNUQsR0FBSSxnQkFBZ0IsSUFBSSxDQUFDLFdBQVcsYUFBYSxTQUFTLElBQUksQ0FBQztBQUFBLElBQy9ELEdBQUksY0FBYyxJQUFJLENBQUMsVUFBVSxXQUFXLFdBQVcsSUFBSSxDQUFDO0FBQUEsSUFDNUQsR0FBSSx3QkFBd0IsSUFDeEIsQ0FBQyxjQUFjLHFCQUFxQiwyQkFBMkIsSUFDL0QsQ0FBQztBQUFBLEVBQ1A7QUFDQSxRQUFNLFdBQVc7QUFBQSxJQUNmO0FBQUEsSUFDQTtBQUFBLElBQ0EsbUJBQW1CLFFBQVEsU0FBUyxTQUFTLFdBQVcsUUFBUTtBQUFBLElBQ2hFLGVBQWUsUUFBUSxTQUFTLFFBQVEsS0FBSyxRQUFRLFNBQVMsWUFBWTtBQUFBLElBQzFFLGdCQUFnQixRQUFRLFNBQVMsT0FBTyxPQUFPLFFBQVEsU0FBUyxXQUFXO0FBQUEsSUFDM0Usd0JBQXdCLFFBQVEsU0FBUyxjQUFjO0FBQUEsSUFDdkQsMkJBQTJCLFFBQVEsU0FBUyx5QkFBeUI7QUFBQSxJQUNyRSw0QkFBNEIsUUFBUSxTQUFTLDJCQUEyQiw4QkFBOEIsR0FBRyxpQkFBaUIsZ0JBQWdCLEVBQUU7QUFBQSxJQUM1SSxHQUFJLGVBQ0E7QUFBQSxNQUNFLG9CQUFvQixhQUFhLGtCQUFrQjtBQUFBLE1BQ25ELGlDQUFpQyxRQUFRLFNBQVMsbUJBQW1CO0FBQUEsTUFDckUsaUJBQWlCLGFBQWEsK0JBQStCLFNBQVMsNEJBQTRCLGFBQWEsNkJBQTZCLFNBQVMsZ0JBQWdCLGFBQWEscUJBQXFCLFNBQVM7QUFBQSxNQUNoTixzQkFBc0IsYUFBYSxRQUFRLFVBQVUsU0FBUyxrQ0FBa0MsYUFBYSx1QkFBdUI7QUFBQSxJQUN0SSxJQUNBO0FBQUEsTUFDRSxnQ0FBZ0MsUUFBUSxRQUFRLFlBQVksUUFBUSxTQUFTLGtCQUFrQixRQUFRLFFBQVEsV0FBVyxRQUFRLFNBQVM7QUFBQSxJQUM3STtBQUFBLElBQ0osR0FBSSxRQUFRLFNBQVMsU0FBUyxDQUFDLElBQUksR0FBRyxRQUFRLFNBQVMsSUFBSSxDQUFDLFlBQVksS0FBSyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUM7QUFBQSxJQUM1RjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxVQUFVLHFCQUFxQixRQUFRLFFBQVEsaUJBQWlCO0FBQUEsSUFDaEUsVUFBVSxtQkFBbUIsUUFBUSxRQUFRLGVBQWU7QUFBQSxJQUM1RCxVQUFVLFVBQVUsUUFBUSxRQUFRLE1BQU07QUFBQSxJQUMxQyxVQUFVLGFBQWEsUUFBUSxRQUFRLFNBQVM7QUFBQSxJQUNoRCxVQUFVLGNBQWMsUUFBUSxRQUFRLFVBQVU7QUFBQSxJQUNsRCxVQUFVLG1DQUFtQyxRQUFRLFFBQVEsK0JBQStCO0FBQUEsSUFDNUYsVUFBVSxnQ0FBZ0MsUUFBUSxRQUFRLDRCQUE0QjtBQUFBLElBQ3RGO0FBQUEsRUFDRixFQUFFLEtBQUssSUFBSTtBQUNYLFFBQU0sV0FBVyxRQUFRLFFBQVEscUJBQXFCLENBQUM7QUFDdkQsUUFBTSxPQUFPO0FBQUEsSUFDWCxDQUFDLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFBQSxJQUN6QixDQUFDLE9BQU8sU0FBUyxPQUFPLEtBQUssQ0FBQztBQUFBLElBQzlCLENBQUMsT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDO0FBQUEsSUFDOUIsQ0FBQyxPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUM7QUFBQSxJQUM5QixDQUFDLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFBQSxFQUMzQjtBQUNBLFFBQU0sVUFBVSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUUsS0FBSyxNQUFNLEtBQUssR0FBRyxDQUFDO0FBQzdELFFBQU0sUUFBUSxLQUNYO0FBQUEsSUFDQyxDQUFDLENBQUMsT0FBTyxLQUFLLEdBQUcsVUFDZiw2QkFBNkIsUUFBUSxFQUFFLHlCQUF5QixLQUFLLG9DQUFxQyxRQUFRLFVBQVcsR0FBRywwQ0FBMEMsS0FBTSxRQUFRLFVBQVcsR0FBRyxZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUM7QUFBQSxFQUN0TyxFQUNDLEtBQUssRUFBRTtBQUNWLFFBQU0sa0JBQWtCLE9BQU8sS0FBSyxRQUFRLE9BQU8sRUFDaEQ7QUFBQSxJQUNDLENBQUMsU0FDQyxLQUFLLFdBQVcseUJBQXlCLEtBQUssS0FBSyxXQUFXLHVCQUF1QjtBQUFBLEVBQ3pGLEVBQ0MsS0FBSztBQUNSLFFBQU0sa0JBQWtCLE9BQU8sS0FBSyxRQUFRLE9BQU8sRUFDaEQsT0FBTyxDQUFDLFNBQVMsS0FBSyxXQUFXLFNBQVMsQ0FBQyxFQUMzQyxLQUFLO0FBQ1IsUUFBTSxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJSCxRQUFRLFNBQVMsU0FBUyxXQUFXLFFBQVEsYUFBYSxRQUFRLFNBQVMsU0FBUyxXQUFXLFFBQVE7QUFBQSwwQkFDekYsV0FBVyxRQUFRLFNBQVMsUUFBUSxDQUFDLEtBQUssV0FBVyxRQUFRLFNBQVMsWUFBWSxDQUFDLGlCQUFpQixXQUFXLFFBQVEsU0FBUyxPQUFPLENBQUMsZUFBZSxXQUFXLFFBQVEsU0FBUyxXQUFXLENBQUM7QUFBQSxnSEFDekcsS0FBSztBQUFBO0FBQUEsa0lBRWEsZUFBZSxRQUFRLFNBQVMsQ0FBQyxxQkFBcUIsbUJBQW1CLFVBQVUsYUFBYSxZQUFZLENBQUMsQ0FBQztBQUFBO0FBQUEsa0lBRTlHLGVBQWUsUUFBUSxTQUFTLGVBQWUsQ0FBQztBQUFBO0FBQUEsa0lBRWhELGVBQWUsUUFBUSxTQUFTLGVBQWUsQ0FBQztBQUFBO0FBQUEsdUdBRTNFLGtCQUFrQixPQUFPLENBQUM7QUFBQTtBQUFBLE9BRTFILFdBQVcsUUFBUSxDQUFDO0FBQUE7QUFHekIsU0FBTztBQUFBLElBQ0wsQ0FBQyxZQUFZLENBQUMsR0FBRyxLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUM7QUFBQSxJQUNoRCxDQUFDLGFBQWEsQ0FBQyxHQUFHO0FBQUEsSUFDbEIsQ0FBQyxTQUFTLENBQUMsR0FBRztBQUFBLElBQ2QsUUFBUTtBQUFBLEVBQ1Y7QUFDRjs7O0FDMVFPLElBQU0sb0JBQW9CLENBQUMsT0FBTyxPQUFPLE9BQU8sT0FBTyxTQUFTLFNBQVMsT0FBTzs7O0FmWHZGLDJCQUEyQixFQUFFLFVBQVUsOEJBQThCLENBQUM7QUFDdEUsSUFBSSxNQUFNLGtCQUFrQixnQkFBZ0I7QUFDMUMsUUFBTSxJQUFJLE1BQU0sK0RBQStEO0FBQ2pGO0FBQ0EsSUFBTSxVQUFVLHNCQUFzQjtBQUN0QyxJQUFNLFNBQVMsVUFBVTtBQUN6QixJQUFNLGVBQWUsS0FBSztBQUFBLEVBQ3hCLFFBQVEsb0JBQW9CLFFBQVEscUJBQXFCLFFBQVE7QUFDbkU7QUFDQSxJQUFNLGdCQUFnQixRQUFRLG9CQUFvQixRQUFRO0FBQzFELElBQU0sa0JBQWtCLElBQUksd0JBQVEsa0JBQWtCO0FBRS9DLElBQU0sVUFBbUI7QUFBQSxFQUM5QixXQUFXO0FBQUEsSUFDVCxnQkFBZ0I7QUFBQSxNQUNkLFVBQVU7QUFBQSxNQUNWLE1BQU07QUFBQSxNQUNOLE1BQU0sUUFBUTtBQUFBLE1BQ2QsVUFBVTtBQUFBLE1BQ1YsVUFBVSxHQUFHLFFBQVEsYUFBYTtBQUFBLE1BQ2xDLGlCQUFpQixLQUFLLElBQUksSUFBSSxRQUFRLE1BQU07QUFBQSxNQUM1QyxRQUFRLFFBQVE7QUFBQSxNQUNoQixjQUFjLEdBQUcscUJBQXFCO0FBQUEsSUFDeEM7QUFBQSxJQUNBLHFCQUFxQjtBQUFBLE1BQ25CLFVBQVU7QUFBQSxNQUNWLE1BQU07QUFBQSxNQUNOLFdBQVcsR0FBRyxRQUFRLGdCQUFnQixDQUFDO0FBQUEsTUFDdkMsTUFBTSxRQUFRO0FBQUEsTUFDZCxVQUFVO0FBQUEsTUFDVixVQUFVLEdBQUcsUUFBUSxrQkFBa0I7QUFBQSxNQUN2QyxpQkFBaUIsS0FBSyxJQUFJLElBQUksUUFBUSxNQUFNO0FBQUEsTUFDNUMsUUFBUSxRQUFRO0FBQUEsTUFDaEIsY0FBYyxHQUFHLHFCQUFxQjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFFQSxZQUFZO0FBQUEsSUFDVixrREFBa0Q7QUFBQSxNQUNoRCxVQUFVLFlBQVk7QUFBQSxNQUN0QixVQUFVLGdCQUFnQixDQUFDO0FBQUEsSUFDN0I7QUFBQSxJQUNBLDJDQUEyQztBQUFBLE1BQ3pDLFVBQVUsWUFBWTtBQUFBLE1BQ3RCLFVBQVUsZ0JBQWdCLENBQUM7QUFBQSxJQUM3QjtBQUFBLElBQ0EsNENBQTRDLENBQUMsVUFBVSxZQUFZLEVBQUU7QUFBQSxJQUNyRSxvREFBb0QsQ0FBQyxVQUFVO0FBQUEsSUFDL0Qsd0NBQXdDLENBQUMsU0FBUztBQUFBLElBQ2xELGlEQUFpRCxDQUFDLFdBQVc7QUFBQSxJQUM3RCxtREFBbUQsQ0FBQyxZQUFZLFdBQVc7QUFBQSxFQUM3RTtBQUFBLEVBQ0EsY0FBYztBQUFBLEVBQ2Q7QUFDRjtBQUdPLFNBQVMsZ0JBQXNCO0FBQ3BDLFFBQU0sT0FDSixpQkFBQUMsUUFBVSxTQUFTLGtCQUFrQixNQUFNLElBQUksVUFBVTtBQUMzRCxrQkFBZ0IsSUFBSSxDQUFDO0FBQ3JCLFFBQU0sV0FBVyxhQUFBQyxRQUFLLElBQUksR0FBRyxPQUFPLFFBQVEsUUFBUSxPQUFPLEVBQUUsQ0FBQyxHQUFHLElBQUksSUFBSTtBQUFBLElBQ3ZFLFdBQVc7QUFBQSxJQUNYLFNBQVM7QUFBQSxJQUNULFNBQVMsRUFBRSxnQkFBZ0IsaUJBQUFELFFBQVUsU0FBUyxLQUFLO0FBQUEsSUFDbkQsTUFBTSxFQUFFLEdBQUcsT0FBTyxNQUFNLE1BQU0sS0FBSyxXQUFXLE9BQU8sSUFBSSxjQUFjLGdCQUFnQjtBQUFBLEVBQ3pGLENBQUM7QUFDRCx3QkFBTSxVQUFVLEVBQUUsZ0NBQWdDLENBQUMsV0FBVyxPQUFPLFdBQVcsSUFBSSxDQUFDO0FBQ3ZGO0FBRU8sSUFBTSxnQkFBZ0I7IiwKICAibmFtZXMiOiBbImltcG9ydF9rNiIsICJpbXBvcnRfaHR0cCIsICJpbXBvcnRfbWV0cmljcyIsICJwcm9maWxlIiwgImNvbmZpZyIsICJpbXBvcnRfazYiLCAiaW1wb3J0X2RhdGEiLCAiY29uZmlnIiwgInByb2ZpbGUiLCAiZXhlY3V0aW9uIiwgImh0dHAiXQp9Cg==
