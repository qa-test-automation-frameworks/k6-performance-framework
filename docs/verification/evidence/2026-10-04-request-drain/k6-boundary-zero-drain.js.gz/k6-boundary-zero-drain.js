"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// tests/load/request-rate-load.ts
var request_rate_load_exports = {};
__export(request_rate_load_exports, {
  handleSummary: () => handleSummary,
  options: () => options,
  singleRequest: () => singleRequest
});
module.exports = __toCommonJS(request_rate_load_exports);
var import_k63 = require("k6");
var import_execution = __toESM(require("k6/execution"));
var import_http2 = __toESM(require("k6/http"));

// config/environments/local.ts
var localConfig = {
  environment: "local",
  baseUrl: "http://localhost:3000/api",
  timeouts: { http: 3e4 },
  arrival: { iterationsPerSecond: 20, maxVus: 100 },
  tags: { env: "local", app: "conduit" },
  allowsWrites: true
};

// config/environments/production.ts
function productionConfig(baseUrl) {
  if (!baseUrl) {
    throw new Error('BASE_URL is required when TARGET_ENV is "production"');
  }
  return {
    environment: "production",
    baseUrl,
    timeouts: { http: 3e4 },
    arrival: { iterationsPerSecond: 10, maxVus: 50 },
    tags: { env: "production", app: "conduit" },
    allowsWrites: false
  };
}

// config/environments/staging.ts
var stagingConfig = {
  environment: "staging",
  baseUrl: "https://api.realworld.show/api",
  timeouts: { http: 3e4 },
  arrival: { iterationsPerSecond: 50, maxVus: 400 },
  tags: { env: "staging", app: "conduit" },
  allowsWrites: false
};

// config/index.ts
var configs = {
  local: localConfig,
  staging: stagingConfig
};
function getConfig(env = __ENV.TARGET_ENV ?? "local") {
  if (env === "production") {
    return {
      ...productionConfig(__ENV.BASE_URL),
      allowsWrites: __ENV.ALLOW_NON_LOCAL_LOAD === "true"
    };
  }
  if (env === "local" || env === "staging") {
    return {
      ...configs[env],
      baseUrl: __ENV.BASE_URL ?? configs[env].baseUrl,
      allowsWrites: env === "staging" ? __ENV.ALLOW_NON_LOCAL_LOAD === "true" : configs[env].allowsWrites
    };
  }
  throw new Error(`Unknown TARGET_ENV: "${env}"`);
}

// config/workloads.ts
function positiveNumber(name, fallback) {
  const raw = __ENV[name];
  if (raw === void 0) return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`${name} must be a positive number`);
  }
  return value;
}
function rejectLegacyRate() {
  if (__ENV.TARGET_RPS !== void 0) {
    throw new Error(
      "TARGET_RPS is ambiguous and has been removed. For the existing journey use TARGET_ITERATIONS_PER_SECOND (old arrival-iteration semantics); for one request per iteration use REQUESTS_PER_SECOND with the dedicated request-rate entry point."
    );
  }
}
function positiveInteger(name, fallback) {
  const value = positiveNumber(name, fallback);
  if (!Number.isSafeInteger(value)) throw new Error(`${name} must be a positive safe integer`);
  return value;
}
function getRequestRateProfile() {
  rejectLegacyRate();
  const minimumAchievedFraction = positiveNumber("MINIMUM_ACHIEVED_FRACTION", 0.98);
  if (minimumAchievedFraction > 1) {
    throw new Error("MINIMUM_ACHIEVED_FRACTION must be at most 1");
  }
  const profile2 = {
    requestsPerSecond: positiveInteger("REQUESTS_PER_SECOND", 500),
    maxVus: positiveInteger("MAX_VUS", 100),
    warmupSeconds: positiveInteger("WARMUP_SECONDS", 10),
    measurementSeconds: positiveInteger("MEASUREMENT_SECONDS", 60),
    minimumAchievedFraction
  };
  if (!Number.isSafeInteger(profile2.requestsPerSecond * profile2.measurementSeconds)) {
    throw new Error("Configured measurement request count exceeds safe integer range");
  }
  return profile2;
}
function getWorkloadProfile() {
  const config2 = getConfig();
  rejectLegacyRate();
  return {
    validation: __ENV.TEST_PROFILE === "validation",
    targetIterationsPerSecond: positiveInteger(
      "TARGET_ITERATIONS_PER_SECOND",
      config2.arrival.iterationsPerSecond
    ),
    maxVus: positiveInteger("MAX_VUS", config2.arrival.maxVus),
    thinkTimeSeconds: positiveNumber("THINK_TIME_SECONDS", 1)
  };
}

// src/helpers/auth.ts
var import_data = require("k6/data");
var tokens = new import_data.SharedArray("user tokens", () => {
  const raw = __ENV.K6_USER_TOKENS;
  if (!raw) return [];
  const parsed = JSON.parse(raw);
  if (!Array.isArray(parsed) || !parsed.every((value) => typeof value === "string")) {
    throw new Error("K6_USER_TOKENS must be a JSON array of strings");
  }
  return parsed;
});

// src/helpers/checks.ts
var import_k6 = require("k6");

// src/utils/http-client.ts
var import_k62 = require("k6");
var import_http = __toESM(require("k6/http"));

// src/utils/metrics.ts
var import_metrics = require("k6/metrics");
var authDuration = new import_metrics.Trend("custom_auth_duration_ms", true);
var articleReadDuration = new import_metrics.Trend("custom_article_read_duration_ms", true);
var articleWriteDuration = new import_metrics.Trend("custom_article_write_duration_ms", true);
var commentDuration = new import_metrics.Trend("custom_comment_duration_ms", true);
var profileDuration = new import_metrics.Trend("custom_profile_duration_ms", true);
var tagDuration = new import_metrics.Trend("custom_tag_duration_ms", true);
var totalBusinessErrors = new import_metrics.Counter("custom_business_errors_total");
var authSuccessRate = new import_metrics.Rate("custom_auth_success_rate");
var articleReadSuccessRate = new import_metrics.Rate("custom_article_read_success_rate");
var articleWriteSuccessRate = new import_metrics.Rate("custom_article_write_success_rate");
var commentSuccessRate = new import_metrics.Rate("custom_comment_success_rate");
var profileSuccessRate = new import_metrics.Rate("custom_profile_success_rate");
var tagSuccessRate = new import_metrics.Rate("custom_tag_success_rate");

// src/fixtures/browse-behaviors.ts
var import_data2 = require("k6/data");

// src/fixtures/browse-behaviors.json
var browse_behaviors_default = [
  { name: "quick-reader", weight: 50, articleLimit: 5, inspectArticle: false },
  { name: "article-reader", weight: 35, articleLimit: 10, inspectArticle: true },
  { name: "deep-reader", weight: 15, articleLimit: 20, inspectArticle: true }
];

// src/fixtures/browse-behaviors.ts
var behaviors = new import_data2.SharedArray(
  "browse behaviors",
  () => browse_behaviors_default.map((behavior) => ({ ...behavior }))
);

// src/helpers/safety.ts
function assertAuthorizedLoadTarget(policy) {
  const config2 = getConfig();
  const loopback = /^https?:\/\/(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(?:\/|$)/i.test(
    config2.baseUrl
  );
  if ((config2.environment !== "local" || !loopback) && __ENV.ALLOW_NON_LOCAL_LOAD !== "true") {
    throw new Error(
      `${policy.workload} ${policy.write ? "write" : "load"} traffic requires a loopback local target or explicit owned-target ALLOW_NON_LOCAL_LOAD=true`
    );
  }
}

// src/helpers/achieved-load.ts
function assessAchievedLoad(profile2, counts) {
  const reasons = [];
  const validCount = (value) => value !== void 0 && Number.isSafeInteger(value) && value >= 0;
  const iterations = validCount(counts.iterations) ? counts.iterations : null;
  const requests = validCount(counts.requests) ? counts.requests : null;
  const dropped = validCount(counts.dropped) ? counts.dropped : null;
  if (iterations === null || requests === null || dropped === null) {
    reasons.push("Missing or invalid measurement count");
  }
  const expected = profile2.requestsPerSecond * profile2.measurementSeconds;
  if (iterations !== null && iterations < expected * profile2.minimumAchievedFraction) {
    reasons.push("Achieved arrival iterations below predeclared minimum");
  }
  if (requests !== null && requests < expected * profile2.minimumAchievedFraction) {
    reasons.push("Achieved HTTP requests below predeclared minimum");
  }
  if (requests !== null && iterations !== null && requests !== iterations) {
    reasons.push("One-request-per-completed-iteration contract violated");
  }
  if (requests !== null && requests > expected + 1) {
    reasons.push("Request count exceeds configured arrival cohort");
  }
  if (dropped !== null && dropped > 0) reasons.push("Generator dropped measurement iterations");
  return {
    valid: reasons.length === 0,
    reasons,
    configuredRequestsPerSecond: profile2.requestsPerSecond,
    measurementSeconds: profile2.measurementSeconds,
    minimumAchievedFraction: profile2.minimumAchievedFraction,
    completedIterations: iterations,
    requests,
    droppedIterations: dropped,
    achievedIterationsPerSecond: iterations === null ? null : iterations / profile2.measurementSeconds,
    achievedRequestsPerSecond: requests === null ? null : requests / profile2.measurementSeconds
  };
}

// src/helpers/summary.ts
function summaryFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.json`;
}
function markdownFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.md`;
}
function htmlFile() {
  const name = __ENV.SUMMARY_NAME ?? "k6-summary";
  return `reports/${name}-summary.html`;
}
function metricRow(name, values) {
  const median = values?.med;
  const p90 = values?.["p(90)"];
  const p95 = values?.["p(95)"];
  const p99 = values?.["p(99)"];
  const max = values?.max;
  const rate = values?.rate;
  const count = values?.count;
  return `| ${name} | ${median?.toFixed(2) ?? "-"} | ${p90?.toFixed(2) ?? "-"} | ${p95?.toFixed(2) ?? "-"} | ${p99?.toFixed(2) ?? "-"} | ${max?.toFixed(2) ?? "-"} | ${rate?.toFixed(4) ?? "-"} | ${count ?? "-"} |`;
}
function thresholdActual(values, threshold) {
  const key = threshold.match(/^(p\(\d+\)|avg|med|min|max|rate|count|value)/)?.[1];
  return key ? values[key] : void 0;
}
function htmlEscape(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
function metricValue(value, digits = 2) {
  return value === void 0 ? "-" : value.toFixed(digits);
}
function htmlMetricRows(metrics, names) {
  if (names.length === 0) {
    return '<tr><td colspan="7">No matching metrics were emitted.</td></tr>';
  }
  return names.map((name) => {
    const values = metrics[name] ?? {};
    return `<tr><td>${htmlEscape(name)}</td><td>${metricValue(values.med)}</td><td>${metricValue(values["p(90)"])}</td><td>${metricValue(values["p(95)"])}</td><td>${metricValue(values["p(99)"])}</td><td>${metricValue(values.rate, 4)}</td><td>${values.count ?? "-"}</td></tr>`;
  }).join("");
}
function htmlThresholdRows(summary) {
  const rows = Object.entries(summary.thresholds).flatMap(
    ([metric, thresholds]) => Object.entries(thresholds).map(([threshold, result]) => {
      const actual = thresholdActual(summary.metrics[metric] ?? {}, threshold);
      return `<tr><td>${htmlEscape(metric)}</td><td>${htmlEscape(threshold)}</td><td>${actual ?? "unavailable"}</td><td class="${result.ok ? "passed" : "failed"}">${result.ok ? "PASS" : "FAIL"}</td></tr>`;
    })
  );
  return rows.length === 0 ? '<tr><td colspan="4">No threshold results were reported.</td></tr>' : rows.join("");
}
function createSummary(data) {
  const workload = getWorkloadProfile();
  const requestProfile = __ENV.WORKLOAD_MODE === "request-rate" ? getRequestRateProfile() : null;
  const achievedLoad = requestProfile ? assessAchievedLoad(requestProfile, {
    iterations: data.metrics["iterations{scenario:request_measurement}"]?.values.count,
    requests: data.metrics["http_reqs{scenario:request_measurement}"]?.values.count,
    dropped: data.metrics["dropped_iterations{scenario:request_measurement}"]?.values.count
  }) : null;
  const checkFailures = data.metrics.checks?.values.fails ?? 0;
  const interruptedIterations = data.metrics.interrupted_iterations?.values.count ?? data.state.interruptedIterations ?? 0;
  const setupErrors = data.state.setupErrors ?? 0;
  const summary = {
    achievedLoad,
    failures: [],
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    metrics: Object.fromEntries(
      Object.entries(data.metrics).map(([name, metric]) => [name, metric.values])
    ),
    metadata: {
      environment: __ENV.TARGET_ENV ?? "local",
      frameworkCommit: __ENV.FRAMEWORK_COMMIT ?? "unknown",
      k6Version: __ENV.K6_VERSION ?? "2.0.0",
      maxVus: requestProfile?.maxVus ?? workload.maxVus,
      profile: __ENV.TEST_PROFILE ?? "full",
      runnerClass: __ENV.RUNNER_CLASS ?? "local",
      targetCommit: __ENV.TARGET_COMMIT ?? "unknown",
      targetId: __ENV.TARGET_ID ?? __ENV.TARGET_ENV ?? "local",
      workloadSchema: requestProfile ? "single-request-arrival-v1" : "journey-arrival-v1",
      targetIterationsPerSecond: requestProfile?.requestsPerSecond ?? workload.targetIterationsPerSecond,
      targetRequestsPerSecond: requestProfile?.requestsPerSecond ?? null,
      measurementSeconds: requestProfile?.measurementSeconds ?? null,
      warmupSeconds: requestProfile?.warmupSeconds ?? null,
      minimumAchievedFraction: requestProfile?.minimumAchievedFraction ?? null
    },
    rootGroup: data.root_group,
    state: data.state,
    thresholds: Object.fromEntries(
      Object.entries(data.metrics).filter(([, metric]) => metric.thresholds).map(([name, metric]) => [name, metric.thresholds ?? {}])
    )
  };
  const failedThresholds = Object.entries(summary.thresholds).flatMap(
    ([metric, thresholds]) => Object.entries(thresholds).filter(([, result]) => !result.ok).map(([threshold]) => {
      const actual = thresholdActual(summary.metrics[metric] ?? {}, threshold);
      return `${metric}: expected ${threshold}; actual ${actual ?? "unavailable"}`;
    })
  );
  summary.failures = [
    ...achievedLoad && !achievedLoad.valid ? achievedLoad.reasons.map((reason) => `Invalid load experiment: ${reason}`) : [],
    ...failedThresholds.map((failure) => `Threshold: ${failure}`),
    ...checkFailures > 0 ? [`Checks: ${checkFailures} failed`] : [],
    ...setupErrors > 0 ? [`Setup: ${setupErrors} error(s)`] : [],
    ...interruptedIterations > 0 ? [`Execution: ${interruptedIterations} interrupted iteration(s)`] : []
  ];
  const markdown = [
    "# k6 Performance Summary",
    "",
    `**Run status:** ${summary.failures.length ? "FAILED" : "PASSED"}`,
    `**Target:** ${summary.metadata.targetId} (${summary.metadata.targetCommit})`,
    `**Profile:** ${summary.metadata.profile} on ${summary.metadata.runnerClass}`,
    `**Workload schema:** ${summary.metadata.workloadSchema}`,
    `**Configured arrival:** ${summary.metadata.targetIterationsPerSecond} iterations/s`,
    `**Configured requests:** ${summary.metadata.targetRequestsPerSecond ?? "not fixed by journey arrival"}${requestProfile ? " requests/s" : ""}`,
    ...achievedLoad ? [
      `**Measurement:** ${achievedLoad.measurementSeconds}s scheduled arrival window, excluding warm-up and the 2s settling gap`,
      `**Achieved:** ${achievedLoad.achievedIterationsPerSecond ?? "unknown"} completed iterations/s; ${achievedLoad.achievedRequestsPerSecond ?? "unknown"} requests/s; ${achievedLoad.droppedIterations ?? "unknown"} dropped iterations`,
      `**Load validity:** ${achievedLoad.valid ? "VALID" : "INVALID"} (predeclared minimum fraction ${achievedLoad.minimumAchievedFraction})`
    ] : [
      `**Observed full-run rates:** ${summary.metrics.iterations?.rate ?? "unknown"} iterations/s; ${summary.metrics.http_reqs?.rate ?? "unknown"} requests/s (native full-run denominator, not a separated steady-state window)`
    ],
    ...summary.failures.length ? ["", ...summary.failures.map((failure) => `- ${failure}`)] : [],
    "",
    "| Metric | p50 | p90 | p95 | p99 | max | Rate | Count |",
    "|---|---:|---:|---:|---:|---:|---:|---:|",
    metricRow("http_req_duration", summary.metrics.http_req_duration),
    metricRow("http_req_failed", summary.metrics.http_req_failed),
    metricRow("checks", summary.metrics.checks),
    metricRow("http_reqs", summary.metrics.http_reqs),
    metricRow("iterations", summary.metrics.iterations),
    metricRow("custom_article_read_duration_ms", summary.metrics.custom_article_read_duration_ms),
    metricRow("custom_business_errors_total", summary.metrics.custom_business_errors_total),
    ""
  ].join("\n");
  const duration = summary.metrics.http_req_duration ?? {};
  const bars = [
    ["p50", duration.med ?? 0],
    ["p90", duration["p(90)"] ?? 0],
    ["p95", duration["p(95)"] ?? 0],
    ["p99", duration["p(99)"] ?? 0],
    ["max", duration.max ?? 0]
  ];
  const maximum = Math.max(...bars.map(([, value]) => value), 1);
  const chart = bars.map(
    ([label, value], index) => `<g transform="translate(0 ${index * 42})"><text x="0" y="20">${label}</text><rect x="48" y="4" width="${value / maximum * 500}" height="22" fill="#2563eb"/><text x="${56 + value / maximum * 500}" y="20">${value.toFixed(2)} ms</text></g>`
  ).join("");
  const endpointMetrics = Object.keys(summary.metrics).filter(
    (name) => name.startsWith("http_req_duration{name:") || name.startsWith("http_req_failed{name:")
  ).sort();
  const businessMetrics = Object.keys(summary.metrics).filter((name) => name.startsWith("custom_")).sort();
  const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>k6 Performance Summary</title>
<style>body{font:16px system-ui;max-width:1120px;margin:40px auto;padding:0 20px;color:#18212f}table{border-collapse:collapse;width:100%;margin:12px 0 28px}th,td{padding:8px;border:1px solid #ccd3dc;text-align:left}th{background:#f4f7fb}.failed{color:#b91c1c;font-weight:700}.passed{color:#047857;font-weight:700}.meta{line-height:1.6}.chart{margin:12px 0 28px}</style></head>
<body><h1>k6 Performance Summary</h1>
<p class="${summary.failures.length ? "failed" : "passed"}"><strong>${summary.failures.length ? "FAILED" : "PASSED"}</strong></p>
<p class="meta">Target: ${htmlEscape(summary.metadata.targetId)} (${htmlEscape(summary.metadata.targetCommit)})<br>Profile: ${htmlEscape(summary.metadata.profile)}<br>Runner: ${htmlEscape(summary.metadata.runnerClass)}</p>
<svg class="chart" role="img" aria-label="Latency percentiles" width="720" height="230" viewBox="0 0 720 230">${chart}</svg>
<h2>Core Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, ["http_req_duration", "http_req_failed", "checks", "http_reqs", "iterations"])}</tbody></table>
<h2>Endpoint Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, endpointMetrics)}</tbody></table>
<h2>Business Metrics</h2>
<table><thead><tr><th>Metric</th><th>p50</th><th>p90</th><th>p95</th><th>p99</th><th>Rate</th><th>Count</th></tr></thead><tbody>${htmlMetricRows(summary.metrics, businessMetrics)}</tbody></table>
<h2>Thresholds</h2>
<table><thead><tr><th>Metric</th><th>Threshold</th><th>Actual</th><th>Status</th></tr></thead><tbody>${htmlThresholdRows(summary)}</tbody></table>
<h2>Markdown Summary</h2>
<pre>${htmlEscape(markdown)}</pre>
</body></html>`;
  return {
    [summaryFile()]: JSON.stringify(summary, null, 2),
    [markdownFile()]: markdown,
    [htmlFile()]: html,
    stdout: markdown
  };
}

// src/types/config.types.ts
var summaryTrendStats = ["avg", "min", "med", "max", "p(90)", "p(95)", "p(99)"];

// tests/load/request-rate-load.ts
assertAuthorizedLoadTarget({ workload: "Single-request arrival load" });
if (__ENV.WORKLOAD_MODE !== "request-rate") {
  throw new Error("Set WORKLOAD_MODE=request-rate for this dedicated entry point");
}
var profile = getRequestRateProfile();
var config = getConfig();
var minimumCount = Math.ceil(
  profile.requestsPerSecond * profile.measurementSeconds * profile.minimumAchievedFraction
);
var expectedCount = profile.requestsPerSecond * profile.measurementSeconds;
var options = {
  scenarios: {
    request_warmup: {
      executor: "constant-arrival-rate",
      exec: "singleRequest",
      rate: profile.requestsPerSecond,
      timeUnit: "1s",
      duration: `${profile.warmupSeconds}s`,
      preAllocatedVUs: Math.min(20, profile.maxVus),
      maxVUs: profile.maxVus,
      gracefulStop: "0s"
    },
    request_measurement: {
      executor: "constant-arrival-rate",
      exec: "singleRequest",
      startTime: `${profile.warmupSeconds + 2}s`,
      rate: profile.requestsPerSecond,
      timeUnit: "1s",
      duration: `${profile.measurementSeconds}s`,
      preAllocatedVUs: Math.min(20, profile.maxVus),
      maxVUs: profile.maxVus,
      gracefulStop: "0s"
    }
  },
  // Creating submetrics through thresholds makes their count available in the native summary.
  thresholds: {
    "http_reqs{scenario:request_measurement}": [
      `count>=${minimumCount}`,
      `count<=${expectedCount + 1}`
    ],
    "iterations{scenario:request_measurement}": [`count>=${minimumCount}`],
    "dropped_iterations{scenario:request_measurement}": ["count==0"],
    "checks{scenario:request_measurement}": ["rate==1"],
    "http_req_failed{scenario:request_measurement}": ["rate<0.01"],
    "http_req_duration{scenario:request_measurement}": ["p(95)<80", "p(99)<150"]
  },
  maxRedirects: 0,
  summaryTrendStats
};
function singleRequest() {
  const path = import_execution.default.scenario.iterationInTest % 5 === 4 ? "/tags" : "/articles?limit=10&offset=0";
  const response = import_http2.default.get(`${config.baseUrl.replace(/\/$/, "")}${path}`, {
    redirects: 0,
    timeout: "1s",
    headers: { "X-Load-Phase": import_execution.default.scenario.name },
    tags: { ...config.tags, name: path.startsWith("/tags") ? "GET /tags" : "GET /articles" }
  });
  (0, import_k63.check)(response, { "single request status is 200": (result) => result.status === 200 });
}
var handleSummary = createSummary;
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vdGVzdHMvbG9hZC9yZXF1ZXN0LXJhdGUtbG9hZC50cyIsICIuLi8uLi9jb25maWcvZW52aXJvbm1lbnRzL2xvY2FsLnRzIiwgIi4uLy4uL2NvbmZpZy9lbnZpcm9ubWVudHMvcHJvZHVjdGlvbi50cyIsICIuLi8uLi9jb25maWcvZW52aXJvbm1lbnRzL3N0YWdpbmcudHMiLCAiLi4vLi4vY29uZmlnL2luZGV4LnRzIiwgIi4uLy4uL2NvbmZpZy93b3JrbG9hZHMudHMiLCAiLi4vLi4vc3JjL2hlbHBlcnMvYXV0aC50cyIsICIuLi8uLi9zcmMvaGVscGVycy9jaGVja3MudHMiLCAiLi4vLi4vc3JjL3V0aWxzL2h0dHAtY2xpZW50LnRzIiwgIi4uLy4uL3NyYy91dGlscy9tZXRyaWNzLnRzIiwgIi4uLy4uL3NyYy9maXh0dXJlcy9icm93c2UtYmVoYXZpb3JzLnRzIiwgIi4uLy4uL3NyYy9maXh0dXJlcy9icm93c2UtYmVoYXZpb3JzLmpzb24iLCAiLi4vLi4vc3JjL2hlbHBlcnMvc2FmZXR5LnRzIiwgIi4uLy4uL3NyYy9oZWxwZXJzL2FjaGlldmVkLWxvYWQudHMiLCAiLi4vLi4vc3JjL2hlbHBlcnMvc3VtbWFyeS50cyIsICIuLi8uLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBjaGVjayB9IGZyb20gJ2s2JztcbmltcG9ydCBleGVjdXRpb24gZnJvbSAnazYvZXhlY3V0aW9uJztcbmltcG9ydCBodHRwIGZyb20gJ2s2L2h0dHAnO1xuaW1wb3J0IHR5cGUgeyBPcHRpb25zIH0gZnJvbSAnazYvb3B0aW9ucyc7XG5pbXBvcnQgeyBnZXRDb25maWcgfSBmcm9tICcuLi8uLi9jb25maWcnO1xuaW1wb3J0IHsgZ2V0UmVxdWVzdFJhdGVQcm9maWxlIH0gZnJvbSAnLi4vLi4vY29uZmlnL3dvcmtsb2Fkcyc7XG5pbXBvcnQgeyBhc3NlcnRBdXRob3JpemVkTG9hZFRhcmdldCwgY3JlYXRlU3VtbWFyeSB9IGZyb20gJy4uLy4uL3NyYy9oZWxwZXJzJztcbmltcG9ydCB7IHN1bW1hcnlUcmVuZFN0YXRzIH0gZnJvbSAnLi4vLi4vc3JjL3R5cGVzL2NvbmZpZy50eXBlcyc7XG5cbmFzc2VydEF1dGhvcml6ZWRMb2FkVGFyZ2V0KHsgd29ya2xvYWQ6ICdTaW5nbGUtcmVxdWVzdCBhcnJpdmFsIGxvYWQnIH0pO1xuaWYgKF9fRU5WLldPUktMT0FEX01PREUgIT09ICdyZXF1ZXN0LXJhdGUnKSB7XG4gIHRocm93IG5ldyBFcnJvcignU2V0IFdPUktMT0FEX01PREU9cmVxdWVzdC1yYXRlIGZvciB0aGlzIGRlZGljYXRlZCBlbnRyeSBwb2ludCcpO1xufVxuY29uc3QgcHJvZmlsZSA9IGdldFJlcXVlc3RSYXRlUHJvZmlsZSgpO1xuY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnKCk7XG5jb25zdCBtaW5pbXVtQ291bnQgPSBNYXRoLmNlaWwoXG4gIHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQgKiBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcyAqIHByb2ZpbGUubWluaW11bUFjaGlldmVkRnJhY3Rpb24sXG4pO1xuY29uc3QgZXhwZWN0ZWRDb3VudCA9IHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQgKiBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcztcblxuZXhwb3J0IGNvbnN0IG9wdGlvbnM6IE9wdGlvbnMgPSB7XG4gIHNjZW5hcmlvczoge1xuICAgIHJlcXVlc3Rfd2FybXVwOiB7XG4gICAgICBleGVjdXRvcjogJ2NvbnN0YW50LWFycml2YWwtcmF0ZScsXG4gICAgICBleGVjOiAnc2luZ2xlUmVxdWVzdCcsXG4gICAgICByYXRlOiBwcm9maWxlLnJlcXVlc3RzUGVyU2Vjb25kLFxuICAgICAgdGltZVVuaXQ6ICcxcycsXG4gICAgICBkdXJhdGlvbjogYCR7cHJvZmlsZS53YXJtdXBTZWNvbmRzfXNgLFxuICAgICAgcHJlQWxsb2NhdGVkVlVzOiBNYXRoLm1pbigyMCwgcHJvZmlsZS5tYXhWdXMpLFxuICAgICAgbWF4VlVzOiBwcm9maWxlLm1heFZ1cyxcbiAgICAgIGdyYWNlZnVsU3RvcDogJzBzJyxcbiAgICB9LFxuICAgIHJlcXVlc3RfbWVhc3VyZW1lbnQ6IHtcbiAgICAgIGV4ZWN1dG9yOiAnY29uc3RhbnQtYXJyaXZhbC1yYXRlJyxcbiAgICAgIGV4ZWM6ICdzaW5nbGVSZXF1ZXN0JyxcbiAgICAgIHN0YXJ0VGltZTogYCR7cHJvZmlsZS53YXJtdXBTZWNvbmRzICsgMn1zYCxcbiAgICAgIHJhdGU6IHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQsXG4gICAgICB0aW1lVW5pdDogJzFzJyxcbiAgICAgIGR1cmF0aW9uOiBgJHtwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kc31zYCxcbiAgICAgIHByZUFsbG9jYXRlZFZVczogTWF0aC5taW4oMjAsIHByb2ZpbGUubWF4VnVzKSxcbiAgICAgIG1heFZVczogcHJvZmlsZS5tYXhWdXMsXG4gICAgICBncmFjZWZ1bFN0b3A6ICcwcycsXG4gICAgfSxcbiAgfSxcbiAgLy8gQ3JlYXRpbmcgc3VibWV0cmljcyB0aHJvdWdoIHRocmVzaG9sZHMgbWFrZXMgdGhlaXIgY291bnQgYXZhaWxhYmxlIGluIHRoZSBuYXRpdmUgc3VtbWFyeS5cbiAgdGhyZXNob2xkczoge1xuICAgICdodHRwX3JlcXN7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nOiBbXG4gICAgICBgY291bnQ+PSR7bWluaW11bUNvdW50fWAsXG4gICAgICBgY291bnQ8PSR7ZXhwZWN0ZWRDb3VudCArIDF9YCxcbiAgICBdLFxuICAgICdpdGVyYXRpb25ze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9JzogW2Bjb3VudD49JHttaW5pbXVtQ291bnR9YF0sXG4gICAgJ2Ryb3BwZWRfaXRlcmF0aW9uc3tzY2VuYXJpbzpyZXF1ZXN0X21lYXN1cmVtZW50fSc6IFsnY291bnQ9PTAnXSxcbiAgICAnY2hlY2tze3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9JzogWydyYXRlPT0xJ10sXG4gICAgJ2h0dHBfcmVxX2ZhaWxlZHtzY2VuYXJpbzpyZXF1ZXN0X21lYXN1cmVtZW50fSc6IFsncmF0ZTwwLjAxJ10sXG4gICAgJ2h0dHBfcmVxX2R1cmF0aW9ue3NjZW5hcmlvOnJlcXVlc3RfbWVhc3VyZW1lbnR9JzogWydwKDk1KTw4MCcsICdwKDk5KTwxNTAnXSxcbiAgfSxcbiAgbWF4UmVkaXJlY3RzOiAwLFxuICBzdW1tYXJ5VHJlbmRTdGF0cyxcbn07XG5cbi8qKiBGaXhlZCA4MC8yMCBhcnRpY2xlcy90YWdzIG1peC4gRGlyZWN0IEhUVFA6IGV4YWN0bHkgb25lIGF0dGVtcHQsIHplcm8gcmVkaXJlY3RzLCBubyBzbGVlcC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzaW5nbGVSZXF1ZXN0KCk6IHZvaWQge1xuICBjb25zdCBwYXRoID1cbiAgICBleGVjdXRpb24uc2NlbmFyaW8uaXRlcmF0aW9uSW5UZXN0ICUgNSA9PT0gNCA/ICcvdGFncycgOiAnL2FydGljbGVzP2xpbWl0PTEwJm9mZnNldD0wJztcbiAgY29uc3QgcmVzcG9uc2UgPSBodHRwLmdldChgJHtjb25maWcuYmFzZVVybC5yZXBsYWNlKC9cXC8kLywgJycpfSR7cGF0aH1gLCB7XG4gICAgcmVkaXJlY3RzOiAwLFxuICAgIHRpbWVvdXQ6ICcxcycsXG4gICAgaGVhZGVyczogeyAnWC1Mb2FkLVBoYXNlJzogZXhlY3V0aW9uLnNjZW5hcmlvLm5hbWUgfSxcbiAgICB0YWdzOiB7IC4uLmNvbmZpZy50YWdzLCBuYW1lOiBwYXRoLnN0YXJ0c1dpdGgoJy90YWdzJykgPyAnR0VUIC90YWdzJyA6ICdHRVQgL2FydGljbGVzJyB9LFxuICB9KTtcbiAgY2hlY2socmVzcG9uc2UsIHsgJ3NpbmdsZSByZXF1ZXN0IHN0YXR1cyBpcyAyMDAnOiAocmVzdWx0KSA9PiByZXN1bHQuc3RhdHVzID09PSAyMDAgfSk7XG59XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVTdW1tYXJ5ID0gY3JlYXRlU3VtbWFyeTtcbiIsICJpbXBvcnQgdHlwZSB7IEVudkNvbmZpZyB9IGZyb20gJy4uLy4uL3NyYy90eXBlcy9jb25maWcudHlwZXMnO1xuXG5leHBvcnQgY29uc3QgbG9jYWxDb25maWc6IEVudkNvbmZpZyA9IHtcbiAgZW52aXJvbm1lbnQ6ICdsb2NhbCcsXG4gIGJhc2VVcmw6ICdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpJyxcbiAgdGltZW91dHM6IHsgaHR0cDogMzBfMDAwIH0sXG4gIGFycml2YWw6IHsgaXRlcmF0aW9uc1BlclNlY29uZDogMjAsIG1heFZ1czogMTAwIH0sXG4gIHRhZ3M6IHsgZW52OiAnbG9jYWwnLCBhcHA6ICdjb25kdWl0JyB9LFxuICBhbGxvd3NXcml0ZXM6IHRydWUsXG59O1xuIiwgImltcG9ydCB0eXBlIHsgRW52Q29uZmlnIH0gZnJvbSAnLi4vLi4vc3JjL3R5cGVzL2NvbmZpZy50eXBlcyc7XG5cbi8qKlxuICogQ3JlYXRlcyBhIHJlYWQtb25seSBwcm9kdWN0aW9uIHRhcmdldCBjb25maWd1cmF0aW9uLlxuICogQHBhcmFtIGJhc2VVcmwgRXhwbGljaXQgYXV0aG9yaXplZCBwcm9kdWN0aW9uIFVSTC5cbiAqIEByZXR1cm5zIFByb2R1Y3Rpb24gZW52aXJvbm1lbnQgY29uZmlndXJhdGlvbi5cbiAqIEB0aHJvd3MgV2hlbiBubyBwcm9kdWN0aW9uIFVSTCBpcyBzdXBwbGllZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByb2R1Y3Rpb25Db25maWcoYmFzZVVybDogc3RyaW5nIHwgdW5kZWZpbmVkKTogRW52Q29uZmlnIHtcbiAgaWYgKCFiYXNlVXJsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdCQVNFX1VSTCBpcyByZXF1aXJlZCB3aGVuIFRBUkdFVF9FTlYgaXMgXCJwcm9kdWN0aW9uXCInKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgZW52aXJvbm1lbnQ6ICdwcm9kdWN0aW9uJyxcbiAgICBiYXNlVXJsLFxuICAgIHRpbWVvdXRzOiB7IGh0dHA6IDMwXzAwMCB9LFxuICAgIGFycml2YWw6IHsgaXRlcmF0aW9uc1BlclNlY29uZDogMTAsIG1heFZ1czogNTAgfSxcbiAgICB0YWdzOiB7IGVudjogJ3Byb2R1Y3Rpb24nLCBhcHA6ICdjb25kdWl0JyB9LFxuICAgIGFsbG93c1dyaXRlczogZmFsc2UsXG4gIH07XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBFbnZDb25maWcgfSBmcm9tICcuLi8uLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzJztcblxuZXhwb3J0IGNvbnN0IHN0YWdpbmdDb25maWc6IEVudkNvbmZpZyA9IHtcbiAgZW52aXJvbm1lbnQ6ICdzdGFnaW5nJyxcbiAgYmFzZVVybDogJ2h0dHBzOi8vYXBpLnJlYWx3b3JsZC5zaG93L2FwaScsXG4gIHRpbWVvdXRzOiB7IGh0dHA6IDMwXzAwMCB9LFxuICBhcnJpdmFsOiB7IGl0ZXJhdGlvbnNQZXJTZWNvbmQ6IDUwLCBtYXhWdXM6IDQwMCB9LFxuICB0YWdzOiB7IGVudjogJ3N0YWdpbmcnLCBhcHA6ICdjb25kdWl0JyB9LFxuICBhbGxvd3NXcml0ZXM6IGZhbHNlLFxufTtcbiIsICJpbXBvcnQgeyBsb2NhbENvbmZpZyB9IGZyb20gJy4vZW52aXJvbm1lbnRzL2xvY2FsJztcbmltcG9ydCB7IHByb2R1Y3Rpb25Db25maWcgfSBmcm9tICcuL2Vudmlyb25tZW50cy9wcm9kdWN0aW9uJztcbmltcG9ydCB7IHN0YWdpbmdDb25maWcgfSBmcm9tICcuL2Vudmlyb25tZW50cy9zdGFnaW5nJztcbmltcG9ydCB0eXBlIHsgRW52aXJvbm1lbnROYW1lLCBFbnZDb25maWcgfSBmcm9tICcuLi9zcmMvdHlwZXMvY29uZmlnLnR5cGVzJztcblxuY29uc3QgY29uZmlnczogUmVjb3JkPEV4Y2x1ZGU8RW52aXJvbm1lbnROYW1lLCAncHJvZHVjdGlvbic+LCBFbnZDb25maWc+ID0ge1xuICBsb2NhbDogbG9jYWxDb25maWcsXG4gIHN0YWdpbmc6IHN0YWdpbmdDb25maWcsXG59O1xuXG4vKipcbiAqIFJlc29sdmVzIGFuZCB2YWxpZGF0ZXMgdGhlIHNlbGVjdGVkIHRhcmdldCBlbnZpcm9ubWVudCBhdCBrNiBpbml0aWFsaXphdGlvbiB0aW1lLlxuICogQHBhcmFtIGVudiBUYXJnZXQgZW52aXJvbm1lbnQgbmFtZS5cbiAqIEByZXR1cm5zIFZhbGlkYXRlZCBlbnZpcm9ubWVudCBjb25maWd1cmF0aW9uLlxuICogQHRocm93cyBXaGVuIHRoZSBlbnZpcm9ubWVudCBuYW1lIGlzIHVua25vd24gb3IgcmVxdWlyZWQgcHJvZHVjdGlvbiBzZXR0aW5ncyBhcmUgYWJzZW50LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29uZmlnKGVudjogc3RyaW5nID0gX19FTlYuVEFSR0VUX0VOViA/PyAnbG9jYWwnKTogRW52Q29uZmlnIHtcbiAgaWYgKGVudiA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnByb2R1Y3Rpb25Db25maWcoX19FTlYuQkFTRV9VUkwpLFxuICAgICAgYWxsb3dzV3JpdGVzOiBfX0VOVi5BTExPV19OT05fTE9DQUxfTE9BRCA9PT0gJ3RydWUnLFxuICAgIH07XG4gIH1cblxuICBpZiAoZW52ID09PSAnbG9jYWwnIHx8IGVudiA9PT0gJ3N0YWdpbmcnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmNvbmZpZ3NbZW52XSxcbiAgICAgIGJhc2VVcmw6IF9fRU5WLkJBU0VfVVJMID8/IGNvbmZpZ3NbZW52XS5iYXNlVXJsLFxuICAgICAgYWxsb3dzV3JpdGVzOlxuICAgICAgICBlbnYgPT09ICdzdGFnaW5nJyA/IF9fRU5WLkFMTE9XX05PTl9MT0NBTF9MT0FEID09PSAndHJ1ZScgOiBjb25maWdzW2Vudl0uYWxsb3dzV3JpdGVzLFxuICAgIH07XG4gIH1cblxuICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gVEFSR0VUX0VOVjogXCIke2Vudn1cImApO1xufVxuIiwgImltcG9ydCB7IGdldENvbmZpZyB9IGZyb20gJy4nO1xuaW1wb3J0IHR5cGUge1xuICBFbnZpcm9ubWVudE5hbWUsXG4gIFN0YWdlZFdvcmtsb2FkLFxuICBXb3JrbG9hZFByb2ZpbGUsXG4gIFdvcmtsb2FkU2NlbmFyaW8sXG4gIFdvcmtsb2FkU3RhZ2UsXG59IGZyb20gJy4uL3NyYy90eXBlcy9jb25maWcudHlwZXMnO1xuXG5jb25zdCBmdWxsUHJvZmlsZXM6IFBhcnRpYWw8UmVjb3JkPEVudmlyb25tZW50TmFtZSwgUmVjb3JkPFN0YWdlZFdvcmtsb2FkLCBXb3JrbG9hZFN0YWdlW10+Pj4gPSB7XG4gIGxvY2FsOiB7XG4gICAgYXV0aGVudGljYXRlZExvYWQ6IFtcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogNSB9LFxuICAgICAgeyBkdXJhdGlvbjogJzVtJywgdGFyZ2V0OiA1IH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMW0nLCB0YXJnZXQ6IDAgfSxcbiAgICBdLFxuICAgIGF1dGhlbnRpY2F0ZWRTdHJlc3M6IFtcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogNSB9LFxuICAgICAgeyBkdXJhdGlvbjogJzVtJywgdGFyZ2V0OiAyMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiAwIH0sXG4gICAgXSxcbiAgICBzdHJlc3M6IFtcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogMjUgfSxcbiAgICAgIHsgZHVyYXRpb246ICczbScsIHRhcmdldDogNTAgfSxcbiAgICAgIHsgZHVyYXRpb246ICczbScsIHRhcmdldDogMTAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnM20nLCB0YXJnZXQ6IDE1MCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiAwIH0sXG4gICAgXSxcbiAgICBzcGlrZTogW1xuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiAxMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzMwcycsIHRhcmdldDogMjAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMW0nLCB0YXJnZXQ6IDIwMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzMwcycsIHRhcmdldDogMTAgfSxcbiAgICAgIHsgZHVyYXRpb246ICczbScsIHRhcmdldDogMTAgfSxcbiAgICAgIHsgZHVyYXRpb246ICcxbScsIHRhcmdldDogMCB9LFxuICAgIF0sXG4gICAgc29hazogW1xuICAgICAgeyBkdXJhdGlvbjogJzVtJywgdGFyZ2V0OiAyMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzJoJywgdGFyZ2V0OiAyMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzVtJywgdGFyZ2V0OiAwIH0sXG4gICAgXSxcbiAgICBicmVha3BvaW50OiBbXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDUwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMm0nLCB0YXJnZXQ6IDEwMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzJtJywgdGFyZ2V0OiAyMDAgfSxcbiAgICAgIHsgZHVyYXRpb246ICcybScsIHRhcmdldDogNDAwIH0sXG4gICAgICB7IGR1cmF0aW9uOiAnMW0nLCB0YXJnZXQ6IDQwMCB9LFxuICAgICAgeyBkdXJhdGlvbjogJzFtJywgdGFyZ2V0OiAwIH0sXG4gICAgXSxcbiAgfSxcbn07XG5cbmNvbnN0IHZhbGlkYXRpb25Qcm9maWxlczogUmVjb3JkPFN0YWdlZFdvcmtsb2FkLCBXb3JrbG9hZFN0YWdlW10+ID0ge1xuICBhdXRoZW50aWNhdGVkTG9hZDogW1xuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMSB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMCB9LFxuICBdLFxuICBhdXRoZW50aWNhdGVkU3RyZXNzOiBbXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAxIH0sXG4gICAgeyBkdXJhdGlvbjogJzVzJywgdGFyZ2V0OiAwIH0sXG4gIF0sXG4gIHN0cmVzczogW1xuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogNSB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMCB9LFxuICBdLFxuICBzcGlrZTogW1xuICAgIHsgZHVyYXRpb246ICczcycsIHRhcmdldDogMiB9LFxuICAgIHsgZHVyYXRpb246ICczcycsIHRhcmdldDogMjAgfSxcbiAgICB7IGR1cmF0aW9uOiAnNXMnLCB0YXJnZXQ6IDIgfSxcbiAgXSxcbiAgc29hazogW1xuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMiB9LFxuICAgIHsgZHVyYXRpb246ICcxMHMnLCB0YXJnZXQ6IDIgfSxcbiAgICB7IGR1cmF0aW9uOiAnNXMnLCB0YXJnZXQ6IDAgfSxcbiAgXSxcbiAgYnJlYWtwb2ludDogW1xuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogNSB9LFxuICAgIHsgZHVyYXRpb246ICc1cycsIHRhcmdldDogMjAgfSxcbiAgICB7IGR1cmF0aW9uOiAnNXMnLCB0YXJnZXQ6IDAgfSxcbiAgXSxcbn07XG5cbmZ1bmN0aW9uIHBvc2l0aXZlTnVtYmVyKG5hbWU6IHN0cmluZywgZmFsbGJhY2s6IG51bWJlcik6IG51bWJlciB7XG4gIGNvbnN0IHJhdyA9IF9fRU5WW25hbWVdO1xuICBpZiAocmF3ID09PSB1bmRlZmluZWQpIHJldHVybiBmYWxsYmFjaztcbiAgY29uc3QgdmFsdWUgPSBOdW1iZXIocmF3KTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUodmFsdWUpIHx8IHZhbHVlIDw9IDApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYCR7bmFtZX0gbXVzdCBiZSBhIHBvc2l0aXZlIG51bWJlcmApO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gcmVqZWN0TGVnYWN5UmF0ZSgpOiB2b2lkIHtcbiAgaWYgKF9fRU5WLlRBUkdFVF9SUFMgIT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdUQVJHRVRfUlBTIGlzIGFtYmlndW91cyBhbmQgaGFzIGJlZW4gcmVtb3ZlZC4gRm9yIHRoZSBleGlzdGluZyBqb3VybmV5IHVzZSAnICtcbiAgICAgICAgJ1RBUkdFVF9JVEVSQVRJT05TX1BFUl9TRUNPTkQgKG9sZCBhcnJpdmFsLWl0ZXJhdGlvbiBzZW1hbnRpY3MpOyBmb3Igb25lIHJlcXVlc3QgcGVyICcgK1xuICAgICAgICAnaXRlcmF0aW9uIHVzZSBSRVFVRVNUU19QRVJfU0VDT05EIHdpdGggdGhlIGRlZGljYXRlZCByZXF1ZXN0LXJhdGUgZW50cnkgcG9pbnQuJyxcbiAgICApO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBvc2l0aXZlSW50ZWdlcihuYW1lOiBzdHJpbmcsIGZhbGxiYWNrOiBudW1iZXIpOiBudW1iZXIge1xuICBjb25zdCB2YWx1ZSA9IHBvc2l0aXZlTnVtYmVyKG5hbWUsIGZhbGxiYWNrKTtcbiAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcih2YWx1ZSkpIHRocm93IG5ldyBFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGEgcG9zaXRpdmUgc2FmZSBpbnRlZ2VyYCk7XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0UmF0ZVByb2ZpbGUge1xuICByZXF1ZXN0c1BlclNlY29uZDogbnVtYmVyO1xuICBtYXhWdXM6IG51bWJlcjtcbiAgd2FybXVwU2Vjb25kczogbnVtYmVyO1xuICBtZWFzdXJlbWVudFNlY29uZHM6IG51bWJlcjtcbiAgbWluaW11bUFjaGlldmVkRnJhY3Rpb246IG51bWJlcjtcbn1cblxuLyoqIE9uZSBIVFRQIHJlcXVlc3QgcGVyIGFycml2YWw7IGR1cmF0aW9ucyBhbmQgYWNjZXB0YW5jZSBmaXhlZCBiZWZvcmUgZXhlY3V0aW9uLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJlcXVlc3RSYXRlUHJvZmlsZSgpOiBSZXF1ZXN0UmF0ZVByb2ZpbGUge1xuICByZWplY3RMZWdhY3lSYXRlKCk7XG4gIGNvbnN0IG1pbmltdW1BY2hpZXZlZEZyYWN0aW9uID0gcG9zaXRpdmVOdW1iZXIoJ01JTklNVU1fQUNISUVWRURfRlJBQ1RJT04nLCAwLjk4KTtcbiAgaWYgKG1pbmltdW1BY2hpZXZlZEZyYWN0aW9uID4gMSkge1xuICAgIHRocm93IG5ldyBFcnJvcignTUlOSU1VTV9BQ0hJRVZFRF9GUkFDVElPTiBtdXN0IGJlIGF0IG1vc3QgMScpO1xuICB9XG4gIGNvbnN0IHByb2ZpbGUgPSB7XG4gICAgcmVxdWVzdHNQZXJTZWNvbmQ6IHBvc2l0aXZlSW50ZWdlcignUkVRVUVTVFNfUEVSX1NFQ09ORCcsIDUwMCksXG4gICAgbWF4VnVzOiBwb3NpdGl2ZUludGVnZXIoJ01BWF9WVVMnLCAxMDApLFxuICAgIHdhcm11cFNlY29uZHM6IHBvc2l0aXZlSW50ZWdlcignV0FSTVVQX1NFQ09ORFMnLCAxMCksXG4gICAgbWVhc3VyZW1lbnRTZWNvbmRzOiBwb3NpdGl2ZUludGVnZXIoJ01FQVNVUkVNRU5UX1NFQ09ORFMnLCA2MCksXG4gICAgbWluaW11bUFjaGlldmVkRnJhY3Rpb24sXG4gIH07XG4gIGlmICghTnVtYmVyLmlzU2FmZUludGVnZXIocHJvZmlsZS5yZXF1ZXN0c1BlclNlY29uZCAqIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzKSkge1xuICAgIHRocm93IG5ldyBFcnJvcignQ29uZmlndXJlZCBtZWFzdXJlbWVudCByZXF1ZXN0IGNvdW50IGV4Y2VlZHMgc2FmZSBpbnRlZ2VyIHJhbmdlJyk7XG4gIH1cbiAgcmV0dXJuIHByb2ZpbGU7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgYm91bmRlZCB3b3JrbG9hZCBjb250cm9scyBmcm9tIGVudmlyb25tZW50IHZhcmlhYmxlcyBhbmQgdGFyZ2V0IGRlZmF1bHRzLlxuICogQHJldHVybnMgVmFsaWRhdGVkIHdvcmtsb2FkIHByb2ZpbGUuXG4gKiBAdGhyb3dzIFdoZW4gYSBudW1lcmljIHdvcmtsb2FkIG92ZXJyaWRlIGlzIG5vdCBwb3NpdGl2ZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFdvcmtsb2FkUHJvZmlsZSgpOiBXb3JrbG9hZFByb2ZpbGUge1xuICBjb25zdCBjb25maWcgPSBnZXRDb25maWcoKTtcbiAgcmVqZWN0TGVnYWN5UmF0ZSgpO1xuICByZXR1cm4ge1xuICAgIHZhbGlkYXRpb246IF9fRU5WLlRFU1RfUFJPRklMRSA9PT0gJ3ZhbGlkYXRpb24nLFxuICAgIHRhcmdldEl0ZXJhdGlvbnNQZXJTZWNvbmQ6IHBvc2l0aXZlSW50ZWdlcihcbiAgICAgICdUQVJHRVRfSVRFUkFUSU9OU19QRVJfU0VDT05EJyxcbiAgICAgIGNvbmZpZy5hcnJpdmFsLml0ZXJhdGlvbnNQZXJTZWNvbmQsXG4gICAgKSxcbiAgICBtYXhWdXM6IHBvc2l0aXZlSW50ZWdlcignTUFYX1ZVUycsIGNvbmZpZy5hcnJpdmFsLm1heFZ1cyksXG4gICAgdGhpbmtUaW1lU2Vjb25kczogcG9zaXRpdmVOdW1iZXIoJ1RISU5LX1RJTUVfU0VDT05EUycsIDEpLFxuICB9O1xufVxuXG4vKipcbiAqIFJlc29sdmVzIGEgdHlwZWQgc3RhZ2UgcHJvZmlsZSBmb3IgdGhlIHNlbGVjdGVkIGVudmlyb25tZW50IGFuZCB0ZXN0IHByb2ZpbGUuXG4gKiBBIHdvcmtsb2FkIGNhbiBiZSBvdmVycmlkZGVuIHdpdGggYSBKU09OIGFycmF5IGluIGl0cyBkZXJpdmVkIGVudmlyb25tZW50IHZhcmlhYmxlLCBzdWNoIGFzXG4gKiBgU1RSRVNTX1NUQUdFU2Agb3IgYEFVVEhFTlRJQ0FURURfTE9BRF9TVEFHRVNgLlxuICogQHBhcmFtIHdvcmtsb2FkIE5hbWVkIHN0YWdlZCB3b3JrbG9hZC5cbiAqIEByZXR1cm5zIFZhbGlkYXRlZCBkdXJhdGlvbi90YXJnZXQgc3RhZ2VzLlxuICogQHRocm93cyBXaGVuIGFuIG92ZXJyaWRlIGlzIGludmFsaWQgSlNPTiBvciBpcyBub3QgYSBub24tZW1wdHkgZHVyYXRpb24vdGFyZ2V0IGFycmF5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0V29ya2xvYWRTdGFnZXMod29ya2xvYWQ6IFN0YWdlZFdvcmtsb2FkKTogV29ya2xvYWRTdGFnZVtdIHtcbiAgY29uc3Qgb3ZlcnJpZGVOYW1lID1cbiAgICBgJHt3b3JrbG9hZC5yZXBsYWNlKC9bQS1aXS9nLCAobGV0dGVyKSA9PiBgXyR7bGV0dGVyfWApfV9TVEFHRVNgLnRvVXBwZXJDYXNlKCk7XG4gIGNvbnN0IHJhdyA9IF9fRU5WW292ZXJyaWRlTmFtZV07XG4gIGlmIChyYXcpIHtcbiAgICBsZXQgc3RhZ2VzOiB1bmtub3duO1xuICAgIHRyeSB7XG4gICAgICBzdGFnZXMgPSBKU09OLnBhcnNlKHJhdykgYXMgdW5rbm93bjtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgJHtvdmVycmlkZU5hbWV9IG11c3QgY29udGFpbiB2YWxpZCBKU09OYCk7XG4gICAgfVxuICAgIGlmIChcbiAgICAgICFBcnJheS5pc0FycmF5KHN0YWdlcykgfHxcbiAgICAgIHN0YWdlcy5sZW5ndGggPT09IDAgfHxcbiAgICAgIHN0YWdlcy5zb21lKFxuICAgICAgICAoc3RhZ2UpID0+XG4gICAgICAgICAgdHlwZW9mIHN0YWdlICE9PSAnb2JqZWN0JyB8fFxuICAgICAgICAgIHN0YWdlID09PSBudWxsIHx8XG4gICAgICAgICAgdHlwZW9mIChzdGFnZSBhcyBXb3JrbG9hZFN0YWdlKS5kdXJhdGlvbiAhPT0gJ3N0cmluZycgfHxcbiAgICAgICAgICAhTnVtYmVyLmlzSW50ZWdlcigoc3RhZ2UgYXMgV29ya2xvYWRTdGFnZSkudGFyZ2V0KSB8fFxuICAgICAgICAgIChzdGFnZSBhcyBXb3JrbG9hZFN0YWdlKS50YXJnZXQgPCAwLFxuICAgICAgKVxuICAgICkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGAke292ZXJyaWRlTmFtZX0gbXVzdCBiZSBhIG5vbi1lbXB0eSBKU09OIGFycmF5IG9mIGR1cmF0aW9uL3RhcmdldCBzdGFnZXNgKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0YWdlcyBhcyBXb3JrbG9hZFN0YWdlW107XG4gIH1cbiAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnKCk7XG4gIGlmIChfX0VOVi5URVNUX1BST0ZJTEUgPT09ICd2YWxpZGF0aW9uJykgcmV0dXJuIHZhbGlkYXRpb25Qcm9maWxlc1t3b3JrbG9hZF07XG4gIGNvbnN0IGVudmlyb25tZW50UHJvZmlsZSA9IGZ1bGxQcm9maWxlc1tjb25maWcuZW52aXJvbm1lbnRdO1xuICBpZiAoIWVudmlyb25tZW50UHJvZmlsZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBGdWxsICR7d29ya2xvYWR9IHByb2ZpbGUgaXMgbm90IGRlZmluZWQgZm9yICR7Y29uZmlnLmVudmlyb25tZW50fTsgcHJvdmlkZSAke292ZXJyaWRlTmFtZX1gLFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGVudmlyb25tZW50UHJvZmlsZVt3b3JrbG9hZF07XG59XG5cbi8qKlxuICogQnVpbGRzIGEgcmFtcGluZy1WVSBzY2VuYXJpby5cbiAqIEBwYXJhbSBzdGFnZXMgVlUgdGFyZ2V0cyBhbmQgZHVyYXRpb25zLlxuICogQHBhcmFtIGdyYWNlZnVsU3RvcCBHcmFjZSBwZXJpb2QgZm9yIGludGVycnVwdGVkIGl0ZXJhdGlvbnMuXG4gKiBAcmV0dXJucyBBIGs2IHJhbXBpbmctdnVzIHNjZW5hcmlvLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmFtcGluZ1Z1cyhcbiAgc3RhZ2VzOiBBcnJheTx7IGR1cmF0aW9uOiBzdHJpbmc7IHRhcmdldDogbnVtYmVyIH0+LFxuICBncmFjZWZ1bFN0b3AgPSAnMzBzJyxcbik6IFdvcmtsb2FkU2NlbmFyaW8ge1xuICByZXR1cm4ge1xuICAgIGV4ZWN1dG9yOiAncmFtcGluZy12dXMnLFxuICAgIHN0YXJ0VlVzOiAwLFxuICAgIHN0YWdlcyxcbiAgICBncmFjZWZ1bFJhbXBEb3duOiBncmFjZWZ1bFN0b3AsXG4gICAgZ3JhY2VmdWxTdG9wLFxuICB9O1xufVxuXG4vKipcbiAqIEJ1aWxkcyBhIGZpeGVkIHBlci1WVSBpdGVyYXRpb24gc2NlbmFyaW8uXG4gKiBAcGFyYW0gdnVzIE51bWJlciBvZiB2aXJ0dWFsIHVzZXJzLlxuICogQHBhcmFtIGl0ZXJhdGlvbnMgSXRlcmF0aW9ucyBwZXIgdmlydHVhbCB1c2VyLlxuICogQHBhcmFtIG1heER1cmF0aW9uIE1heGltdW0gc2NlbmFyaW8gZHVyYXRpb24uXG4gKiBAcGFyYW0gZ3JhY2VmdWxTdG9wIEdyYWNlIHBlcmlvZCBmb3IgaW50ZXJydXB0ZWQgaXRlcmF0aW9ucy5cbiAqIEByZXR1cm5zIEEgazYgcGVyLXZ1LWl0ZXJhdGlvbnMgc2NlbmFyaW8uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwZXJWdUl0ZXJhdGlvbnMoXG4gIHZ1czogbnVtYmVyLFxuICBpdGVyYXRpb25zOiBudW1iZXIsXG4gIG1heER1cmF0aW9uOiBzdHJpbmcsXG4gIGdyYWNlZnVsU3RvcCA9ICcxMHMnLFxuKTogV29ya2xvYWRTY2VuYXJpbyB7XG4gIHJldHVybiB7IGV4ZWN1dG9yOiAncGVyLXZ1LWl0ZXJhdGlvbnMnLCB2dXMsIGl0ZXJhdGlvbnMsIG1heER1cmF0aW9uLCBncmFjZWZ1bFN0b3AgfTtcbn1cblxuLyoqXG4gKiBCdWlsZHMgYSBib3VuZGVkIGNvbnN0YW50LWFycml2YWwtcmF0ZSBzY2VuYXJpby5cbiAqIEBwYXJhbSBwcm9maWxlIFJlc29sdmVkIHdvcmtsb2FkIGxpbWl0cy5cbiAqIEBwYXJhbSBkdXJhdGlvbiBTY2VuYXJpbyBkdXJhdGlvbi5cbiAqIEByZXR1cm5zIEEgazYgY29uc3RhbnQtYXJyaXZhbC1yYXRlIHNjZW5hcmlvLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY29uc3RhbnRBcnJpdmFsUmF0ZShwcm9maWxlOiBXb3JrbG9hZFByb2ZpbGUsIGR1cmF0aW9uOiBzdHJpbmcpOiBXb3JrbG9hZFNjZW5hcmlvIHtcbiAgcmV0dXJuIHtcbiAgICBleGVjdXRvcjogJ2NvbnN0YW50LWFycml2YWwtcmF0ZScsXG4gICAgcmF0ZTogcHJvZmlsZS50YXJnZXRJdGVyYXRpb25zUGVyU2Vjb25kLFxuICAgIHRpbWVVbml0OiAnMXMnLFxuICAgIGR1cmF0aW9uLFxuICAgIHByZUFsbG9jYXRlZFZVczogTWF0aC5taW4oMjAsIHByb2ZpbGUubWF4VnVzKSxcbiAgICBtYXhWVXM6IHByb2ZpbGUubWF4VnVzLFxuICAgIGdyYWNlZnVsU3RvcDogJzMwcycsXG4gIH07XG59XG4iLCAiaW1wb3J0IHsgU2hhcmVkQXJyYXkgfSBmcm9tICdrNi9kYXRhJztcblxuY29uc3QgdG9rZW5zID0gbmV3IFNoYXJlZEFycmF5PHN0cmluZz4oJ3VzZXIgdG9rZW5zJywgKCkgPT4ge1xuICBjb25zdCByYXcgPSBfX0VOVi5LNl9VU0VSX1RPS0VOUztcbiAgaWYgKCFyYXcpIHJldHVybiBbXTtcbiAgY29uc3QgcGFyc2VkOiB1bmtub3duID0gSlNPTi5wYXJzZShyYXcpO1xuICBpZiAoIUFycmF5LmlzQXJyYXkocGFyc2VkKSB8fCAhcGFyc2VkLmV2ZXJ5KCh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0s2X1VTRVJfVE9LRU5TIG11c3QgYmUgYSBKU09OIGFycmF5IG9mIHN0cmluZ3MnKTtcbiAgfVxuICByZXR1cm4gcGFyc2VkO1xufSk7XG5cbi8qKlxuICogU2VsZWN0cyBhIHNoYXJlZCBhdXRoZW50aWNhdGlvbiB0b2tlbiBkZXRlcm1pbmlzdGljYWxseSBmb3IgYSB2aXJ0dWFsIHVzZXIuXG4gKiBAcGFyYW0gdnUgazYgdmlydHVhbC11c2VyIG51bWJlci5cbiAqIEByZXR1cm5zIFRoZSB0b2tlbiBhc3NpZ25lZCB0byB0aGUgdmlydHVhbCB1c2VyLlxuICogQHRocm93cyBXaGVuIG5vIHZhbGlkIHRva2VuIGFycmF5IHdhcyBwcm92aWRlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRva2VuRm9yVnUodnUgPSBfX1ZVKTogc3RyaW5nIHtcbiAgaWYgKHRva2Vucy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcignSzZfVVNFUl9UT0tFTlMgaXMgcmVxdWlyZWQgZm9yIGF1dGhlbnRpY2F0ZWQgdGVzdHMnKTtcbiAgcmV0dXJuIHRva2Vuc1sodnUgLSAxKSAlIHRva2Vucy5sZW5ndGhdITtcbn1cbiIsICJpbXBvcnQgeyBjaGVjayB9IGZyb20gJ2s2JztcbmltcG9ydCB0eXBlIHsgSHR0cFJlc3BvbnNlIH0gZnJvbSAnLi4vdHlwZXMnO1xuXG4vKipcbiAqIFJlY29yZHMgYSBuYW1lZCBrNiBzdGF0dXMgY2hlY2suXG4gKiBAcGFyYW0gcmVzcG9uc2UgVHlwZWQgSFRUUCByZXNwb25zZS5cbiAqIEBwYXJhbSBleHBlY3RlZCBFeHBlY3RlZCBIVFRQIHN0YXR1cy5cbiAqIEBwYXJhbSBsYWJlbCBIdW1hbi1yZWFkYWJsZSBvcGVyYXRpb24gbGFiZWwuXG4gKiBAcmV0dXJucyBXaGV0aGVyIHRoZSByZXNwb25zZSBtYXRjaGVkIHRoZSBleHBlY3RlZCBzdGF0dXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1N0YXR1czxUPihcbiAgcmVzcG9uc2U6IEh0dHBSZXNwb25zZTxUPixcbiAgZXhwZWN0ZWQ6IG51bWJlcixcbiAgbGFiZWw6IHN0cmluZyxcbik6IGJvb2xlYW4ge1xuICByZXR1cm4gY2hlY2socmVzcG9uc2UucmF3LCB7XG4gICAgW2Ake2xhYmVsfTogc3RhdHVzICR7ZXhwZWN0ZWR9YF06ICgpID0+IHJlc3BvbnNlLnN0YXR1cyA9PT0gZXhwZWN0ZWQsXG4gIH0pO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIHBhcnNlZCByZXNwb25zZSBib2R5LlxuICogQHBhcmFtIHJlc3BvbnNlIFR5cGVkIEhUVFAgcmVzcG9uc2UuXG4gKiBAcGFyYW0gbGFiZWwgSHVtYW4tcmVhZGFibGUgb3BlcmF0aW9uIGxhYmVsLlxuICogQHJldHVybnMgVGhlIHBhcnNlZCByZXNwb25zZSBib2R5LlxuICogQHRocm93cyBXaGVuIHRoZSByZXNwb25zZSBoYXMgbm8gSlNPTiBib2R5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVxdWlyZURhdGE8VD4ocmVzcG9uc2U6IEh0dHBSZXNwb25zZTxUPiwgbGFiZWw6IHN0cmluZyk6IFQge1xuICBpZiAocmVzcG9uc2UuZGF0YSA9PT0gbnVsbCkgdGhyb3cgbmV3IEVycm9yKGAke2xhYmVsfSByZXR1cm5lZCBubyBKU09OIGJvZHlgKTtcbiAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XG59XG4iLCAiaW1wb3J0IHsgc2xlZXAgfSBmcm9tICdrNic7XG5pbXBvcnQgaHR0cCwgeyB0eXBlIFBhcmFtcywgdHlwZSBSZXF1ZXN0Qm9keSwgdHlwZSBSZXNwb25zZSB9IGZyb20gJ2s2L2h0dHAnO1xuaW1wb3J0IHsgZ2V0Q29uZmlnIH0gZnJvbSAnLi4vLi4vY29uZmlnJztcbmltcG9ydCB0eXBlIHsgSHR0cE1ldGhvZCwgSHR0cFJlcXVlc3RPcHRpb25zLCBIdHRwUmVzcG9uc2UgfSBmcm9tICcuLi90eXBlcy9hcGkudHlwZXMnO1xuaW1wb3J0IHR5cGUgeyBCdXNpbmVzc01ldHJpY0dyb3VwIH0gZnJvbSAnLi4vdHlwZXMvYXBpLnR5cGVzJztcbmltcG9ydCB0eXBlIHsgRW52Q29uZmlnIH0gZnJvbSAnLi4vdHlwZXMvY29uZmlnLnR5cGVzJztcbmltcG9ydCB7IGxvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJztcbmltcG9ydCB7XG4gIGFydGljbGVSZWFkRHVyYXRpb24sXG4gIGFydGljbGVSZWFkU3VjY2Vzc1JhdGUsXG4gIGFydGljbGVXcml0ZUR1cmF0aW9uLFxuICBhcnRpY2xlV3JpdGVTdWNjZXNzUmF0ZSxcbiAgYXV0aER1cmF0aW9uLFxuICBhdXRoU3VjY2Vzc1JhdGUsXG4gIGNvbW1lbnREdXJhdGlvbixcbiAgY29tbWVudFN1Y2Nlc3NSYXRlLFxuICBwcm9maWxlRHVyYXRpb24sXG4gIHByb2ZpbGVTdWNjZXNzUmF0ZSxcbiAgdGFnRHVyYXRpb24sXG4gIHRhZ1N1Y2Nlc3NSYXRlLFxuICB0b3RhbEJ1c2luZXNzRXJyb3JzLFxufSBmcm9tICcuL21ldHJpY3MnO1xuXG5jb25zdCBzYWZlUmV0cnlNZXRob2RzID0gbmV3IFNldDxIdHRwTWV0aG9kPihbJ0dFVCcsICdIRUFEJywgJ1BVVCcsICdERUxFVEUnXSk7XG5jb25zdCB3cml0ZU1ldGhvZHMgPSBuZXcgU2V0PEh0dHBNZXRob2Q+KFsnUE9TVCcsICdQVVQnLCAnUEFUQ0gnLCAnREVMRVRFJ10pO1xuXG5mdW5jdGlvbiBqb2luVXJsKGJhc2VVcmw6IHN0cmluZywgcGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2Jhc2VVcmwucmVwbGFjZSgvXFwvKyQvLCAnJyl9LyR7cGF0aC5yZXBsYWNlKC9eXFwvKy8sICcnKX1gO1xufVxuXG5mdW5jdGlvbiBwYXJzZUpzb248VD4ocmVzcG9uc2U6IFJlc3BvbnNlKTogVCB8IG51bGwge1xuICBpZiAoIXJlc3BvbnNlLmJvZHkpIHJldHVybiBudWxsO1xuICB0cnkge1xuICAgIHJldHVybiByZXNwb25zZS5qc29uKCkgYXMgVDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuY29uc3QgbWV0cmljUmVjb3JkZXJzOiBSZWNvcmQ8XG4gIEJ1c2luZXNzTWV0cmljR3JvdXAsXG4gIHsgZHVyYXRpb246IHR5cGVvZiBhdXRoRHVyYXRpb247IHN1Y2Nlc3M6IHR5cGVvZiBhdXRoU3VjY2Vzc1JhdGUgfVxuPiA9IHtcbiAgYXV0aGVudGljYXRpb246IHsgZHVyYXRpb246IGF1dGhEdXJhdGlvbiwgc3VjY2VzczogYXV0aFN1Y2Nlc3NSYXRlIH0sXG4gICdhcnRpY2xlLXJlYWQnOiB7IGR1cmF0aW9uOiBhcnRpY2xlUmVhZER1cmF0aW9uLCBzdWNjZXNzOiBhcnRpY2xlUmVhZFN1Y2Nlc3NSYXRlIH0sXG4gICdhcnRpY2xlLXdyaXRlJzogeyBkdXJhdGlvbjogYXJ0aWNsZVdyaXRlRHVyYXRpb24sIHN1Y2Nlc3M6IGFydGljbGVXcml0ZVN1Y2Nlc3NSYXRlIH0sXG4gIGNvbW1lbnQ6IHsgZHVyYXRpb246IGNvbW1lbnREdXJhdGlvbiwgc3VjY2VzczogY29tbWVudFN1Y2Nlc3NSYXRlIH0sXG4gIHByb2ZpbGU6IHsgZHVyYXRpb246IHByb2ZpbGVEdXJhdGlvbiwgc3VjY2VzczogcHJvZmlsZVN1Y2Nlc3NSYXRlIH0sXG4gIHRhZzogeyBkdXJhdGlvbjogdGFnRHVyYXRpb24sIHN1Y2Nlc3M6IHRhZ1N1Y2Nlc3NSYXRlIH0sXG59O1xuXG5mdW5jdGlvbiByZWNvcmRCdXNpbmVzc01ldHJpY3MoXG4gIGVuZHBvaW50TmFtZTogc3RyaW5nLFxuICBtZXRyaWNHcm91cDogQnVzaW5lc3NNZXRyaWNHcm91cCB8IHVuZGVmaW5lZCxcbiAgcmVzcG9uc2U6IFJlc3BvbnNlLFxuKTogdm9pZCB7XG4gIGNvbnN0IGR1cmF0aW9uID0gcmVzcG9uc2UudGltaW5ncy5kdXJhdGlvbjtcbiAgaWYgKG1ldHJpY0dyb3VwKSB7XG4gICAgY29uc3QgcmVjb3JkZXIgPSBtZXRyaWNSZWNvcmRlcnNbbWV0cmljR3JvdXBdO1xuICAgIHJlY29yZGVyLmR1cmF0aW9uLmFkZChkdXJhdGlvbiwgeyBlbmRwb2ludDogZW5kcG9pbnROYW1lIH0pO1xuICAgIHJlY29yZGVyLnN1Y2Nlc3MuYWRkKHJlc3BvbnNlLnN0YXR1cyA+PSAyMDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgNDAwLCB7XG4gICAgICBlbmRwb2ludDogZW5kcG9pbnROYW1lLFxuICAgIH0pO1xuICB9XG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB7XG4gICAgdG90YWxCdXNpbmVzc0Vycm9ycy5hZGQoMSwgeyBlbmRwb2ludDogZW5kcG9pbnROYW1lLCBzdGF0dXM6IFN0cmluZyhyZXNwb25zZS5zdGF0dXMpIH0pO1xuICB9XG59XG5cbi8qKiBTaGFyZWQgdGFnZ2VkIEhUVFAgdHJhbnNwb3J0IHdpdGggdGFyZ2V0IHNhZmV0eSwgcmV0cmllcywgYW5kIGJ1c2luZXNzIG1ldHJpYyByZWNvcmRpbmcuICovXG5leHBvcnQgY2xhc3MgSHR0cENsaWVudCB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgY29uZmlnOiBFbnZDb25maWcgPSBnZXRDb25maWcoKSkge31cblxuICByZXF1ZXN0PFQ+KFxuICAgIG1ldGhvZDogSHR0cE1ldGhvZCxcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgZW5kcG9pbnROYW1lOiBzdHJpbmcsXG4gICAgYm9keT86IHVua25vd24sXG4gICAgb3B0aW9uczogSHR0cFJlcXVlc3RPcHRpb25zID0ge30sXG4gICk6IEh0dHBSZXNwb25zZTxUPiB7XG4gICAgaWYgKCF0aGlzLmNvbmZpZy5hbGxvd3NXcml0ZXMgJiYgd3JpdGVNZXRob2RzLmhhcyhtZXRob2QpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7bWV0aG9kfSByZXF1ZXN0cyBhcmUgYmxvY2tlZCBpbiB0aGUgcHJvZHVjdGlvbiBlbnZpcm9ubWVudGApO1xuICAgIH1cblxuICAgIGNvbnN0IHVybCA9IGpvaW5VcmwodGhpcy5jb25maWcuYmFzZVVybCwgcGF0aCk7XG4gICAgY29uc3QgcGFyYW1zOiBQYXJhbXMgPSB7XG4gICAgICAuLi5vcHRpb25zLnBhcmFtcyxcbiAgICAgIHRpbWVvdXQ6IG9wdGlvbnMucGFyYW1zPy50aW1lb3V0ID8/IHRoaXMuY29uZmlnLnRpbWVvdXRzLmh0dHAsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihib2R5ID09PSB1bmRlZmluZWQgPyB7fSA6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9KSxcbiAgICAgICAgLi4ub3B0aW9ucy5wYXJhbXM/LmhlYWRlcnMsXG4gICAgICB9LFxuICAgICAgdGFnczoge1xuICAgICAgICAuLi50aGlzLmNvbmZpZy50YWdzLFxuICAgICAgICAuLi5vcHRpb25zLnBhcmFtcz8udGFncyxcbiAgICAgICAgbmFtZTogZW5kcG9pbnROYW1lLFxuICAgICAgfSxcbiAgICB9O1xuICAgIGNvbnN0IHJlcXVlc3RCb2R5OiBSZXF1ZXN0Qm9keSB8IG51bGwgPVxuICAgICAgYm9keSA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IHR5cGVvZiBib2R5ID09PSAnc3RyaW5nJyA/IGJvZHkgOiBKU09OLnN0cmluZ2lmeShib2R5KTtcbiAgICBjb25zdCByZXRyeSA9IHNhZmVSZXRyeU1ldGhvZHMuaGFzKG1ldGhvZCkgfHwgb3B0aW9ucy5yZXRyeVVuc2FmZSA9PT0gdHJ1ZTtcbiAgICBsZXQgYXR0ZW1wdHMgPSAwO1xuICAgIGxldCByZXNwb25zZTogUmVzcG9uc2U7XG5cbiAgICBkbyB7XG4gICAgICBhdHRlbXB0cyArPSAxO1xuICAgICAgbG9nZ2VyLmRlYnVnKCdIVFRQIHJlcXVlc3QnLCB7IG1ldGhvZCwgdXJsLCB0YWdzOiBwYXJhbXMudGFncywgYXR0ZW1wdDogYXR0ZW1wdHMgfSk7XG4gICAgICByZXNwb25zZSA9IGh0dHAucmVxdWVzdChtZXRob2QsIHVybCwgcmVxdWVzdEJvZHksIHBhcmFtcyk7XG4gICAgICByZWNvcmRCdXNpbmVzc01ldHJpY3MoZW5kcG9pbnROYW1lLCBvcHRpb25zLm1ldHJpY0dyb3VwLCByZXNwb25zZSk7XG4gICAgICBsb2dnZXIuZGVidWcoJ0hUVFAgcmVzcG9uc2UnLCB7IG1ldGhvZCwgdXJsLCBzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cywgYXR0ZW1wdDogYXR0ZW1wdHMgfSk7XG5cbiAgICAgIGlmICghKHJldHJ5ICYmIGF0dGVtcHRzID09PSAxICYmIHJlc3BvbnNlLnN0YXR1cyA+PSA1MDApKSBicmVhaztcbiAgICAgIHNsZWVwKDAuMSk7XG4gICAgfSB3aGlsZSAoYXR0ZW1wdHMgPCAyKTtcblxuICAgIHJldHVybiB7XG4gICAgICBkYXRhOiBwYXJzZUpzb248VD4ocmVzcG9uc2UpLFxuICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICBoZWFkZXJzOiByZXNwb25zZS5oZWFkZXJzLFxuICAgICAgcmF3OiByZXNwb25zZSxcbiAgICAgIGF0dGVtcHRzLFxuICAgIH07XG4gIH1cblxuICBnZXQ8VD4ocGF0aDogc3RyaW5nLCBuYW1lOiBzdHJpbmcsIG9wdGlvbnM/OiBIdHRwUmVxdWVzdE9wdGlvbnMpOiBIdHRwUmVzcG9uc2U8VD4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8VD4oJ0dFVCcsIHBhdGgsIG5hbWUsIHVuZGVmaW5lZCwgb3B0aW9ucyk7XG4gIH1cblxuICBwb3N0PFQ+KFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBuYW1lOiBzdHJpbmcsXG4gICAgYm9keTogdW5rbm93bixcbiAgICBvcHRpb25zPzogSHR0cFJlcXVlc3RPcHRpb25zLFxuICApOiBIdHRwUmVzcG9uc2U8VD4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8VD4oJ1BPU1QnLCBwYXRoLCBuYW1lLCBib2R5LCBvcHRpb25zKTtcbiAgfVxuXG4gIHB1dDxUPihwYXRoOiBzdHJpbmcsIG5hbWU6IHN0cmluZywgYm9keTogdW5rbm93biwgb3B0aW9ucz86IEh0dHBSZXF1ZXN0T3B0aW9ucyk6IEh0dHBSZXNwb25zZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxUPignUFVUJywgcGF0aCwgbmFtZSwgYm9keSwgb3B0aW9ucyk7XG4gIH1cblxuICBwYXRjaDxUPihcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgbmFtZTogc3RyaW5nLFxuICAgIGJvZHk6IHVua25vd24sXG4gICAgb3B0aW9ucz86IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgKTogSHR0cFJlc3BvbnNlPFQ+IHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFQ+KCdQQVRDSCcsIHBhdGgsIG5hbWUsIGJvZHksIG9wdGlvbnMpO1xuICB9XG5cbiAgZGVsZXRlPFQ+KHBhdGg6IHN0cmluZywgbmFtZTogc3RyaW5nLCBvcHRpb25zPzogSHR0cFJlcXVlc3RPcHRpb25zKTogSHR0cFJlc3BvbnNlPFQ+IHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFQ+KCdERUxFVEUnLCBwYXRoLCBuYW1lLCB1bmRlZmluZWQsIG9wdGlvbnMpO1xuICB9XG59XG4iLCAiaW1wb3J0IHsgQ291bnRlciwgUmF0ZSwgVHJlbmQgfSBmcm9tICdrNi9tZXRyaWNzJztcblxuLyoqIEF1dGhlbnRpY2F0aW9uIGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IGF1dGhEdXJhdGlvbiA9IG5ldyBUcmVuZCgnY3VzdG9tX2F1dGhfZHVyYXRpb25fbXMnLCB0cnVlKTtcbi8qKiBSZWFkLW9ubHkgYXJ0aWNsZSByZXF1ZXN0IGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IGFydGljbGVSZWFkRHVyYXRpb24gPSBuZXcgVHJlbmQoJ2N1c3RvbV9hcnRpY2xlX3JlYWRfZHVyYXRpb25fbXMnLCB0cnVlKTtcbi8qKiBBcnRpY2xlIG11dGF0aW9uIGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IGFydGljbGVXcml0ZUR1cmF0aW9uID0gbmV3IFRyZW5kKCdjdXN0b21fYXJ0aWNsZV93cml0ZV9kdXJhdGlvbl9tcycsIHRydWUpO1xuLyoqIENvbW1lbnQgb3BlcmF0aW9uIGxhdGVuY3kgaW4gbWlsbGlzZWNvbmRzLiAqL1xuZXhwb3J0IGNvbnN0IGNvbW1lbnREdXJhdGlvbiA9IG5ldyBUcmVuZCgnY3VzdG9tX2NvbW1lbnRfZHVyYXRpb25fbXMnLCB0cnVlKTtcbi8qKiBQcm9maWxlIG9wZXJhdGlvbiBsYXRlbmN5IGluIG1pbGxpc2Vjb25kcy4gKi9cbmV4cG9ydCBjb25zdCBwcm9maWxlRHVyYXRpb24gPSBuZXcgVHJlbmQoJ2N1c3RvbV9wcm9maWxlX2R1cmF0aW9uX21zJywgdHJ1ZSk7XG4vKiogVGFnIG9wZXJhdGlvbiBsYXRlbmN5IGluIG1pbGxpc2Vjb25kcy4gKi9cbmV4cG9ydCBjb25zdCB0YWdEdXJhdGlvbiA9IG5ldyBUcmVuZCgnY3VzdG9tX3RhZ19kdXJhdGlvbl9tcycsIHRydWUpO1xuLyoqIENvdW50IG9mIEhUVFAgcmVzcG9uc2VzIHJlcHJlc2VudGluZyBidXNpbmVzcy1vcGVyYXRpb24gZmFpbHVyZXMuICovXG5leHBvcnQgY29uc3QgdG90YWxCdXNpbmVzc0Vycm9ycyA9IG5ldyBDb3VudGVyKCdjdXN0b21fYnVzaW5lc3NfZXJyb3JzX3RvdGFsJyk7XG4vKiogUmF0aW8gb2Ygc3VjY2Vzc2Z1bCBhdXRoZW50aWNhdGlvbiBvcGVyYXRpb25zLiAqL1xuZXhwb3J0IGNvbnN0IGF1dGhTdWNjZXNzUmF0ZSA9IG5ldyBSYXRlKCdjdXN0b21fYXV0aF9zdWNjZXNzX3JhdGUnKTtcbi8qKiBSYXRpbyBvZiBzdWNjZXNzZnVsIGFydGljbGUgcmVhZCBvcGVyYXRpb25zLiAqL1xuZXhwb3J0IGNvbnN0IGFydGljbGVSZWFkU3VjY2Vzc1JhdGUgPSBuZXcgUmF0ZSgnY3VzdG9tX2FydGljbGVfcmVhZF9zdWNjZXNzX3JhdGUnKTtcbi8qKiBSYXRpbyBvZiBzdWNjZXNzZnVsIGFydGljbGUgd3JpdGUgb3BlcmF0aW9ucy4gKi9cbmV4cG9ydCBjb25zdCBhcnRpY2xlV3JpdGVTdWNjZXNzUmF0ZSA9IG5ldyBSYXRlKCdjdXN0b21fYXJ0aWNsZV93cml0ZV9zdWNjZXNzX3JhdGUnKTtcbi8qKiBSYXRpbyBvZiBzdWNjZXNzZnVsIGNvbW1lbnQgb3BlcmF0aW9ucy4gKi9cbmV4cG9ydCBjb25zdCBjb21tZW50U3VjY2Vzc1JhdGUgPSBuZXcgUmF0ZSgnY3VzdG9tX2NvbW1lbnRfc3VjY2Vzc19yYXRlJyk7XG4vKiogUmF0aW8gb2Ygc3VjY2Vzc2Z1bCBwcm9maWxlIG9wZXJhdGlvbnMuICovXG5leHBvcnQgY29uc3QgcHJvZmlsZVN1Y2Nlc3NSYXRlID0gbmV3IFJhdGUoJ2N1c3RvbV9wcm9maWxlX3N1Y2Nlc3NfcmF0ZScpO1xuLyoqIFJhdGlvIG9mIHN1Y2Nlc3NmdWwgdGFnIG9wZXJhdGlvbnMuICovXG5leHBvcnQgY29uc3QgdGFnU3VjY2Vzc1JhdGUgPSBuZXcgUmF0ZSgnY3VzdG9tX3RhZ19zdWNjZXNzX3JhdGUnKTtcbiIsICJpbXBvcnQgeyBTaGFyZWRBcnJheSB9IGZyb20gJ2s2L2RhdGEnO1xuaW1wb3J0IHNvdXJjZSBmcm9tICcuL2Jyb3dzZS1iZWhhdmlvcnMuanNvbic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnJvd3NlQmVoYXZpb3Ige1xuICBuYW1lOiBzdHJpbmc7XG4gIHdlaWdodDogbnVtYmVyO1xuICBhcnRpY2xlTGltaXQ6IG51bWJlcjtcbiAgaW5zcGVjdEFydGljbGU6IGJvb2xlYW47XG59XG5cbmNvbnN0IGJlaGF2aW9ycyA9IG5ldyBTaGFyZWRBcnJheTxCcm93c2VCZWhhdmlvcj4oJ2Jyb3dzZSBiZWhhdmlvcnMnLCAoKSA9PlxuICBzb3VyY2UubWFwKChiZWhhdmlvcikgPT4gKHsgLi4uYmVoYXZpb3IgfSkpLFxuKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGJyb3dzZUJlaGF2aW9yKGl0ZXJhdGlvbiA9IF9fSVRFUik6IEJyb3dzZUJlaGF2aW9yIHtcbiAgY29uc3QgdG90YWxXZWlnaHQgPSBiZWhhdmlvcnMucmVkdWNlKChzdW0sIGJlaGF2aW9yKSA9PiBzdW0gKyBiZWhhdmlvci53ZWlnaHQsIDApO1xuICBsZXQgc2VsZWN0aW9uID0gaXRlcmF0aW9uICUgdG90YWxXZWlnaHQ7XG4gIGZvciAoY29uc3QgYmVoYXZpb3Igb2YgYmVoYXZpb3JzKSB7XG4gICAgaWYgKHNlbGVjdGlvbiA8IGJlaGF2aW9yLndlaWdodCkgcmV0dXJuIGJlaGF2aW9yO1xuICAgIHNlbGVjdGlvbiAtPSBiZWhhdmlvci53ZWlnaHQ7XG4gIH1cbiAgY29uc3QgZmFsbGJhY2sgPSBiZWhhdmlvcnNbMF07XG4gIGlmICghZmFsbGJhY2spIHRocm93IG5ldyBFcnJvcignQXQgbGVhc3Qgb25lIGJyb3dzZSBiZWhhdmlvciBpcyByZXF1aXJlZCcpO1xuICByZXR1cm4gZmFsbGJhY2s7XG59XG4iLCAiW1xuICB7IFwibmFtZVwiOiBcInF1aWNrLXJlYWRlclwiLCBcIndlaWdodFwiOiA1MCwgXCJhcnRpY2xlTGltaXRcIjogNSwgXCJpbnNwZWN0QXJ0aWNsZVwiOiBmYWxzZSB9LFxuICB7IFwibmFtZVwiOiBcImFydGljbGUtcmVhZGVyXCIsIFwid2VpZ2h0XCI6IDM1LCBcImFydGljbGVMaW1pdFwiOiAxMCwgXCJpbnNwZWN0QXJ0aWNsZVwiOiB0cnVlIH0sXG4gIHsgXCJuYW1lXCI6IFwiZGVlcC1yZWFkZXJcIiwgXCJ3ZWlnaHRcIjogMTUsIFwiYXJ0aWNsZUxpbWl0XCI6IDIwLCBcImluc3BlY3RBcnRpY2xlXCI6IHRydWUgfVxuXVxuIiwgImltcG9ydCB7IGdldENvbmZpZyB9IGZyb20gJy4uLy4uL2NvbmZpZyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9hZFRhcmdldFBvbGljeSB7XG4gIHdvcmtsb2FkOiBzdHJpbmc7XG4gIHdyaXRlPzogYm9vbGVhbjtcbn1cblxuLyoqXG4gKiBSZWplY3RzIHN1c3RhaW5lZCBvciB3cml0ZS1oZWF2eSB0cmFmZmljIGFnYWluc3Qgbm9uLWxvY2FsIHRhcmdldHMgdW5sZXNzIGV4cGxpY2l0bHkgYXBwcm92ZWQuXG4gKiBAcGFyYW0gcG9saWN5IFdvcmtsb2FkIGlkZW50aXR5IGFuZCB3aGV0aGVyIGl0IG11dGF0ZXMgdGFyZ2V0IGRhdGEuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc3NlcnRBdXRob3JpemVkTG9hZFRhcmdldChwb2xpY3k6IExvYWRUYXJnZXRQb2xpY3kpOiB2b2lkIHtcbiAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnKCk7XG4gIGNvbnN0IGxvb3BiYWNrID0gL15odHRwcz86XFwvXFwvKD86bG9jYWxob3N0fDEyN1xcLjBcXC4wXFwuMXxcXFs6OjFcXF0pKD86OlxcZCspPyg/OlxcL3wkKS9pLnRlc3QoXG4gICAgY29uZmlnLmJhc2VVcmwsXG4gICk7XG4gIGlmICgoY29uZmlnLmVudmlyb25tZW50ICE9PSAnbG9jYWwnIHx8ICFsb29wYmFjaykgJiYgX19FTlYuQUxMT1dfTk9OX0xPQ0FMX0xPQUQgIT09ICd0cnVlJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGAke3BvbGljeS53b3JrbG9hZH0gJHtwb2xpY3kud3JpdGUgPyAnd3JpdGUnIDogJ2xvYWQnfSB0cmFmZmljIHJlcXVpcmVzIGEgbG9vcGJhY2sgbG9jYWwgdGFyZ2V0IG9yIGV4cGxpY2l0IG93bmVkLXRhcmdldCBBTExPV19OT05fTE9DQUxfTE9BRD10cnVlYCxcbiAgICApO1xuICB9XG59XG5cbi8qKiBAdGhyb3dzIFdoZW4gYSB3cml0ZSB3b3JrbG9hZCB0YXJnZXRzIGEgbm9uLWxvY2FsIGVudmlyb25tZW50IHdpdGhvdXQgZXhwbGljaXQgYXV0aG9yaXphdGlvbi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc3NlcnRXcml0ZVRhcmdldCgpOiB2b2lkIHtcbiAgYXNzZXJ0QXV0aG9yaXplZExvYWRUYXJnZXQoeyB3b3JrbG9hZDogJ0F1dGhlbnRpY2F0ZWQnLCB3cml0ZTogdHJ1ZSB9KTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IFJlcXVlc3RSYXRlUHJvZmlsZSB9IGZyb20gJy4uLy4uL2NvbmZpZy93b3JrbG9hZHMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEFjaGlldmVkTG9hZCB7XG4gIHZhbGlkOiBib29sZWFuO1xuICByZWFzb25zOiBzdHJpbmdbXTtcbiAgY29uZmlndXJlZFJlcXVlc3RzUGVyU2Vjb25kOiBudW1iZXI7XG4gIG1lYXN1cmVtZW50U2Vjb25kczogbnVtYmVyO1xuICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbjogbnVtYmVyO1xuICBjb21wbGV0ZWRJdGVyYXRpb25zOiBudW1iZXIgfCBudWxsO1xuICByZXF1ZXN0czogbnVtYmVyIHwgbnVsbDtcbiAgZHJvcHBlZEl0ZXJhdGlvbnM6IG51bWJlciB8IG51bGw7XG4gIGFjaGlldmVkSXRlcmF0aW9uc1BlclNlY29uZDogbnVtYmVyIHwgbnVsbDtcbiAgYWNoaWV2ZWRSZXF1ZXN0c1BlclNlY29uZDogbnVtYmVyIHwgbnVsbDtcbn1cblxuLyoqIFZhbGlkYXRlIHRoZSBmaXhlZCBtZWFzdXJlbWVudCBjb2hvcnQ7IG1pc3NpbmcgZXZpZGVuY2UgaXMgbm90IHplcm8uICovXG5leHBvcnQgZnVuY3Rpb24gYXNzZXNzQWNoaWV2ZWRMb2FkKFxuICBwcm9maWxlOiBSZXF1ZXN0UmF0ZVByb2ZpbGUsXG4gIGNvdW50czoge1xuICAgIGl0ZXJhdGlvbnM/OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgcmVxdWVzdHM/OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgZHJvcHBlZD86IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgfSxcbik6IEFjaGlldmVkTG9hZCB7XG4gIGNvbnN0IHJlYXNvbnM6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHZhbGlkQ291bnQgPSAodmFsdWU6IG51bWJlciB8IHVuZGVmaW5lZCk6IHZhbHVlIGlzIG51bWJlciA9PlxuICAgIHZhbHVlICE9PSB1bmRlZmluZWQgJiYgTnVtYmVyLmlzU2FmZUludGVnZXIodmFsdWUpICYmIHZhbHVlID49IDA7XG4gIGNvbnN0IGl0ZXJhdGlvbnMgPSB2YWxpZENvdW50KGNvdW50cy5pdGVyYXRpb25zKSA/IGNvdW50cy5pdGVyYXRpb25zIDogbnVsbDtcbiAgY29uc3QgcmVxdWVzdHMgPSB2YWxpZENvdW50KGNvdW50cy5yZXF1ZXN0cykgPyBjb3VudHMucmVxdWVzdHMgOiBudWxsO1xuICBjb25zdCBkcm9wcGVkID0gdmFsaWRDb3VudChjb3VudHMuZHJvcHBlZCkgPyBjb3VudHMuZHJvcHBlZCA6IG51bGw7XG4gIGlmIChpdGVyYXRpb25zID09PSBudWxsIHx8IHJlcXVlc3RzID09PSBudWxsIHx8IGRyb3BwZWQgPT09IG51bGwpIHtcbiAgICByZWFzb25zLnB1c2goJ01pc3Npbmcgb3IgaW52YWxpZCBtZWFzdXJlbWVudCBjb3VudCcpO1xuICB9XG4gIGNvbnN0IGV4cGVjdGVkID0gcHJvZmlsZS5yZXF1ZXN0c1BlclNlY29uZCAqIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzO1xuICBpZiAoaXRlcmF0aW9ucyAhPT0gbnVsbCAmJiBpdGVyYXRpb25zIDwgZXhwZWN0ZWQgKiBwcm9maWxlLm1pbmltdW1BY2hpZXZlZEZyYWN0aW9uKSB7XG4gICAgcmVhc29ucy5wdXNoKCdBY2hpZXZlZCBhcnJpdmFsIGl0ZXJhdGlvbnMgYmVsb3cgcHJlZGVjbGFyZWQgbWluaW11bScpO1xuICB9XG4gIGlmIChyZXF1ZXN0cyAhPT0gbnVsbCAmJiByZXF1ZXN0cyA8IGV4cGVjdGVkICogcHJvZmlsZS5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbikge1xuICAgIHJlYXNvbnMucHVzaCgnQWNoaWV2ZWQgSFRUUCByZXF1ZXN0cyBiZWxvdyBwcmVkZWNsYXJlZCBtaW5pbXVtJyk7XG4gIH1cbiAgaWYgKHJlcXVlc3RzICE9PSBudWxsICYmIGl0ZXJhdGlvbnMgIT09IG51bGwgJiYgcmVxdWVzdHMgIT09IGl0ZXJhdGlvbnMpIHtcbiAgICByZWFzb25zLnB1c2goJ09uZS1yZXF1ZXN0LXBlci1jb21wbGV0ZWQtaXRlcmF0aW9uIGNvbnRyYWN0IHZpb2xhdGVkJyk7XG4gIH1cbiAgaWYgKHJlcXVlc3RzICE9PSBudWxsICYmIHJlcXVlc3RzID4gZXhwZWN0ZWQgKyAxKSB7XG4gICAgcmVhc29ucy5wdXNoKCdSZXF1ZXN0IGNvdW50IGV4Y2VlZHMgY29uZmlndXJlZCBhcnJpdmFsIGNvaG9ydCcpO1xuICB9XG4gIGlmIChkcm9wcGVkICE9PSBudWxsICYmIGRyb3BwZWQgPiAwKSByZWFzb25zLnB1c2goJ0dlbmVyYXRvciBkcm9wcGVkIG1lYXN1cmVtZW50IGl0ZXJhdGlvbnMnKTtcbiAgcmV0dXJuIHtcbiAgICB2YWxpZDogcmVhc29ucy5sZW5ndGggPT09IDAsXG4gICAgcmVhc29ucyxcbiAgICBjb25maWd1cmVkUmVxdWVzdHNQZXJTZWNvbmQ6IHByb2ZpbGUucmVxdWVzdHNQZXJTZWNvbmQsXG4gICAgbWVhc3VyZW1lbnRTZWNvbmRzOiBwcm9maWxlLm1lYXN1cmVtZW50U2Vjb25kcyxcbiAgICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbjogcHJvZmlsZS5taW5pbXVtQWNoaWV2ZWRGcmFjdGlvbixcbiAgICBjb21wbGV0ZWRJdGVyYXRpb25zOiBpdGVyYXRpb25zLFxuICAgIHJlcXVlc3RzLFxuICAgIGRyb3BwZWRJdGVyYXRpb25zOiBkcm9wcGVkLFxuICAgIGFjaGlldmVkSXRlcmF0aW9uc1BlclNlY29uZDpcbiAgICAgIGl0ZXJhdGlvbnMgPT09IG51bGwgPyBudWxsIDogaXRlcmF0aW9ucyAvIHByb2ZpbGUubWVhc3VyZW1lbnRTZWNvbmRzLFxuICAgIGFjaGlldmVkUmVxdWVzdHNQZXJTZWNvbmQ6IHJlcXVlc3RzID09PSBudWxsID8gbnVsbCA6IHJlcXVlc3RzIC8gcHJvZmlsZS5tZWFzdXJlbWVudFNlY29uZHMsXG4gIH07XG59XG4iLCAiaW1wb3J0IHsgZ2V0UmVxdWVzdFJhdGVQcm9maWxlLCBnZXRXb3JrbG9hZFByb2ZpbGUgfSBmcm9tICcuLi8uLi9jb25maWcvd29ya2xvYWRzJztcbmltcG9ydCB7IGFzc2Vzc0FjaGlldmVkTG9hZCB9IGZyb20gJy4vYWNoaWV2ZWQtbG9hZCc7XG5pbXBvcnQgdHlwZSB7IEFjaGlldmVkTG9hZCB9IGZyb20gJy4vYWNoaWV2ZWQtbG9hZCc7XG5cbmludGVyZmFjZSBNZXRyaWNWYWx1ZXMge1xuICBhdmc/OiBudW1iZXI7XG4gIGNvdW50PzogbnVtYmVyO1xuICBmYWlscz86IG51bWJlcjtcbiAgbWF4PzogbnVtYmVyO1xuICBtZWQ/OiBudW1iZXI7XG4gIG1pbj86IG51bWJlcjtcbiAgcGFzc2VzPzogbnVtYmVyO1xuICAncCg5MCknPzogbnVtYmVyO1xuICAncCg5NSknPzogbnVtYmVyO1xuICAncCg5OSknPzogbnVtYmVyO1xuICByYXRlPzogbnVtYmVyO1xuICB2YWx1ZT86IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIFN1bW1hcnlNZXRyaWMge1xuICBjb250YWlucz86IHN0cmluZztcbiAgdGhyZXNob2xkcz86IFJlY29yZDxzdHJpbmcsIHsgb2s6IGJvb2xlYW4gfT47XG4gIHR5cGU/OiBzdHJpbmc7XG4gIHZhbHVlczogTWV0cmljVmFsdWVzO1xufVxuXG5pbnRlcmZhY2UgU3VtbWFyeURhdGEge1xuICBtZXRyaWNzOiBSZWNvcmQ8c3RyaW5nLCBTdW1tYXJ5TWV0cmljPjtcbiAgcm9vdF9ncm91cDogdW5rbm93bjtcbiAgc3RhdGU6IHtcbiAgICBzZXR1cEVycm9ycz86IG51bWJlcjtcbiAgICBpbnRlcnJ1cHRlZEl0ZXJhdGlvbnM/OiBudW1iZXI7XG4gICAgW2tleTogc3RyaW5nXTogdW5rbm93bjtcbiAgfTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQZXJmb3JtYW5jZVN1bW1hcnkge1xuICBhY2hpZXZlZExvYWQ6IEFjaGlldmVkTG9hZCB8IG51bGw7XG4gIGZhaWx1cmVzOiBzdHJpbmdbXTtcbiAgZ2VuZXJhdGVkQXQ6IHN0cmluZztcbiAgbWV0cmljczogUmVjb3JkPHN0cmluZywgTWV0cmljVmFsdWVzPjtcbiAgbWV0YWRhdGE6IHtcbiAgICBlbnZpcm9ubWVudDogc3RyaW5nO1xuICAgIGZyYW1ld29ya0NvbW1pdDogc3RyaW5nO1xuICAgIGs2VmVyc2lvbjogc3RyaW5nO1xuICAgIG1heFZ1czogbnVtYmVyIHwgbnVsbDtcbiAgICBwcm9maWxlOiBzdHJpbmc7XG4gICAgcnVubmVyQ2xhc3M6IHN0cmluZztcbiAgICB0YXJnZXRDb21taXQ6IHN0cmluZztcbiAgICB0YXJnZXRJZDogc3RyaW5nO1xuICAgIHdvcmtsb2FkU2NoZW1hOiBzdHJpbmc7XG4gICAgdGFyZ2V0SXRlcmF0aW9uc1BlclNlY29uZDogbnVtYmVyO1xuICAgIHRhcmdldFJlcXVlc3RzUGVyU2Vjb25kOiBudW1iZXIgfCBudWxsO1xuICAgIG1lYXN1cmVtZW50U2Vjb25kczogbnVtYmVyIHwgbnVsbDtcbiAgICB3YXJtdXBTZWNvbmRzOiBudW1iZXIgfCBudWxsO1xuICAgIG1pbmltdW1BY2hpZXZlZEZyYWN0aW9uOiBudW1iZXIgfCBudWxsO1xuICB9O1xuICByb290R3JvdXA6IHVua25vd247XG4gIHN0YXRlOiB1bmtub3duO1xuICB0aHJlc2hvbGRzOiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCB7IG9rOiBib29sZWFuIH0+Pjtcbn1cblxuZnVuY3Rpb24gc3VtbWFyeUZpbGUoKTogc3RyaW5nIHtcbiAgY29uc3QgbmFtZSA9IF9fRU5WLlNVTU1BUllfTkFNRSA/PyAnazYtc3VtbWFyeSc7XG4gIHJldHVybiBgcmVwb3J0cy8ke25hbWV9LXN1bW1hcnkuanNvbmA7XG59XG5cbmZ1bmN0aW9uIG1hcmtkb3duRmlsZSgpOiBzdHJpbmcge1xuICBjb25zdCBuYW1lID0gX19FTlYuU1VNTUFSWV9OQU1FID8/ICdrNi1zdW1tYXJ5JztcbiAgcmV0dXJuIGByZXBvcnRzLyR7bmFtZX0tc3VtbWFyeS5tZGA7XG59XG5cbmZ1bmN0aW9uIGh0bWxGaWxlKCk6IHN0cmluZyB7XG4gIGNvbnN0IG5hbWUgPSBfX0VOVi5TVU1NQVJZX05BTUUgPz8gJ2s2LXN1bW1hcnknO1xuICByZXR1cm4gYHJlcG9ydHMvJHtuYW1lfS1zdW1tYXJ5Lmh0bWxgO1xufVxuXG5mdW5jdGlvbiBtZXRyaWNSb3cobmFtZTogc3RyaW5nLCB2YWx1ZXM6IE1ldHJpY1ZhbHVlcyB8IHVuZGVmaW5lZCk6IHN0cmluZyB7XG4gIGNvbnN0IG1lZGlhbiA9IHZhbHVlcz8ubWVkO1xuICBjb25zdCBwOTAgPSB2YWx1ZXM/LlsncCg5MCknXTtcbiAgY29uc3QgcDk1ID0gdmFsdWVzPy5bJ3AoOTUpJ107XG4gIGNvbnN0IHA5OSA9IHZhbHVlcz8uWydwKDk5KSddO1xuICBjb25zdCBtYXggPSB2YWx1ZXM/Lm1heDtcbiAgY29uc3QgcmF0ZSA9IHZhbHVlcz8ucmF0ZTtcbiAgY29uc3QgY291bnQgPSB2YWx1ZXM/LmNvdW50O1xuICByZXR1cm4gYHwgJHtuYW1lfSB8ICR7bWVkaWFuPy50b0ZpeGVkKDIpID8/ICctJ30gfCAke3A5MD8udG9GaXhlZCgyKSA/PyAnLSd9IHwgJHtwOTU/LnRvRml4ZWQoMikgPz8gJy0nfSB8ICR7cDk5Py50b0ZpeGVkKDIpID8/ICctJ30gfCAke21heD8udG9GaXhlZCgyKSA/PyAnLSd9IHwgJHtyYXRlPy50b0ZpeGVkKDQpID8/ICctJ30gfCAke2NvdW50ID8/ICctJ30gfGA7XG59XG5cbmZ1bmN0aW9uIHRocmVzaG9sZEFjdHVhbCh2YWx1ZXM6IE1ldHJpY1ZhbHVlcywgdGhyZXNob2xkOiBzdHJpbmcpOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICBjb25zdCBrZXkgPSB0aHJlc2hvbGQubWF0Y2goL14ocFxcKFxcZCtcXCl8YXZnfG1lZHxtaW58bWF4fHJhdGV8Y291bnR8dmFsdWUpLyk/LlsxXTtcbiAgcmV0dXJuIGtleSA/IHZhbHVlc1trZXkgYXMga2V5b2YgTWV0cmljVmFsdWVzXSA6IHVuZGVmaW5lZDtcbn1cblxuZnVuY3Rpb24gaHRtbEVzY2FwZSh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHZhbHVlXG4gICAgLnJlcGxhY2VBbGwoJyYnLCAnJmFtcDsnKVxuICAgIC5yZXBsYWNlQWxsKCc8JywgJyZsdDsnKVxuICAgIC5yZXBsYWNlQWxsKCc+JywgJyZndDsnKVxuICAgIC5yZXBsYWNlQWxsKCdcIicsICcmcXVvdDsnKTtcbn1cblxuZnVuY3Rpb24gbWV0cmljVmFsdWUodmFsdWU6IG51bWJlciB8IHVuZGVmaW5lZCwgZGlnaXRzID0gMik6IHN0cmluZyB7XG4gIHJldHVybiB2YWx1ZSA9PT0gdW5kZWZpbmVkID8gJy0nIDogdmFsdWUudG9GaXhlZChkaWdpdHMpO1xufVxuXG5mdW5jdGlvbiBodG1sTWV0cmljUm93cyhtZXRyaWNzOiBSZWNvcmQ8c3RyaW5nLCBNZXRyaWNWYWx1ZXM+LCBuYW1lczogc3RyaW5nW10pOiBzdHJpbmcge1xuICBpZiAobmFtZXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuICc8dHI+PHRkIGNvbHNwYW49XCI3XCI+Tm8gbWF0Y2hpbmcgbWV0cmljcyB3ZXJlIGVtaXR0ZWQuPC90ZD48L3RyPic7XG4gIH1cbiAgcmV0dXJuIG5hbWVzXG4gICAgLm1hcCgobmFtZSkgPT4ge1xuICAgICAgY29uc3QgdmFsdWVzID0gbWV0cmljc1tuYW1lXSA/PyB7fTtcbiAgICAgIHJldHVybiBgPHRyPjx0ZD4ke2h0bWxFc2NhcGUobmFtZSl9PC90ZD48dGQ+JHttZXRyaWNWYWx1ZSh2YWx1ZXMubWVkKX08L3RkPjx0ZD4ke21ldHJpY1ZhbHVlKHZhbHVlc1sncCg5MCknXSl9PC90ZD48dGQ+JHttZXRyaWNWYWx1ZSh2YWx1ZXNbJ3AoOTUpJ10pfTwvdGQ+PHRkPiR7bWV0cmljVmFsdWUodmFsdWVzWydwKDk5KSddKX08L3RkPjx0ZD4ke21ldHJpY1ZhbHVlKHZhbHVlcy5yYXRlLCA0KX08L3RkPjx0ZD4ke3ZhbHVlcy5jb3VudCA/PyAnLSd9PC90ZD48L3RyPmA7XG4gICAgfSlcbiAgICAuam9pbignJyk7XG59XG5cbmZ1bmN0aW9uIGh0bWxUaHJlc2hvbGRSb3dzKHN1bW1hcnk6IFBlcmZvcm1hbmNlU3VtbWFyeSk6IHN0cmluZyB7XG4gIGNvbnN0IHJvd3MgPSBPYmplY3QuZW50cmllcyhzdW1tYXJ5LnRocmVzaG9sZHMpLmZsYXRNYXAoKFttZXRyaWMsIHRocmVzaG9sZHNdKSA9PlxuICAgIE9iamVjdC5lbnRyaWVzKHRocmVzaG9sZHMpLm1hcCgoW3RocmVzaG9sZCwgcmVzdWx0XSkgPT4ge1xuICAgICAgY29uc3QgYWN0dWFsID0gdGhyZXNob2xkQWN0dWFsKHN1bW1hcnkubWV0cmljc1ttZXRyaWNdID8/IHt9LCB0aHJlc2hvbGQpO1xuICAgICAgcmV0dXJuIGA8dHI+PHRkPiR7aHRtbEVzY2FwZShtZXRyaWMpfTwvdGQ+PHRkPiR7aHRtbEVzY2FwZSh0aHJlc2hvbGQpfTwvdGQ+PHRkPiR7YWN0dWFsID8/ICd1bmF2YWlsYWJsZSd9PC90ZD48dGQgY2xhc3M9XCIke3Jlc3VsdC5vayA/ICdwYXNzZWQnIDogJ2ZhaWxlZCd9XCI+JHtyZXN1bHQub2sgPyAnUEFTUycgOiAnRkFJTCd9PC90ZD48L3RyPmA7XG4gICAgfSksXG4gICk7XG4gIHJldHVybiByb3dzLmxlbmd0aCA9PT0gMFxuICAgID8gJzx0cj48dGQgY29sc3Bhbj1cIjRcIj5ObyB0aHJlc2hvbGQgcmVzdWx0cyB3ZXJlIHJlcG9ydGVkLjwvdGQ+PC90cj4nXG4gICAgOiByb3dzLmpvaW4oJycpO1xufVxuXG4vKipcbiAqIFByb2R1Y2VzIG1hY2hpbmUtcmVhZGFibGUgYW5kIHJldmlld2VyLXJlYWRhYmxlIGFydGlmYWN0cyBmcm9tIGEgY29tcGxldGVkIGs2IHJ1bi5cbiAqIEBwYXJhbSBkYXRhIGs2IGVuZC1vZi10ZXN0IHN1bW1hcnkgZGF0YS5cbiAqIEByZXR1cm5zIE91dHB1dCBwYXRocyBtYXBwZWQgdG8gc2VyaWFsaXplZCByZXBvcnQgY29udGVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN1bW1hcnkoZGF0YTogU3VtbWFyeURhdGEpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgY29uc3Qgd29ya2xvYWQgPSBnZXRXb3JrbG9hZFByb2ZpbGUoKTtcbiAgY29uc3QgcmVxdWVzdFByb2ZpbGUgPSBfX0VOVi5XT1JLTE9BRF9NT0RFID09PSAncmVxdWVzdC1yYXRlJyA/IGdldFJlcXVlc3RSYXRlUHJvZmlsZSgpIDogbnVsbDtcbiAgY29uc3QgYWNoaWV2ZWRMb2FkID0gcmVxdWVzdFByb2ZpbGVcbiAgICA/IGFzc2Vzc0FjaGlldmVkTG9hZChyZXF1ZXN0UHJvZmlsZSwge1xuICAgICAgICBpdGVyYXRpb25zOiBkYXRhLm1ldHJpY3NbJ2l0ZXJhdGlvbnN7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nXT8udmFsdWVzLmNvdW50LFxuICAgICAgICByZXF1ZXN0czogZGF0YS5tZXRyaWNzWydodHRwX3JlcXN7c2NlbmFyaW86cmVxdWVzdF9tZWFzdXJlbWVudH0nXT8udmFsdWVzLmNvdW50LFxuICAgICAgICBkcm9wcGVkOiBkYXRhLm1ldHJpY3NbJ2Ryb3BwZWRfaXRlcmF0aW9uc3tzY2VuYXJpbzpyZXF1ZXN0X21lYXN1cmVtZW50fSddPy52YWx1ZXMuY291bnQsXG4gICAgICB9KVxuICAgIDogbnVsbDtcbiAgY29uc3QgY2hlY2tGYWlsdXJlcyA9IGRhdGEubWV0cmljcy5jaGVja3M/LnZhbHVlcy5mYWlscyA/PyAwO1xuICBjb25zdCBpbnRlcnJ1cHRlZEl0ZXJhdGlvbnMgPVxuICAgIGRhdGEubWV0cmljcy5pbnRlcnJ1cHRlZF9pdGVyYXRpb25zPy52YWx1ZXMuY291bnQgPz8gZGF0YS5zdGF0ZS5pbnRlcnJ1cHRlZEl0ZXJhdGlvbnMgPz8gMDtcbiAgY29uc3Qgc2V0dXBFcnJvcnMgPSBkYXRhLnN0YXRlLnNldHVwRXJyb3JzID8/IDA7XG4gIGNvbnN0IHN1bW1hcnk6IFBlcmZvcm1hbmNlU3VtbWFyeSA9IHtcbiAgICBhY2hpZXZlZExvYWQsXG4gICAgZmFpbHVyZXM6IFtdLFxuICAgIGdlbmVyYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgbWV0cmljczogT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgICAgT2JqZWN0LmVudHJpZXMoZGF0YS5tZXRyaWNzKS5tYXAoKFtuYW1lLCBtZXRyaWNdKSA9PiBbbmFtZSwgbWV0cmljLnZhbHVlc10pLFxuICAgICksXG4gICAgbWV0YWRhdGE6IHtcbiAgICAgIGVudmlyb25tZW50OiBfX0VOVi5UQVJHRVRfRU5WID8/ICdsb2NhbCcsXG4gICAgICBmcmFtZXdvcmtDb21taXQ6IF9fRU5WLkZSQU1FV09SS19DT01NSVQgPz8gJ3Vua25vd24nLFxuICAgICAgazZWZXJzaW9uOiBfX0VOVi5LNl9WRVJTSU9OID8/ICcyLjAuMCcsXG4gICAgICBtYXhWdXM6IHJlcXVlc3RQcm9maWxlPy5tYXhWdXMgPz8gd29ya2xvYWQubWF4VnVzLFxuICAgICAgcHJvZmlsZTogX19FTlYuVEVTVF9QUk9GSUxFID8/ICdmdWxsJyxcbiAgICAgIHJ1bm5lckNsYXNzOiBfX0VOVi5SVU5ORVJfQ0xBU1MgPz8gJ2xvY2FsJyxcbiAgICAgIHRhcmdldENvbW1pdDogX19FTlYuVEFSR0VUX0NPTU1JVCA/PyAndW5rbm93bicsXG4gICAgICB0YXJnZXRJZDogX19FTlYuVEFSR0VUX0lEID8/IF9fRU5WLlRBUkdFVF9FTlYgPz8gJ2xvY2FsJyxcbiAgICAgIHdvcmtsb2FkU2NoZW1hOiByZXF1ZXN0UHJvZmlsZSA/ICdzaW5nbGUtcmVxdWVzdC1hcnJpdmFsLXYxJyA6ICdqb3VybmV5LWFycml2YWwtdjEnLFxuICAgICAgdGFyZ2V0SXRlcmF0aW9uc1BlclNlY29uZDpcbiAgICAgICAgcmVxdWVzdFByb2ZpbGU/LnJlcXVlc3RzUGVyU2Vjb25kID8/IHdvcmtsb2FkLnRhcmdldEl0ZXJhdGlvbnNQZXJTZWNvbmQsXG4gICAgICB0YXJnZXRSZXF1ZXN0c1BlclNlY29uZDogcmVxdWVzdFByb2ZpbGU/LnJlcXVlc3RzUGVyU2Vjb25kID8/IG51bGwsXG4gICAgICBtZWFzdXJlbWVudFNlY29uZHM6IHJlcXVlc3RQcm9maWxlPy5tZWFzdXJlbWVudFNlY29uZHMgPz8gbnVsbCxcbiAgICAgIHdhcm11cFNlY29uZHM6IHJlcXVlc3RQcm9maWxlPy53YXJtdXBTZWNvbmRzID8/IG51bGwsXG4gICAgICBtaW5pbXVtQWNoaWV2ZWRGcmFjdGlvbjogcmVxdWVzdFByb2ZpbGU/Lm1pbmltdW1BY2hpZXZlZEZyYWN0aW9uID8/IG51bGwsXG4gICAgfSxcbiAgICByb290R3JvdXA6IGRhdGEucm9vdF9ncm91cCxcbiAgICBzdGF0ZTogZGF0YS5zdGF0ZSxcbiAgICB0aHJlc2hvbGRzOiBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgICBPYmplY3QuZW50cmllcyhkYXRhLm1ldHJpY3MpXG4gICAgICAgIC5maWx0ZXIoKFssIG1ldHJpY10pID0+IG1ldHJpYy50aHJlc2hvbGRzKVxuICAgICAgICAubWFwKChbbmFtZSwgbWV0cmljXSkgPT4gW25hbWUsIG1ldHJpYy50aHJlc2hvbGRzID8/IHt9XSksXG4gICAgKSxcbiAgfTtcbiAgY29uc3QgZmFpbGVkVGhyZXNob2xkcyA9IE9iamVjdC5lbnRyaWVzKHN1bW1hcnkudGhyZXNob2xkcykuZmxhdE1hcCgoW21ldHJpYywgdGhyZXNob2xkc10pID0+XG4gICAgT2JqZWN0LmVudHJpZXModGhyZXNob2xkcylcbiAgICAgIC5maWx0ZXIoKFssIHJlc3VsdF0pID0+ICFyZXN1bHQub2spXG4gICAgICAubWFwKChbdGhyZXNob2xkXSkgPT4ge1xuICAgICAgICBjb25zdCBhY3R1YWwgPSB0aHJlc2hvbGRBY3R1YWwoc3VtbWFyeS5tZXRyaWNzW21ldHJpY10gPz8ge30sIHRocmVzaG9sZCk7XG4gICAgICAgIHJldHVybiBgJHttZXRyaWN9OiBleHBlY3RlZCAke3RocmVzaG9sZH07IGFjdHVhbCAke2FjdHVhbCA/PyAndW5hdmFpbGFibGUnfWA7XG4gICAgICB9KSxcbiAgKTtcbiAgc3VtbWFyeS5mYWlsdXJlcyA9IFtcbiAgICAuLi4oYWNoaWV2ZWRMb2FkICYmICFhY2hpZXZlZExvYWQudmFsaWRcbiAgICAgID8gYWNoaWV2ZWRMb2FkLnJlYXNvbnMubWFwKChyZWFzb24pID0+IGBJbnZhbGlkIGxvYWQgZXhwZXJpbWVudDogJHtyZWFzb259YClcbiAgICAgIDogW10pLFxuICAgIC4uLmZhaWxlZFRocmVzaG9sZHMubWFwKChmYWlsdXJlKSA9PiBgVGhyZXNob2xkOiAke2ZhaWx1cmV9YCksXG4gICAgLi4uKGNoZWNrRmFpbHVyZXMgPiAwID8gW2BDaGVja3M6ICR7Y2hlY2tGYWlsdXJlc30gZmFpbGVkYF0gOiBbXSksXG4gICAgLi4uKHNldHVwRXJyb3JzID4gMCA/IFtgU2V0dXA6ICR7c2V0dXBFcnJvcnN9IGVycm9yKHMpYF0gOiBbXSksXG4gICAgLi4uKGludGVycnVwdGVkSXRlcmF0aW9ucyA+IDBcbiAgICAgID8gW2BFeGVjdXRpb246ICR7aW50ZXJydXB0ZWRJdGVyYXRpb25zfSBpbnRlcnJ1cHRlZCBpdGVyYXRpb24ocylgXVxuICAgICAgOiBbXSksXG4gIF07XG4gIGNvbnN0IG1hcmtkb3duID0gW1xuICAgICcjIGs2IFBlcmZvcm1hbmNlIFN1bW1hcnknLFxuICAgICcnLFxuICAgIGAqKlJ1biBzdGF0dXM6KiogJHtzdW1tYXJ5LmZhaWx1cmVzLmxlbmd0aCA/ICdGQUlMRUQnIDogJ1BBU1NFRCd9YCxcbiAgICBgKipUYXJnZXQ6KiogJHtzdW1tYXJ5Lm1ldGFkYXRhLnRhcmdldElkfSAoJHtzdW1tYXJ5Lm1ldGFkYXRhLnRhcmdldENvbW1pdH0pYCxcbiAgICBgKipQcm9maWxlOioqICR7c3VtbWFyeS5tZXRhZGF0YS5wcm9maWxlfSBvbiAke3N1bW1hcnkubWV0YWRhdGEucnVubmVyQ2xhc3N9YCxcbiAgICBgKipXb3JrbG9hZCBzY2hlbWE6KiogJHtzdW1tYXJ5Lm1ldGFkYXRhLndvcmtsb2FkU2NoZW1hfWAsXG4gICAgYCoqQ29uZmlndXJlZCBhcnJpdmFsOioqICR7c3VtbWFyeS5tZXRhZGF0YS50YXJnZXRJdGVyYXRpb25zUGVyU2Vjb25kfSBpdGVyYXRpb25zL3NgLFxuICAgIGAqKkNvbmZpZ3VyZWQgcmVxdWVzdHM6KiogJHtzdW1tYXJ5Lm1ldGFkYXRhLnRhcmdldFJlcXVlc3RzUGVyU2Vjb25kID8/ICdub3QgZml4ZWQgYnkgam91cm5leSBhcnJpdmFsJ30ke3JlcXVlc3RQcm9maWxlID8gJyByZXF1ZXN0cy9zJyA6ICcnfWAsXG4gICAgLi4uKGFjaGlldmVkTG9hZFxuICAgICAgPyBbXG4gICAgICAgICAgYCoqTWVhc3VyZW1lbnQ6KiogJHthY2hpZXZlZExvYWQubWVhc3VyZW1lbnRTZWNvbmRzfXMgc2NoZWR1bGVkIGFycml2YWwgd2luZG93LCBleGNsdWRpbmcgd2FybS11cCBhbmQgdGhlIDJzIHNldHRsaW5nIGdhcGAsXG4gICAgICAgICAgYCoqQWNoaWV2ZWQ6KiogJHthY2hpZXZlZExvYWQuYWNoaWV2ZWRJdGVyYXRpb25zUGVyU2Vjb25kID8/ICd1bmtub3duJ30gY29tcGxldGVkIGl0ZXJhdGlvbnMvczsgJHthY2hpZXZlZExvYWQuYWNoaWV2ZWRSZXF1ZXN0c1BlclNlY29uZCA/PyAndW5rbm93bid9IHJlcXVlc3RzL3M7ICR7YWNoaWV2ZWRMb2FkLmRyb3BwZWRJdGVyYXRpb25zID8/ICd1bmtub3duJ30gZHJvcHBlZCBpdGVyYXRpb25zYCxcbiAgICAgICAgICBgKipMb2FkIHZhbGlkaXR5OioqICR7YWNoaWV2ZWRMb2FkLnZhbGlkID8gJ1ZBTElEJyA6ICdJTlZBTElEJ30gKHByZWRlY2xhcmVkIG1pbmltdW0gZnJhY3Rpb24gJHthY2hpZXZlZExvYWQubWluaW11bUFjaGlldmVkRnJhY3Rpb259KWAsXG4gICAgICAgIF1cbiAgICAgIDogW1xuICAgICAgICAgIGAqKk9ic2VydmVkIGZ1bGwtcnVuIHJhdGVzOioqICR7c3VtbWFyeS5tZXRyaWNzLml0ZXJhdGlvbnM/LnJhdGUgPz8gJ3Vua25vd24nfSBpdGVyYXRpb25zL3M7ICR7c3VtbWFyeS5tZXRyaWNzLmh0dHBfcmVxcz8ucmF0ZSA/PyAndW5rbm93bid9IHJlcXVlc3RzL3MgKG5hdGl2ZSBmdWxsLXJ1biBkZW5vbWluYXRvciwgbm90IGEgc2VwYXJhdGVkIHN0ZWFkeS1zdGF0ZSB3aW5kb3cpYCxcbiAgICAgICAgXSksXG4gICAgLi4uKHN1bW1hcnkuZmFpbHVyZXMubGVuZ3RoID8gWycnLCAuLi5zdW1tYXJ5LmZhaWx1cmVzLm1hcCgoZmFpbHVyZSkgPT4gYC0gJHtmYWlsdXJlfWApXSA6IFtdKSxcbiAgICAnJyxcbiAgICAnfCBNZXRyaWMgfCBwNTAgfCBwOTAgfCBwOTUgfCBwOTkgfCBtYXggfCBSYXRlIHwgQ291bnQgfCcsXG4gICAgJ3wtLS18LS0tOnwtLS06fC0tLTp8LS0tOnwtLS06fC0tLTp8LS0tOnwnLFxuICAgIG1ldHJpY1JvdygnaHR0cF9yZXFfZHVyYXRpb24nLCBzdW1tYXJ5Lm1ldHJpY3MuaHR0cF9yZXFfZHVyYXRpb24pLFxuICAgIG1ldHJpY1JvdygnaHR0cF9yZXFfZmFpbGVkJywgc3VtbWFyeS5tZXRyaWNzLmh0dHBfcmVxX2ZhaWxlZCksXG4gICAgbWV0cmljUm93KCdjaGVja3MnLCBzdW1tYXJ5Lm1ldHJpY3MuY2hlY2tzKSxcbiAgICBtZXRyaWNSb3coJ2h0dHBfcmVxcycsIHN1bW1hcnkubWV0cmljcy5odHRwX3JlcXMpLFxuICAgIG1ldHJpY1JvdygnaXRlcmF0aW9ucycsIHN1bW1hcnkubWV0cmljcy5pdGVyYXRpb25zKSxcbiAgICBtZXRyaWNSb3coJ2N1c3RvbV9hcnRpY2xlX3JlYWRfZHVyYXRpb25fbXMnLCBzdW1tYXJ5Lm1ldHJpY3MuY3VzdG9tX2FydGljbGVfcmVhZF9kdXJhdGlvbl9tcyksXG4gICAgbWV0cmljUm93KCdjdXN0b21fYnVzaW5lc3NfZXJyb3JzX3RvdGFsJywgc3VtbWFyeS5tZXRyaWNzLmN1c3RvbV9idXNpbmVzc19lcnJvcnNfdG90YWwpLFxuICAgICcnLFxuICBdLmpvaW4oJ1xcbicpO1xuICBjb25zdCBkdXJhdGlvbiA9IHN1bW1hcnkubWV0cmljcy5odHRwX3JlcV9kdXJhdGlvbiA/PyB7fTtcbiAgY29uc3QgYmFycyA9IFtcbiAgICBbJ3A1MCcsIGR1cmF0aW9uLm1lZCA/PyAwXSxcbiAgICBbJ3A5MCcsIGR1cmF0aW9uWydwKDkwKSddID8/IDBdLFxuICAgIFsncDk1JywgZHVyYXRpb25bJ3AoOTUpJ10gPz8gMF0sXG4gICAgWydwOTknLCBkdXJhdGlvblsncCg5OSknXSA/PyAwXSxcbiAgICBbJ21heCcsIGR1cmF0aW9uLm1heCA/PyAwXSxcbiAgXSBhcyBjb25zdDtcbiAgY29uc3QgbWF4aW11bSA9IE1hdGgubWF4KC4uLmJhcnMubWFwKChbLCB2YWx1ZV0pID0+IHZhbHVlKSwgMSk7XG4gIGNvbnN0IGNoYXJ0ID0gYmFyc1xuICAgIC5tYXAoXG4gICAgICAoW2xhYmVsLCB2YWx1ZV0sIGluZGV4KSA9PlxuICAgICAgICBgPGcgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDAgJHtpbmRleCAqIDQyfSlcIj48dGV4dCB4PVwiMFwiIHk9XCIyMFwiPiR7bGFiZWx9PC90ZXh0PjxyZWN0IHg9XCI0OFwiIHk9XCI0XCIgd2lkdGg9XCIkeyh2YWx1ZSAvIG1heGltdW0pICogNTAwfVwiIGhlaWdodD1cIjIyXCIgZmlsbD1cIiMyNTYzZWJcIi8+PHRleHQgeD1cIiR7NTYgKyAodmFsdWUgLyBtYXhpbXVtKSAqIDUwMH1cIiB5PVwiMjBcIj4ke3ZhbHVlLnRvRml4ZWQoMil9IG1zPC90ZXh0PjwvZz5gLFxuICAgIClcbiAgICAuam9pbignJyk7XG4gIGNvbnN0IGVuZHBvaW50TWV0cmljcyA9IE9iamVjdC5rZXlzKHN1bW1hcnkubWV0cmljcylcbiAgICAuZmlsdGVyKFxuICAgICAgKG5hbWUpID0+XG4gICAgICAgIG5hbWUuc3RhcnRzV2l0aCgnaHR0cF9yZXFfZHVyYXRpb257bmFtZTonKSB8fCBuYW1lLnN0YXJ0c1dpdGgoJ2h0dHBfcmVxX2ZhaWxlZHtuYW1lOicpLFxuICAgIClcbiAgICAuc29ydCgpO1xuICBjb25zdCBidXNpbmVzc01ldHJpY3MgPSBPYmplY3Qua2V5cyhzdW1tYXJ5Lm1ldHJpY3MpXG4gICAgLmZpbHRlcigobmFtZSkgPT4gbmFtZS5zdGFydHNXaXRoKCdjdXN0b21fJykpXG4gICAgLnNvcnQoKTtcbiAgY29uc3QgaHRtbCA9IGA8IWRvY3R5cGUgaHRtbD5cbjxodG1sPjxoZWFkPjxtZXRhIGNoYXJzZXQ9XCJ1dGYtOFwiPjx0aXRsZT5rNiBQZXJmb3JtYW5jZSBTdW1tYXJ5PC90aXRsZT5cbjxzdHlsZT5ib2R5e2ZvbnQ6MTZweCBzeXN0ZW0tdWk7bWF4LXdpZHRoOjExMjBweDttYXJnaW46NDBweCBhdXRvO3BhZGRpbmc6MCAyMHB4O2NvbG9yOiMxODIxMmZ9dGFibGV7Ym9yZGVyLWNvbGxhcHNlOmNvbGxhcHNlO3dpZHRoOjEwMCU7bWFyZ2luOjEycHggMCAyOHB4fXRoLHRke3BhZGRpbmc6OHB4O2JvcmRlcjoxcHggc29saWQgI2NjZDNkYzt0ZXh0LWFsaWduOmxlZnR9dGh7YmFja2dyb3VuZDojZjRmN2ZifS5mYWlsZWR7Y29sb3I6I2I5MWMxYztmb250LXdlaWdodDo3MDB9LnBhc3NlZHtjb2xvcjojMDQ3ODU3O2ZvbnQtd2VpZ2h0OjcwMH0ubWV0YXtsaW5lLWhlaWdodDoxLjZ9LmNoYXJ0e21hcmdpbjoxMnB4IDAgMjhweH08L3N0eWxlPjwvaGVhZD5cbjxib2R5PjxoMT5rNiBQZXJmb3JtYW5jZSBTdW1tYXJ5PC9oMT5cbjxwIGNsYXNzPVwiJHtzdW1tYXJ5LmZhaWx1cmVzLmxlbmd0aCA/ICdmYWlsZWQnIDogJ3Bhc3NlZCd9XCI+PHN0cm9uZz4ke3N1bW1hcnkuZmFpbHVyZXMubGVuZ3RoID8gJ0ZBSUxFRCcgOiAnUEFTU0VEJ308L3N0cm9uZz48L3A+XG48cCBjbGFzcz1cIm1ldGFcIj5UYXJnZXQ6ICR7aHRtbEVzY2FwZShzdW1tYXJ5Lm1ldGFkYXRhLnRhcmdldElkKX0gKCR7aHRtbEVzY2FwZShzdW1tYXJ5Lm1ldGFkYXRhLnRhcmdldENvbW1pdCl9KTxicj5Qcm9maWxlOiAke2h0bWxFc2NhcGUoc3VtbWFyeS5tZXRhZGF0YS5wcm9maWxlKX08YnI+UnVubmVyOiAke2h0bWxFc2NhcGUoc3VtbWFyeS5tZXRhZGF0YS5ydW5uZXJDbGFzcyl9PC9wPlxuPHN2ZyBjbGFzcz1cImNoYXJ0XCIgcm9sZT1cImltZ1wiIGFyaWEtbGFiZWw9XCJMYXRlbmN5IHBlcmNlbnRpbGVzXCIgd2lkdGg9XCI3MjBcIiBoZWlnaHQ9XCIyMzBcIiB2aWV3Qm94PVwiMCAwIDcyMCAyMzBcIj4ke2NoYXJ0fTwvc3ZnPlxuPGgyPkNvcmUgTWV0cmljczwvaDI+XG48dGFibGU+PHRoZWFkPjx0cj48dGg+TWV0cmljPC90aD48dGg+cDUwPC90aD48dGg+cDkwPC90aD48dGg+cDk1PC90aD48dGg+cDk5PC90aD48dGg+UmF0ZTwvdGg+PHRoPkNvdW50PC90aD48L3RyPjwvdGhlYWQ+PHRib2R5PiR7aHRtbE1ldHJpY1Jvd3Moc3VtbWFyeS5tZXRyaWNzLCBbJ2h0dHBfcmVxX2R1cmF0aW9uJywgJ2h0dHBfcmVxX2ZhaWxlZCcsICdjaGVja3MnLCAnaHR0cF9yZXFzJywgJ2l0ZXJhdGlvbnMnXSl9PC90Ym9keT48L3RhYmxlPlxuPGgyPkVuZHBvaW50IE1ldHJpY3M8L2gyPlxuPHRhYmxlPjx0aGVhZD48dHI+PHRoPk1ldHJpYzwvdGg+PHRoPnA1MDwvdGg+PHRoPnA5MDwvdGg+PHRoPnA5NTwvdGg+PHRoPnA5OTwvdGg+PHRoPlJhdGU8L3RoPjx0aD5Db3VudDwvdGg+PC90cj48L3RoZWFkPjx0Ym9keT4ke2h0bWxNZXRyaWNSb3dzKHN1bW1hcnkubWV0cmljcywgZW5kcG9pbnRNZXRyaWNzKX08L3Rib2R5PjwvdGFibGU+XG48aDI+QnVzaW5lc3MgTWV0cmljczwvaDI+XG48dGFibGU+PHRoZWFkPjx0cj48dGg+TWV0cmljPC90aD48dGg+cDUwPC90aD48dGg+cDkwPC90aD48dGg+cDk1PC90aD48dGg+cDk5PC90aD48dGg+UmF0ZTwvdGg+PHRoPkNvdW50PC90aD48L3RyPjwvdGhlYWQ+PHRib2R5PiR7aHRtbE1ldHJpY1Jvd3Moc3VtbWFyeS5tZXRyaWNzLCBidXNpbmVzc01ldHJpY3MpfTwvdGJvZHk+PC90YWJsZT5cbjxoMj5UaHJlc2hvbGRzPC9oMj5cbjx0YWJsZT48dGhlYWQ+PHRyPjx0aD5NZXRyaWM8L3RoPjx0aD5UaHJlc2hvbGQ8L3RoPjx0aD5BY3R1YWw8L3RoPjx0aD5TdGF0dXM8L3RoPjwvdHI+PC90aGVhZD48dGJvZHk+JHtodG1sVGhyZXNob2xkUm93cyhzdW1tYXJ5KX08L3Rib2R5PjwvdGFibGU+XG48aDI+TWFya2Rvd24gU3VtbWFyeTwvaDI+XG48cHJlPiR7aHRtbEVzY2FwZShtYXJrZG93bil9PC9wcmU+XG48L2JvZHk+PC9odG1sPmA7XG5cbiAgcmV0dXJuIHtcbiAgICBbc3VtbWFyeUZpbGUoKV06IEpTT04uc3RyaW5naWZ5KHN1bW1hcnksIG51bGwsIDIpLFxuICAgIFttYXJrZG93bkZpbGUoKV06IG1hcmtkb3duLFxuICAgIFtodG1sRmlsZSgpXTogaHRtbCxcbiAgICBzdGRvdXQ6IG1hcmtkb3duLFxuICB9O1xufVxuIiwgImltcG9ydCB0eXBlIHsgVGhyZXNob2xkIH0gZnJvbSAnazYvb3B0aW9ucyc7XG5pbXBvcnQgdHlwZSB7IFNjZW5hcmlvT3B0aW9ucyB9IGZyb20gJy4vc2NlbmFyaW8udHlwZXMnO1xuXG5leHBvcnQgdHlwZSBFbnZpcm9ubWVudE5hbWUgPSAnbG9jYWwnIHwgJ3N0YWdpbmcnIHwgJ3Byb2R1Y3Rpb24nO1xuXG5leHBvcnQgaW50ZXJmYWNlIEVudkNvbmZpZyB7XG4gIGVudmlyb25tZW50OiBFbnZpcm9ubWVudE5hbWU7XG4gIGJhc2VVcmw6IHN0cmluZztcbiAgdGltZW91dHM6IHtcbiAgICBodHRwOiBudW1iZXI7XG4gIH07XG4gIGFycml2YWw6IHtcbiAgICBpdGVyYXRpb25zUGVyU2Vjb25kOiBudW1iZXI7XG4gICAgbWF4VnVzOiBudW1iZXI7XG4gIH07XG4gIHRhZ3M6IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIGFsbG93c1dyaXRlczogYm9vbGVhbjtcbn1cblxuZXhwb3J0IHR5cGUgVGhyZXNob2xkU2V0ID0gUmVjb3JkPHN0cmluZywgVGhyZXNob2xkW10+O1xuXG5leHBvcnQgY29uc3Qgc3VtbWFyeVRyZW5kU3RhdHMgPSBbJ2F2ZycsICdtaW4nLCAnbWVkJywgJ21heCcsICdwKDkwKScsICdwKDk1KScsICdwKDk5KSddO1xuXG5leHBvcnQgaW50ZXJmYWNlIFdvcmtsb2FkUHJvZmlsZSB7XG4gIHZhbGlkYXRpb246IGJvb2xlYW47XG4gIHRhcmdldEl0ZXJhdGlvbnNQZXJTZWNvbmQ6IG51bWJlcjtcbiAgbWF4VnVzOiBudW1iZXI7XG4gIHRoaW5rVGltZVNlY29uZHM6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBXb3JrbG9hZFN0YWdlIHtcbiAgZHVyYXRpb246IHN0cmluZztcbiAgdGFyZ2V0OiBudW1iZXI7XG59XG5cbmV4cG9ydCB0eXBlIFN0YWdlZFdvcmtsb2FkID1cbiAgfCAnYXV0aGVudGljYXRlZExvYWQnXG4gIHwgJ2F1dGhlbnRpY2F0ZWRTdHJlc3MnXG4gIHwgJ3N0cmVzcydcbiAgfCAnc3Bpa2UnXG4gIHwgJ3NvYWsnXG4gIHwgJ2JyZWFrcG9pbnQnO1xuXG5leHBvcnQgdHlwZSBXb3JrbG9hZFNjZW5hcmlvID0gU2NlbmFyaW9PcHRpb25zO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFBQSxhQUFzQjtBQUN0Qix1QkFBc0I7QUFDdEIsSUFBQUMsZUFBaUI7OztBQ0FWLElBQU0sY0FBeUI7QUFBQSxFQUNwQyxhQUFhO0FBQUEsRUFDYixTQUFTO0FBQUEsRUFDVCxVQUFVLEVBQUUsTUFBTSxJQUFPO0FBQUEsRUFDekIsU0FBUyxFQUFFLHFCQUFxQixJQUFJLFFBQVEsSUFBSTtBQUFBLEVBQ2hELE1BQU0sRUFBRSxLQUFLLFNBQVMsS0FBSyxVQUFVO0FBQUEsRUFDckMsY0FBYztBQUNoQjs7O0FDRE8sU0FBUyxpQkFBaUIsU0FBd0M7QUFDdkUsTUFBSSxDQUFDLFNBQVM7QUFDWixVQUFNLElBQUksTUFBTSxzREFBc0Q7QUFBQSxFQUN4RTtBQUVBLFNBQU87QUFBQSxJQUNMLGFBQWE7QUFBQSxJQUNiO0FBQUEsSUFDQSxVQUFVLEVBQUUsTUFBTSxJQUFPO0FBQUEsSUFDekIsU0FBUyxFQUFFLHFCQUFxQixJQUFJLFFBQVEsR0FBRztBQUFBLElBQy9DLE1BQU0sRUFBRSxLQUFLLGNBQWMsS0FBSyxVQUFVO0FBQUEsSUFDMUMsY0FBYztBQUFBLEVBQ2hCO0FBQ0Y7OztBQ25CTyxJQUFNLGdCQUEyQjtBQUFBLEVBQ3RDLGFBQWE7QUFBQSxFQUNiLFNBQVM7QUFBQSxFQUNULFVBQVUsRUFBRSxNQUFNLElBQU87QUFBQSxFQUN6QixTQUFTLEVBQUUscUJBQXFCLElBQUksUUFBUSxJQUFJO0FBQUEsRUFDaEQsTUFBTSxFQUFFLEtBQUssV0FBVyxLQUFLLFVBQVU7QUFBQSxFQUN2QyxjQUFjO0FBQ2hCOzs7QUNKQSxJQUFNLFVBQXFFO0FBQUEsRUFDekUsT0FBTztBQUFBLEVBQ1AsU0FBUztBQUNYO0FBUU8sU0FBUyxVQUFVLE1BQWMsTUFBTSxjQUFjLFNBQW9CO0FBQzlFLE1BQUksUUFBUSxjQUFjO0FBQ3hCLFdBQU87QUFBQSxNQUNMLEdBQUcsaUJBQWlCLE1BQU0sUUFBUTtBQUFBLE1BQ2xDLGNBQWMsTUFBTSx5QkFBeUI7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFFBQVEsV0FBVyxRQUFRLFdBQVc7QUFDeEMsV0FBTztBQUFBLE1BQ0wsR0FBRyxRQUFRLEdBQUc7QUFBQSxNQUNkLFNBQVMsTUFBTSxZQUFZLFFBQVEsR0FBRyxFQUFFO0FBQUEsTUFDeEMsY0FDRSxRQUFRLFlBQVksTUFBTSx5QkFBeUIsU0FBUyxRQUFRLEdBQUcsRUFBRTtBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUVBLFFBQU0sSUFBSSxNQUFNLHdCQUF3QixHQUFHLEdBQUc7QUFDaEQ7OztBQ2dEQSxTQUFTLGVBQWUsTUFBYyxVQUEwQjtBQUM5RCxRQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLE1BQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE1BQU0sR0FBRyxJQUFJLDRCQUE0QjtBQUFBLEVBQ3JEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBeUI7QUFDaEMsTUFBSSxNQUFNLGVBQWUsUUFBVztBQUNsQyxVQUFNLElBQUk7QUFBQSxNQUNSO0FBQUEsSUFHRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLE1BQWMsVUFBMEI7QUFDL0QsUUFBTSxRQUFRLGVBQWUsTUFBTSxRQUFRO0FBQzNDLE1BQUksQ0FBQyxPQUFPLGNBQWMsS0FBSyxFQUFHLE9BQU0sSUFBSSxNQUFNLEdBQUcsSUFBSSxrQ0FBa0M7QUFDM0YsU0FBTztBQUNUO0FBV08sU0FBUyx3QkFBNEM7QUFDMUQsbUJBQWlCO0FBQ2pCLFFBQU0sMEJBQTBCLGVBQWUsNkJBQTZCLElBQUk7QUFDaEYsTUFBSSwwQkFBMEIsR0FBRztBQUMvQixVQUFNLElBQUksTUFBTSw2Q0FBNkM7QUFBQSxFQUMvRDtBQUNBLFFBQU1DLFdBQVU7QUFBQSxJQUNkLG1CQUFtQixnQkFBZ0IsdUJBQXVCLEdBQUc7QUFBQSxJQUM3RCxRQUFRLGdCQUFnQixXQUFXLEdBQUc7QUFBQSxJQUN0QyxlQUFlLGdCQUFnQixrQkFBa0IsRUFBRTtBQUFBLElBQ25ELG9CQUFvQixnQkFBZ0IsdUJBQXVCLEVBQUU7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTyxjQUFjQSxTQUFRLG9CQUFvQkEsU0FBUSxrQkFBa0IsR0FBRztBQUNqRixVQUFNLElBQUksTUFBTSxpRUFBaUU7QUFBQSxFQUNuRjtBQUNBLFNBQU9BO0FBQ1Q7QUFPTyxTQUFTLHFCQUFzQztBQUNwRCxRQUFNQyxVQUFTLFVBQVU7QUFDekIsbUJBQWlCO0FBQ2pCLFNBQU87QUFBQSxJQUNMLFlBQVksTUFBTSxpQkFBaUI7QUFBQSxJQUNuQywyQkFBMkI7QUFBQSxNQUN6QjtBQUFBLE1BQ0FBLFFBQU8sUUFBUTtBQUFBLElBQ2pCO0FBQUEsSUFDQSxRQUFRLGdCQUFnQixXQUFXQSxRQUFPLFFBQVEsTUFBTTtBQUFBLElBQ3hELGtCQUFrQixlQUFlLHNCQUFzQixDQUFDO0FBQUEsRUFDMUQ7QUFDRjs7O0FDekpBLGtCQUE0QjtBQUU1QixJQUFNLFNBQVMsSUFBSSx3QkFBb0IsZUFBZSxNQUFNO0FBQzFELFFBQU0sTUFBTSxNQUFNO0FBQ2xCLE1BQUksQ0FBQyxJQUFLLFFBQU8sQ0FBQztBQUNsQixRQUFNLFNBQWtCLEtBQUssTUFBTSxHQUFHO0FBQ3RDLE1BQUksQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUFLLENBQUMsT0FBTyxNQUFNLENBQUMsVUFBVSxPQUFPLFVBQVUsUUFBUSxHQUFHO0FBQ2pGLFVBQU0sSUFBSSxNQUFNLGdEQUFnRDtBQUFBLEVBQ2xFO0FBQ0EsU0FBTztBQUNULENBQUM7OztBQ1ZELGdCQUFzQjs7O0FDQXRCLElBQUFDLGFBQXNCO0FBQ3RCLGtCQUFtRTs7O0FDRG5FLHFCQUFxQztBQUc5QixJQUFNLGVBQWUsSUFBSSxxQkFBTSwyQkFBMkIsSUFBSTtBQUU5RCxJQUFNLHNCQUFzQixJQUFJLHFCQUFNLG1DQUFtQyxJQUFJO0FBRTdFLElBQU0sdUJBQXVCLElBQUkscUJBQU0sb0NBQW9DLElBQUk7QUFFL0UsSUFBTSxrQkFBa0IsSUFBSSxxQkFBTSw4QkFBOEIsSUFBSTtBQUVwRSxJQUFNLGtCQUFrQixJQUFJLHFCQUFNLDhCQUE4QixJQUFJO0FBRXBFLElBQU0sY0FBYyxJQUFJLHFCQUFNLDBCQUEwQixJQUFJO0FBRTVELElBQU0sc0JBQXNCLElBQUksdUJBQVEsOEJBQThCO0FBRXRFLElBQU0sa0JBQWtCLElBQUksb0JBQUssMEJBQTBCO0FBRTNELElBQU0seUJBQXlCLElBQUksb0JBQUssa0NBQWtDO0FBRTFFLElBQU0sMEJBQTBCLElBQUksb0JBQUssbUNBQW1DO0FBRTVFLElBQU0scUJBQXFCLElBQUksb0JBQUssNkJBQTZCO0FBRWpFLElBQU0scUJBQXFCLElBQUksb0JBQUssNkJBQTZCO0FBRWpFLElBQU0saUJBQWlCLElBQUksb0JBQUsseUJBQXlCOzs7QUMzQmhFLElBQUFDLGVBQTRCOzs7QUNBNUI7QUFBQSxFQUNFLEVBQUUsTUFBUSxnQkFBZ0IsUUFBVSxJQUFJLGNBQWdCLEdBQUcsZ0JBQWtCLE1BQU07QUFBQSxFQUNuRixFQUFFLE1BQVEsa0JBQWtCLFFBQVUsSUFBSSxjQUFnQixJQUFJLGdCQUFrQixLQUFLO0FBQUEsRUFDckYsRUFBRSxNQUFRLGVBQWUsUUFBVSxJQUFJLGNBQWdCLElBQUksZ0JBQWtCLEtBQUs7QUFDcEY7OztBRE1BLElBQU0sWUFBWSxJQUFJO0FBQUEsRUFBNEI7QUFBQSxFQUFvQixNQUNwRSx5QkFBTyxJQUFJLENBQUMsY0FBYyxFQUFFLEdBQUcsU0FBUyxFQUFFO0FBQzVDOzs7QUVETyxTQUFTLDJCQUEyQixRQUFnQztBQUN6RSxRQUFNQyxVQUFTLFVBQVU7QUFDekIsUUFBTSxXQUFXLG1FQUFtRTtBQUFBLElBQ2xGQSxRQUFPO0FBQUEsRUFDVDtBQUNBLE9BQUtBLFFBQU8sZ0JBQWdCLFdBQVcsQ0FBQyxhQUFhLE1BQU0seUJBQXlCLFFBQVE7QUFDMUYsVUFBTSxJQUFJO0FBQUEsTUFDUixHQUFHLE9BQU8sUUFBUSxJQUFJLE9BQU8sUUFBUSxVQUFVLE1BQU07QUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFDRjs7O0FDTE8sU0FBUyxtQkFDZEMsVUFDQSxRQUtjO0FBQ2QsUUFBTSxVQUFvQixDQUFDO0FBQzNCLFFBQU0sYUFBYSxDQUFDLFVBQ2xCLFVBQVUsVUFBYSxPQUFPLGNBQWMsS0FBSyxLQUFLLFNBQVM7QUFDakUsUUFBTSxhQUFhLFdBQVcsT0FBTyxVQUFVLElBQUksT0FBTyxhQUFhO0FBQ3ZFLFFBQU0sV0FBVyxXQUFXLE9BQU8sUUFBUSxJQUFJLE9BQU8sV0FBVztBQUNqRSxRQUFNLFVBQVUsV0FBVyxPQUFPLE9BQU8sSUFBSSxPQUFPLFVBQVU7QUFDOUQsTUFBSSxlQUFlLFFBQVEsYUFBYSxRQUFRLFlBQVksTUFBTTtBQUNoRSxZQUFRLEtBQUssc0NBQXNDO0FBQUEsRUFDckQ7QUFDQSxRQUFNLFdBQVdBLFNBQVEsb0JBQW9CQSxTQUFRO0FBQ3JELE1BQUksZUFBZSxRQUFRLGFBQWEsV0FBV0EsU0FBUSx5QkFBeUI7QUFDbEYsWUFBUSxLQUFLLHVEQUF1RDtBQUFBLEVBQ3RFO0FBQ0EsTUFBSSxhQUFhLFFBQVEsV0FBVyxXQUFXQSxTQUFRLHlCQUF5QjtBQUM5RSxZQUFRLEtBQUssa0RBQWtEO0FBQUEsRUFDakU7QUFDQSxNQUFJLGFBQWEsUUFBUSxlQUFlLFFBQVEsYUFBYSxZQUFZO0FBQ3ZFLFlBQVEsS0FBSyx1REFBdUQ7QUFBQSxFQUN0RTtBQUNBLE1BQUksYUFBYSxRQUFRLFdBQVcsV0FBVyxHQUFHO0FBQ2hELFlBQVEsS0FBSyxpREFBaUQ7QUFBQSxFQUNoRTtBQUNBLE1BQUksWUFBWSxRQUFRLFVBQVUsRUFBRyxTQUFRLEtBQUssMENBQTBDO0FBQzVGLFNBQU87QUFBQSxJQUNMLE9BQU8sUUFBUSxXQUFXO0FBQUEsSUFDMUI7QUFBQSxJQUNBLDZCQUE2QkEsU0FBUTtBQUFBLElBQ3JDLG9CQUFvQkEsU0FBUTtBQUFBLElBQzVCLHlCQUF5QkEsU0FBUTtBQUFBLElBQ2pDLHFCQUFxQjtBQUFBLElBQ3JCO0FBQUEsSUFDQSxtQkFBbUI7QUFBQSxJQUNuQiw2QkFDRSxlQUFlLE9BQU8sT0FBTyxhQUFhQSxTQUFRO0FBQUEsSUFDcEQsMkJBQTJCLGFBQWEsT0FBTyxPQUFPLFdBQVdBLFNBQVE7QUFBQSxFQUMzRTtBQUNGOzs7QUNFQSxTQUFTLGNBQXNCO0FBQzdCLFFBQU0sT0FBTyxNQUFNLGdCQUFnQjtBQUNuQyxTQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUVBLFNBQVMsZUFBdUI7QUFDOUIsUUFBTSxPQUFPLE1BQU0sZ0JBQWdCO0FBQ25DLFNBQU8sV0FBVyxJQUFJO0FBQ3hCO0FBRUEsU0FBUyxXQUFtQjtBQUMxQixRQUFNLE9BQU8sTUFBTSxnQkFBZ0I7QUFDbkMsU0FBTyxXQUFXLElBQUk7QUFDeEI7QUFFQSxTQUFTLFVBQVUsTUFBYyxRQUEwQztBQUN6RSxRQUFNLFNBQVMsUUFBUTtBQUN2QixRQUFNLE1BQU0sU0FBUyxPQUFPO0FBQzVCLFFBQU0sTUFBTSxTQUFTLE9BQU87QUFDNUIsUUFBTSxNQUFNLFNBQVMsT0FBTztBQUM1QixRQUFNLE1BQU0sUUFBUTtBQUNwQixRQUFNLE9BQU8sUUFBUTtBQUNyQixRQUFNLFFBQVEsUUFBUTtBQUN0QixTQUFPLEtBQUssSUFBSSxNQUFNLFFBQVEsUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLEtBQUssUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLEtBQUssUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLEtBQUssUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLEtBQUssUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLE1BQU0sUUFBUSxDQUFDLEtBQUssR0FBRyxNQUFNLFNBQVMsR0FBRztBQUNoTjtBQUVBLFNBQVMsZ0JBQWdCLFFBQXNCLFdBQXVDO0FBQ3BGLFFBQU0sTUFBTSxVQUFVLE1BQU0sOENBQThDLElBQUksQ0FBQztBQUMvRSxTQUFPLE1BQU0sT0FBTyxHQUF5QixJQUFJO0FBQ25EO0FBRUEsU0FBUyxXQUFXLE9BQXVCO0FBQ3pDLFNBQU8sTUFDSixXQUFXLEtBQUssT0FBTyxFQUN2QixXQUFXLEtBQUssTUFBTSxFQUN0QixXQUFXLEtBQUssTUFBTSxFQUN0QixXQUFXLEtBQUssUUFBUTtBQUM3QjtBQUVBLFNBQVMsWUFBWSxPQUEyQixTQUFTLEdBQVc7QUFDbEUsU0FBTyxVQUFVLFNBQVksTUFBTSxNQUFNLFFBQVEsTUFBTTtBQUN6RDtBQUVBLFNBQVMsZUFBZSxTQUF1QyxPQUF5QjtBQUN0RixNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFdBQU87QUFBQSxFQUNUO0FBQ0EsU0FBTyxNQUNKLElBQUksQ0FBQyxTQUFTO0FBQ2IsVUFBTSxTQUFTLFFBQVEsSUFBSSxLQUFLLENBQUM7QUFDakMsV0FBTyxXQUFXLFdBQVcsSUFBSSxDQUFDLFlBQVksWUFBWSxPQUFPLEdBQUcsQ0FBQyxZQUFZLFlBQVksT0FBTyxPQUFPLENBQUMsQ0FBQyxZQUFZLFlBQVksT0FBTyxPQUFPLENBQUMsQ0FBQyxZQUFZLFlBQVksT0FBTyxPQUFPLENBQUMsQ0FBQyxZQUFZLFlBQVksT0FBTyxNQUFNLENBQUMsQ0FBQyxZQUFZLE9BQU8sU0FBUyxHQUFHO0FBQUEsRUFDclEsQ0FBQyxFQUNBLEtBQUssRUFBRTtBQUNaO0FBRUEsU0FBUyxrQkFBa0IsU0FBcUM7QUFDOUQsUUFBTSxPQUFPLE9BQU8sUUFBUSxRQUFRLFVBQVUsRUFBRTtBQUFBLElBQVEsQ0FBQyxDQUFDLFFBQVEsVUFBVSxNQUMxRSxPQUFPLFFBQVEsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDLFdBQVcsTUFBTSxNQUFNO0FBQ3RELFlBQU0sU0FBUyxnQkFBZ0IsUUFBUSxRQUFRLE1BQU0sS0FBSyxDQUFDLEdBQUcsU0FBUztBQUN2RSxhQUFPLFdBQVcsV0FBVyxNQUFNLENBQUMsWUFBWSxXQUFXLFNBQVMsQ0FBQyxZQUFZLFVBQVUsYUFBYSxtQkFBbUIsT0FBTyxLQUFLLFdBQVcsUUFBUSxLQUFLLE9BQU8sS0FBSyxTQUFTLE1BQU07QUFBQSxJQUM1TCxDQUFDO0FBQUEsRUFDSDtBQUNBLFNBQU8sS0FBSyxXQUFXLElBQ25CLHNFQUNBLEtBQUssS0FBSyxFQUFFO0FBQ2xCO0FBT08sU0FBUyxjQUFjLE1BQTJDO0FBQ3ZFLFFBQU0sV0FBVyxtQkFBbUI7QUFDcEMsUUFBTSxpQkFBaUIsTUFBTSxrQkFBa0IsaUJBQWlCLHNCQUFzQixJQUFJO0FBQzFGLFFBQU0sZUFBZSxpQkFDakIsbUJBQW1CLGdCQUFnQjtBQUFBLElBQ2pDLFlBQVksS0FBSyxRQUFRLDBDQUEwQyxHQUFHLE9BQU87QUFBQSxJQUM3RSxVQUFVLEtBQUssUUFBUSx5Q0FBeUMsR0FBRyxPQUFPO0FBQUEsSUFDMUUsU0FBUyxLQUFLLFFBQVEsa0RBQWtELEdBQUcsT0FBTztBQUFBLEVBQ3BGLENBQUMsSUFDRDtBQUNKLFFBQU0sZ0JBQWdCLEtBQUssUUFBUSxRQUFRLE9BQU8sU0FBUztBQUMzRCxRQUFNLHdCQUNKLEtBQUssUUFBUSx3QkFBd0IsT0FBTyxTQUFTLEtBQUssTUFBTSx5QkFBeUI7QUFDM0YsUUFBTSxjQUFjLEtBQUssTUFBTSxlQUFlO0FBQzlDLFFBQU0sVUFBOEI7QUFBQSxJQUNsQztBQUFBLElBQ0EsVUFBVSxDQUFDO0FBQUEsSUFDWCxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsU0FBUyxPQUFPO0FBQUEsTUFDZCxPQUFPLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTSxNQUFNLE1BQU0sQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDO0FBQUEsSUFDNUU7QUFBQSxJQUNBLFVBQVU7QUFBQSxNQUNSLGFBQWEsTUFBTSxjQUFjO0FBQUEsTUFDakMsaUJBQWlCLE1BQU0sb0JBQW9CO0FBQUEsTUFDM0MsV0FBVyxNQUFNLGNBQWM7QUFBQSxNQUMvQixRQUFRLGdCQUFnQixVQUFVLFNBQVM7QUFBQSxNQUMzQyxTQUFTLE1BQU0sZ0JBQWdCO0FBQUEsTUFDL0IsYUFBYSxNQUFNLGdCQUFnQjtBQUFBLE1BQ25DLGNBQWMsTUFBTSxpQkFBaUI7QUFBQSxNQUNyQyxVQUFVLE1BQU0sYUFBYSxNQUFNLGNBQWM7QUFBQSxNQUNqRCxnQkFBZ0IsaUJBQWlCLDhCQUE4QjtBQUFBLE1BQy9ELDJCQUNFLGdCQUFnQixxQkFBcUIsU0FBUztBQUFBLE1BQ2hELHlCQUF5QixnQkFBZ0IscUJBQXFCO0FBQUEsTUFDOUQsb0JBQW9CLGdCQUFnQixzQkFBc0I7QUFBQSxNQUMxRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCx5QkFBeUIsZ0JBQWdCLDJCQUEyQjtBQUFBLElBQ3RFO0FBQUEsSUFDQSxXQUFXLEtBQUs7QUFBQSxJQUNoQixPQUFPLEtBQUs7QUFBQSxJQUNaLFlBQVksT0FBTztBQUFBLE1BQ2pCLE9BQU8sUUFBUSxLQUFLLE9BQU8sRUFDeEIsT0FBTyxDQUFDLENBQUMsRUFBRSxNQUFNLE1BQU0sT0FBTyxVQUFVLEVBQ3hDLElBQUksQ0FBQyxDQUFDLE1BQU0sTUFBTSxNQUFNLENBQUMsTUFBTSxPQUFPLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUM1RDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLG1CQUFtQixPQUFPLFFBQVEsUUFBUSxVQUFVLEVBQUU7QUFBQSxJQUFRLENBQUMsQ0FBQyxRQUFRLFVBQVUsTUFDdEYsT0FBTyxRQUFRLFVBQVUsRUFDdEIsT0FBTyxDQUFDLENBQUMsRUFBRSxNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsRUFDakMsSUFBSSxDQUFDLENBQUMsU0FBUyxNQUFNO0FBQ3BCLFlBQU0sU0FBUyxnQkFBZ0IsUUFBUSxRQUFRLE1BQU0sS0FBSyxDQUFDLEdBQUcsU0FBUztBQUN2RSxhQUFPLEdBQUcsTUFBTSxjQUFjLFNBQVMsWUFBWSxVQUFVLGFBQWE7QUFBQSxJQUM1RSxDQUFDO0FBQUEsRUFDTDtBQUNBLFVBQVEsV0FBVztBQUFBLElBQ2pCLEdBQUksZ0JBQWdCLENBQUMsYUFBYSxRQUM5QixhQUFhLFFBQVEsSUFBSSxDQUFDLFdBQVcsNEJBQTRCLE1BQU0sRUFBRSxJQUN6RSxDQUFDO0FBQUEsSUFDTCxHQUFHLGlCQUFpQixJQUFJLENBQUMsWUFBWSxjQUFjLE9BQU8sRUFBRTtBQUFBLElBQzVELEdBQUksZ0JBQWdCLElBQUksQ0FBQyxXQUFXLGFBQWEsU0FBUyxJQUFJLENBQUM7QUFBQSxJQUMvRCxHQUFJLGNBQWMsSUFBSSxDQUFDLFVBQVUsV0FBVyxXQUFXLElBQUksQ0FBQztBQUFBLElBQzVELEdBQUksd0JBQXdCLElBQ3hCLENBQUMsY0FBYyxxQkFBcUIsMkJBQTJCLElBQy9ELENBQUM7QUFBQSxFQUNQO0FBQ0EsUUFBTSxXQUFXO0FBQUEsSUFDZjtBQUFBLElBQ0E7QUFBQSxJQUNBLG1CQUFtQixRQUFRLFNBQVMsU0FBUyxXQUFXLFFBQVE7QUFBQSxJQUNoRSxlQUFlLFFBQVEsU0FBUyxRQUFRLEtBQUssUUFBUSxTQUFTLFlBQVk7QUFBQSxJQUMxRSxnQkFBZ0IsUUFBUSxTQUFTLE9BQU8sT0FBTyxRQUFRLFNBQVMsV0FBVztBQUFBLElBQzNFLHdCQUF3QixRQUFRLFNBQVMsY0FBYztBQUFBLElBQ3ZELDJCQUEyQixRQUFRLFNBQVMseUJBQXlCO0FBQUEsSUFDckUsNEJBQTRCLFFBQVEsU0FBUywyQkFBMkIsOEJBQThCLEdBQUcsaUJBQWlCLGdCQUFnQixFQUFFO0FBQUEsSUFDNUksR0FBSSxlQUNBO0FBQUEsTUFDRSxvQkFBb0IsYUFBYSxrQkFBa0I7QUFBQSxNQUNuRCxpQkFBaUIsYUFBYSwrQkFBK0IsU0FBUyw0QkFBNEIsYUFBYSw2QkFBNkIsU0FBUyxnQkFBZ0IsYUFBYSxxQkFBcUIsU0FBUztBQUFBLE1BQ2hOLHNCQUFzQixhQUFhLFFBQVEsVUFBVSxTQUFTLGtDQUFrQyxhQUFhLHVCQUF1QjtBQUFBLElBQ3RJLElBQ0E7QUFBQSxNQUNFLGdDQUFnQyxRQUFRLFFBQVEsWUFBWSxRQUFRLFNBQVMsa0JBQWtCLFFBQVEsUUFBUSxXQUFXLFFBQVEsU0FBUztBQUFBLElBQzdJO0FBQUEsSUFDSixHQUFJLFFBQVEsU0FBUyxTQUFTLENBQUMsSUFBSSxHQUFHLFFBQVEsU0FBUyxJQUFJLENBQUMsWUFBWSxLQUFLLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQztBQUFBLElBQzVGO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFVBQVUscUJBQXFCLFFBQVEsUUFBUSxpQkFBaUI7QUFBQSxJQUNoRSxVQUFVLG1CQUFtQixRQUFRLFFBQVEsZUFBZTtBQUFBLElBQzVELFVBQVUsVUFBVSxRQUFRLFFBQVEsTUFBTTtBQUFBLElBQzFDLFVBQVUsYUFBYSxRQUFRLFFBQVEsU0FBUztBQUFBLElBQ2hELFVBQVUsY0FBYyxRQUFRLFFBQVEsVUFBVTtBQUFBLElBQ2xELFVBQVUsbUNBQW1DLFFBQVEsUUFBUSwrQkFBK0I7QUFBQSxJQUM1RixVQUFVLGdDQUFnQyxRQUFRLFFBQVEsNEJBQTRCO0FBQUEsSUFDdEY7QUFBQSxFQUNGLEVBQUUsS0FBSyxJQUFJO0FBQ1gsUUFBTSxXQUFXLFFBQVEsUUFBUSxxQkFBcUIsQ0FBQztBQUN2RCxRQUFNLE9BQU87QUFBQSxJQUNYLENBQUMsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUFBLElBQ3pCLENBQUMsT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDO0FBQUEsSUFDOUIsQ0FBQyxPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUM7QUFBQSxJQUM5QixDQUFDLE9BQU8sU0FBUyxPQUFPLEtBQUssQ0FBQztBQUFBLElBQzlCLENBQUMsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUFBLEVBQzNCO0FBQ0EsUUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRSxLQUFLLE1BQU0sS0FBSyxHQUFHLENBQUM7QUFDN0QsUUFBTSxRQUFRLEtBQ1g7QUFBQSxJQUNDLENBQUMsQ0FBQyxPQUFPLEtBQUssR0FBRyxVQUNmLDZCQUE2QixRQUFRLEVBQUUseUJBQXlCLEtBQUssb0NBQXFDLFFBQVEsVUFBVyxHQUFHLDBDQUEwQyxLQUFNLFFBQVEsVUFBVyxHQUFHLFlBQVksTUFBTSxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQ3RPLEVBQ0MsS0FBSyxFQUFFO0FBQ1YsUUFBTSxrQkFBa0IsT0FBTyxLQUFLLFFBQVEsT0FBTyxFQUNoRDtBQUFBLElBQ0MsQ0FBQyxTQUNDLEtBQUssV0FBVyx5QkFBeUIsS0FBSyxLQUFLLFdBQVcsdUJBQXVCO0FBQUEsRUFDekYsRUFDQyxLQUFLO0FBQ1IsUUFBTSxrQkFBa0IsT0FBTyxLQUFLLFFBQVEsT0FBTyxFQUNoRCxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsU0FBUyxDQUFDLEVBQzNDLEtBQUs7QUFDUixRQUFNLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlILFFBQVEsU0FBUyxTQUFTLFdBQVcsUUFBUSxhQUFhLFFBQVEsU0FBUyxTQUFTLFdBQVcsUUFBUTtBQUFBLDBCQUN6RixXQUFXLFFBQVEsU0FBUyxRQUFRLENBQUMsS0FBSyxXQUFXLFFBQVEsU0FBUyxZQUFZLENBQUMsaUJBQWlCLFdBQVcsUUFBUSxTQUFTLE9BQU8sQ0FBQyxlQUFlLFdBQVcsUUFBUSxTQUFTLFdBQVcsQ0FBQztBQUFBLGdIQUN6RyxLQUFLO0FBQUE7QUFBQSxrSUFFYSxlQUFlLFFBQVEsU0FBUyxDQUFDLHFCQUFxQixtQkFBbUIsVUFBVSxhQUFhLFlBQVksQ0FBQyxDQUFDO0FBQUE7QUFBQSxrSUFFOUcsZUFBZSxRQUFRLFNBQVMsZUFBZSxDQUFDO0FBQUE7QUFBQSxrSUFFaEQsZUFBZSxRQUFRLFNBQVMsZUFBZSxDQUFDO0FBQUE7QUFBQSx1R0FFM0Usa0JBQWtCLE9BQU8sQ0FBQztBQUFBO0FBQUEsT0FFMUgsV0FBVyxRQUFRLENBQUM7QUFBQTtBQUd6QixTQUFPO0FBQUEsSUFDTCxDQUFDLFlBQVksQ0FBQyxHQUFHLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ2hELENBQUMsYUFBYSxDQUFDLEdBQUc7QUFBQSxJQUNsQixDQUFDLFNBQVMsQ0FBQyxHQUFHO0FBQUEsSUFDZCxRQUFRO0FBQUEsRUFDVjtBQUNGOzs7QUNsUU8sSUFBTSxvQkFBb0IsQ0FBQyxPQUFPLE9BQU8sT0FBTyxPQUFPLFNBQVMsU0FBUyxPQUFPOzs7QWZadkYsMkJBQTJCLEVBQUUsVUFBVSw4QkFBOEIsQ0FBQztBQUN0RSxJQUFJLE1BQU0sa0JBQWtCLGdCQUFnQjtBQUMxQyxRQUFNLElBQUksTUFBTSwrREFBK0Q7QUFDakY7QUFDQSxJQUFNLFVBQVUsc0JBQXNCO0FBQ3RDLElBQU0sU0FBUyxVQUFVO0FBQ3pCLElBQU0sZUFBZSxLQUFLO0FBQUEsRUFDeEIsUUFBUSxvQkFBb0IsUUFBUSxxQkFBcUIsUUFBUTtBQUNuRTtBQUNBLElBQU0sZ0JBQWdCLFFBQVEsb0JBQW9CLFFBQVE7QUFFbkQsSUFBTSxVQUFtQjtBQUFBLEVBQzlCLFdBQVc7QUFBQSxJQUNULGdCQUFnQjtBQUFBLE1BQ2QsVUFBVTtBQUFBLE1BQ1YsTUFBTTtBQUFBLE1BQ04sTUFBTSxRQUFRO0FBQUEsTUFDZCxVQUFVO0FBQUEsTUFDVixVQUFVLEdBQUcsUUFBUSxhQUFhO0FBQUEsTUFDbEMsaUJBQWlCLEtBQUssSUFBSSxJQUFJLFFBQVEsTUFBTTtBQUFBLE1BQzVDLFFBQVEsUUFBUTtBQUFBLE1BQ2hCLGNBQWM7QUFBQSxJQUNoQjtBQUFBLElBQ0EscUJBQXFCO0FBQUEsTUFDbkIsVUFBVTtBQUFBLE1BQ1YsTUFBTTtBQUFBLE1BQ04sV0FBVyxHQUFHLFFBQVEsZ0JBQWdCLENBQUM7QUFBQSxNQUN2QyxNQUFNLFFBQVE7QUFBQSxNQUNkLFVBQVU7QUFBQSxNQUNWLFVBQVUsR0FBRyxRQUFRLGtCQUFrQjtBQUFBLE1BQ3ZDLGlCQUFpQixLQUFLLElBQUksSUFBSSxRQUFRLE1BQU07QUFBQSxNQUM1QyxRQUFRLFFBQVE7QUFBQSxNQUNoQixjQUFjO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUVBLFlBQVk7QUFBQSxJQUNWLDJDQUEyQztBQUFBLE1BQ3pDLFVBQVUsWUFBWTtBQUFBLE1BQ3RCLFVBQVUsZ0JBQWdCLENBQUM7QUFBQSxJQUM3QjtBQUFBLElBQ0EsNENBQTRDLENBQUMsVUFBVSxZQUFZLEVBQUU7QUFBQSxJQUNyRSxvREFBb0QsQ0FBQyxVQUFVO0FBQUEsSUFDL0Qsd0NBQXdDLENBQUMsU0FBUztBQUFBLElBQ2xELGlEQUFpRCxDQUFDLFdBQVc7QUFBQSxJQUM3RCxtREFBbUQsQ0FBQyxZQUFZLFdBQVc7QUFBQSxFQUM3RTtBQUFBLEVBQ0EsY0FBYztBQUFBLEVBQ2Q7QUFDRjtBQUdPLFNBQVMsZ0JBQXNCO0FBQ3BDLFFBQU0sT0FDSixpQkFBQUMsUUFBVSxTQUFTLGtCQUFrQixNQUFNLElBQUksVUFBVTtBQUMzRCxRQUFNLFdBQVcsYUFBQUMsUUFBSyxJQUFJLEdBQUcsT0FBTyxRQUFRLFFBQVEsT0FBTyxFQUFFLENBQUMsR0FBRyxJQUFJLElBQUk7QUFBQSxJQUN2RSxXQUFXO0FBQUEsSUFDWCxTQUFTO0FBQUEsSUFDVCxTQUFTLEVBQUUsZ0JBQWdCLGlCQUFBRCxRQUFVLFNBQVMsS0FBSztBQUFBLElBQ25ELE1BQU0sRUFBRSxHQUFHLE9BQU8sTUFBTSxNQUFNLEtBQUssV0FBVyxPQUFPLElBQUksY0FBYyxnQkFBZ0I7QUFBQSxFQUN6RixDQUFDO0FBQ0Qsd0JBQU0sVUFBVSxFQUFFLGdDQUFnQyxDQUFDLFdBQVcsT0FBTyxXQUFXLElBQUksQ0FBQztBQUN2RjtBQUVPLElBQU0sZ0JBQWdCOyIsCiAgIm5hbWVzIjogWyJpbXBvcnRfazYiLCAiaW1wb3J0X2h0dHAiLCAicHJvZmlsZSIsICJjb25maWciLCAiaW1wb3J0X2s2IiwgImltcG9ydF9kYXRhIiwgImNvbmZpZyIsICJwcm9maWxlIiwgImV4ZWN1dGlvbiIsICJodHRwIl0KfQo=
